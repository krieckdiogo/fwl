import React, { useState, useEffect, useMemo } from 'react';
import { fetchLeagueData, getAvatarUrl } from '../services/sleeper';
import { 
  Trophy, 
  ArrowLeft, 
  Search, 
  ShieldCheck, 
  History, 
  Globe, 
  Award, 
  User, 
  AlertCircle,
  RefreshCw,
  Flame,
  Medal,
  Crown,
  ChevronRight
} from 'lucide-react';

interface PlayoffsChallengeProps {
  onBack: () => void;
}

interface Participant {
  name: string;
  seed: number;
  score: number;
  avatar?: string | null;
}

interface Match {
  id: number;
  t1: Participant;
  t2: Participant;
  winnerName: string;
}

interface ManagerMap {
  [key: string]: {
    username: string;
    avatar: string | null;
  }
}

const MANUAL_USER_EXCEPTIONS: Record<string, string> = {
  "old no. 7th round": "josuebrazil",
  "old no. 7th round picks": "josuebrazil",
  "respiração touchdown": "Tomchdown",
  "tre white goalie": "hellison99",
  "tre white goalie academy": "hellison99",
  "exit light!": "NeltonLopes",
  "exit light, enter night!": "NeltonLopes",
  "underdog": "PinhaisUnderdogs",
  "golden tate war.": "Canoleira",
  "golden tate warriors": "Canoleira",
  "camaragibe rep.": "PedroLuz07",
  "camaragibe republicans": "PedroLuz07",
  "colossal": "Yuriidjsantos",
  "american bulldogs": "Igwells",
  "vader's": "Vader",
  "eaglesabs": "EaglesABS",
  "samurais olhos": "B3TO",
  "samurais olhos azuis": "B3TO",
  "samurais de olhos azuis": "B3TO",
  "twerkzone": "Reagetime2",
  "vaifogo": "Fogonabombaaaa",
  "russell wilson": "HawkDestro",
  "brazil colts": "matigianini",
  "brazilian colts": "matigianini"
};

const DIVISIONAL_IDS = [
  '1204159865153388544', '1227151609222414336', '1203718439328288768', '1227148843859062784',
  '1204160977872883712', '1208069127642558464', '1228858492396249088', '1205275237512380416',
  '1230678720927256576', '1204161934232911872', '1208069811418976256', '1228075640113086464',
  '1230631997513154560', '1229611593545826304', '1228008558625292288', '1205275488969306112',
  '1230004768844283904', '1205274747131150336', '1227150862938284032', '1205275066451906560',
  '1230515275959377920'
];

const roundsInfo = [
  { id: 1, label: 'R1 (W2)', week: 2, desc: 'Wildcard' },
  { id: 2, label: 'R2 (W3)', week: 3, desc: 'Round of 128' },
  { id: 3, label: 'R3 (W4)', week: 4, desc: 'Round of 64' },
  { id: 4, label: 'R4 (W5)', week: 5, desc: 'Round of 32' },
  { id: 5, label: 'QF (W6)', week: 6, desc: 'Elite 8' },
  { id: 6, label: 'SF (W7)', week: 7, desc: 'Final Four' },
  { id: 7, label: 'F (W8)', week: 8, desc: 'Semifinais' },
  { id: 8, label: '3º (W9)', week: 9, desc: 'Disputa de Bronze' },
  { id: 9, label: 'GF (W9)', week: 9, desc: 'Grand Final' },
];

const PlayoffsChallenge: React.FC<PlayoffsChallengeProps> = ({ onBack }) => {
  const [activeRoundTab, setActiveRoundTab] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [userMap, setUserMap] = useState<ManagerMap>({});
  const [loadingMapping, setLoadingMapping] = useState(true);

  useEffect(() => {
    const loadMapping = async () => {
      const mapping: ManagerMap = {};
      try {
        const results = await Promise.all(
          DIVISIONAL_IDS.map(id => fetchLeagueData(id).catch(() => null))
        );
        results.forEach(data => {
          if (!data) return;
          data.users.forEach(user => {
            const teamName = user.metadata?.team_name;
            const displayName = user.display_name;
            if (teamName) mapping[teamName.toLowerCase().trim()] = { username: displayName, avatar: user.avatar };
            mapping[displayName.toLowerCase().trim()] = { username: displayName, avatar: user.avatar };
          });
        });
        setUserMap(mapping);
      } catch (err) { console.error(err); } finally { setLoadingMapping(false); }
    };
    loadMapping();
  }, []);

  const getManagerInfo = (name: string) => {
    const key = name.toLowerCase().trim();
    if (MANUAL_USER_EXCEPTIONS[key]) return { username: MANUAL_USER_EXCEPTIONS[key], avatar: null, isPending: false };
    if (userMap[key]) return { ...userMap[key], isPending: false };
    return { username: 'manager_tbd', avatar: null, isPending: true };
  };

  const STATIC_BRACKET: Record<number, Match[]> = {
    1: [
      { id: 1, t1: { name: 'DGlad', seed: 5, score: 120.52 }, t2: { name: 'Brazuka Cheesers', seed: 252, score: 117.34 }, winnerName: 'DGlad' },
      { id: 2, t1: { name: 'Inno9', seed: 6, score: 125.30 }, t2: { name: 'EULLER_MATOS', seed: 251, score: 41.34 }, winnerName: 'Inno9' },
      { id: 3, t1: { name: 'Green frogs', seed: 7, score: 112.80 }, t2: { name: 'AugustoFuente', seed: 250, score: 102.18 }, winnerName: 'Green frogs' },
      { id: 4, t1: { name: 'LiaraFP', seed: 8, score: 90.52 }, t2: { name: 'Kobawsk', seed: 249, score: 95.18 }, winnerName: 'Kobawsk' },
      { id: 5, t1: { name: 'Lunatkicks', seed: 9, score: 110.44 }, t2: { name: 'crflicao', seed: 248, score: 104.18 }, winnerName: 'Lunatkicks' },
      { id: 6, t1: { name: 'Real Garruchos F.C', seed: 10, score: 102.70 }, t2: { name: 'MTosti', seed: 247, score: 79.60 }, winnerName: 'Real Garruchos F.C' },
      { id: 7, t1: { name: 'jetro50', seed: 11, score: 105.88 }, t2: { name: 'saylentbob', seed: 246, score: 84.24 }, winnerName: 'jetro50' },
      { id: 8, t1: { name: 'DeflateKing', seed: 12, score: 101.38 }, t2: { name: 'Gumagol971', seed: 245, score: 94.80 }, winnerName: 'DeflateKing' },
      { id: 9, t1: { name: 'Leitinho Dolphins', seed: 13, score: 138.80 }, t2: { name: 'OCITELHTA VENTANIA', seed: 244, score: 94.20 }, winnerName: 'Leitinho Dolphins' },
      { id: 10, t1: { name: 'SOAD', seed: 14, score: 87.74 }, t2: { name: 'Sirigaita', seed: 243, score: 115.86 }, winnerName: 'Sirigaita' },
      { id: 11, t1: { name: 'FabricioCunha', seed: 15, score: 103.00 }, t2: { name: 'Denver Donkeys', seed: 242, score: 106.44 }, winnerName: 'Denver Donkeys' },
      { id: 12, t1: { name: 'diegohssg', seed: 16, score: 121.78 }, t2: { name: 'FC Chucruts', seed: 241, score: 126.54 }, winnerName: 'FC Chucruts' },
      { id: 13, t1: { name: 'ライオンズ', seed: 17, score: 145.76 }, t2: { name: 'Black Bulls', seed: 240, score: 97.94 }, winnerName: 'ライオンズ' },
      { id: 14, t1: { name: 'Moita Team', seed: 18, score: 101.62 }, t2: { name: 'vagnercf', seed: 239, score: 107.30 }, winnerName: 'vagnercf' },
      { id: 15, t1: { name: 'GuiRezende', seed: 19, score: 116.40 }, t2: { name: 'KFC Kings', seed: 238, score: 130.84 }, winnerName: 'KFC Kings' },
      { id: 16, t1: { name: 'beu128', seed: 20, score: 101.64 }, t2: { name: 'VoliBEARS', seed: 237, score: 88.88 }, winnerName: 'beu128' },
      { id: 17, t1: { name: 'Tre White Goalie Academy', seed: 21, score: 82.02 }, t2: { name: 'Angeloni99', seed: 236, score: 115.00 }, winnerName: 'Angeloni99' },
      { id: 18, t1: { name: 'Clemson Broncos', seed: 22, score: 130.60 }, t2: { name: 'Viúvo do Brady', seed: 235, score: 152.58 }, winnerName: 'Viúvo do Brady' },
      { id: 19, t1: { name: 'Old No. 7th Round Picks', seed: 23, score: 107.32 }, t2: { name: 'Viuvo do Baker', seed: 234, score: 92.90 }, winnerName: 'Old No. 7th Round Picks' },
      { id: 20, t1: { name: 'Verdigris Calamities', seed: 24, score: 116.18 }, t2: { name: 'NathanLuccas22', seed: 233, score: 88.54 }, winnerName: 'Verdigris Calamities' },
      { id: 21, t1: { name: 'Melca7', seed: 25, score: 141.04 }, t2: { name: 'Felipesimoes', seed: 232, score: 124.40 }, winnerName: 'Melca7' },
      { id: 22, t1: { name: 'FalcaoReal', seed: 26, score: 113.52 }, t2: { name: 'GMJohnWick', seed: 231, score: 84.76 }, winnerName: 'FalcaoReal' },
      { id: 23, t1: { name: 'RodGianini', seed: 27, score: 106.00 }, t2: { name: 'vilsonm', seed: 230, score: 117.30 }, winnerName: 'vilsonm' },
      { id: 24, t1: { name: 'WillPro', seed: 28, score: 121.50 }, t2: { name: 'BrHorse', seed: 229, score: 88.66 }, winnerName: 'WillPro' },
      { id: 25, t1: { name: 'volnandy', seed: 29, score: 134.40 }, t2: { name: 'Los llamas', seed: 228, score: 128.70 }, winnerName: 'volnandy' },
      { id: 26, t1: { name: 'Seahawks LC', seed: 30, score: 102.48 }, t2: { name: 'Green Bay Diamonds', seed: 227, score: 119.14 }, winnerName: 'Green Bay Diamonds' },
      { id: 27, t1: { name: 'cardosoo', seed: 31, score: 97.40 }, t2: { name: 'Love Thy Nabers', seed: 226, score: 150.94 }, winnerName: 'Love Thy Nabers' },
      { id: 28, t1: { name: 'frostzx', seed: 32, score: 155.60 }, t2: { name: 'BernardoMachado', seed: 225, score: 140.46 }, winnerName: 'frostzx' },
      { id: 29, t1: { name: 'FlaFalcons', seed: 33, score: 126.88 }, t2: { name: 'mathiascblc', seed: 224, score: 124.74 }, winnerName: 'FlaFalcons' },
      { id: 30, t1: { name: 'joaosandin', seed: 34, score: 85.94 }, t2: { name: 'Eduardocfilho', seed: 223, score: 90.68 }, winnerName: 'Eduardocfilho' },
      { id: 31, t1: { name: 'RESPIRAÇÃO TOUCHDOWN', seed: 35, score: 144.00 }, t2: { name: 'Exit light, enter night!', seed: 222, score: 66.84 }, winnerName: 'RESPIRAÇÃO TOUCHDOWN' },
      { id: 32, t1: { name: 'SaintsJP', seed: 36, score: 130.34 }, t2: { name: 'Eduhenri', seed: 221, score: 113.24 }, winnerName: 'SaintsJP' }
    ],
    2: [
      { id: 201, t1: { name: 'American Bulldogs', seed: 1, score: 129.82 }, t2: { name: 'Explosion Raiders', seed: 128, score: 116.16 }, winnerName: 'American Bulldogs' },
      { id: 202, t1: { name: 'Genipabus Dromedarios', seed: 2, score: 110.72 }, t2: { name: 'Ghost of Soteropolis', seed: 127, score: 82.08 }, winnerName: 'Genipabus Dromedarios' },
      { id: 203, t1: { name: 'pedrotti', seed: 3, score: 124.32 }, t2: { name: 'pipito', seed: 126, score: 111.68 }, winnerName: 'pedrotti' },
      { id: 204, t1: { name: 'Butt Fumble', seed: 4, score: 108.08 }, t2: { name: 'MAGRELÃO BLUEDOGS', seed: 132, score: 99.32 }, winnerName: 'Butt Fumble' },
      { id: 205, t1: { name: 'DGlad', seed: 5, score: 129.82 }, t2: { name: 'Santástico da NFL', seed: 133, score: 65.26 }, winnerName: 'DGlad' },
      { id: 206, t1: { name: 'Inno9', seed: 6, score: 103.52 }, t2: { name: 'Deflategreats FC', seed: 134, score: 94.72 }, winnerName: 'Inno9' },
      { id: 207, t1: { name: 'Green frogs', seed: 7, score: 120.82 }, t2: { name: 'Lambeaughini', seed: 135, score: 91.74 }, winnerName: 'Green frogs' },
      { id: 208, t1: { name: 'Kobawsk', seed: 249, score: 112.26 }, t2: { name: 'In AR we trust', seed: 136, score: 149.02 }, winnerName: 'In AR we trust' },
      { id: 209, t1: { name: 'Lunatkicks', seed: 9, score: 126.64 }, t2: { name: 'LeandroNS', seed: 120, score: 105.26 }, winnerName: 'Lunatkicks' },
      { id: 210, t1: { name: 'Real Garruchos F.C', seed: 10, score: 102.02 }, t2: { name: 'DS Valhalla', seed: 119, score: 83.62 }, winnerName: 'Real Garruchos F.C' },
      { id: 211, t1: { name: 'jetro50', seed: 11, score: 84.60 }, t2: { name: 'HeidlonG', seed: 139, score: 118.44 }, winnerName: 'HeidlonG' },
      { id: 212, t1: { name: 'DeflateKing', seed: 12, score: 108.68 }, t2: { name: 'Green Bay Lakers', seed: 140, score: 134.42 }, winnerName: 'Green Bay Lakers' },
      { id: 213, t1: { name: 'Leitinho Dolphins', seed: 13, score: 122.22 }, t2: { name: 'SaloMAYE', seed: 116, score: 109.32 }, winnerName: 'Leitinho Dolphins' },
      { id: 214, t1: { name: 'Sirigaita', seed: 243, score: 93.38 }, t2: { name: 'FelipePatriots', seed: 115, score: 111.26 }, winnerName: 'FelipePatriots' },
      { id: 215, t1: { name: 'Denver Donkeys', seed: 242, score: 106.52 }, t2: { name: 'ThomasM3l00', seed: 114, score: 119.22 }, winnerName: 'ThomasM3l00' },
      { id: 216, t1: { name: 'FC Chucruts', seed: 241, score: 103.34 }, t2: { name: 'osmar', seed: 144, score: 111.56 }, winnerName: 'osmar' },
      { id: 217, t1: { name: 'ライオンズ', seed: 17, score: 106.98 }, t2: { name: 'Sporting Braunschweig', seed: 145, score: 116.32 }, winnerName: 'Sporting Braunschweig' },
      { id: 218, t1: { name: 'vagnercf', seed: 239, score: 138.76 }, t2: { name: 'Samurais de olhos Azuis', seed: 146, score: 116.46 }, winnerName: 'vagnercf' },
      { id: 219, t1: { name: 'KFC Kings', seed: 238, score: 142.24 }, t2: { name: 'Texão da Massa', seed: 110, score: 92.42 }, winnerName: 'KFC Kings' },
      { id: 220, t1: { name: 'beu128', seed: 20, score: 95.42 }, t2: { name: 'Planet Hampton', seed: 148, score: 121.12 }, winnerName: 'Planet Hampton' },
      { id: 221, t1: { name: 'Angeloni99', seed: 236, score: 68.36 }, t2: { name: 'North East Harpy', seed: 108, score: 62.92 }, winnerName: 'Angeloni99' },
      { id: 222, t1: { name: 'Viúvo do Brady', seed: 235, score: 103.62 }, t2: { name: 'Borgo Hawks', seed: 107, score: 109.56 }, winnerName: 'Borgo Hawks' },
      { id: 223, t1: { name: 'Old No. 7th Round Picks', seed: 23, score: 115.42 }, t2: { name: 'Coltsquest', seed: 151, score: 76.58 }, winnerName: 'Old No. 7th Round Picks' },
      { id: 224, t1: { name: 'Verdigris Calamities', seed: 24, score: 102.66 }, t2: { name: 'Lesio9ers', seed: 105, score: 79.88 }, winnerName: 'Verdigris Calamities' },
      { id: 225, t1: { name: 'Melca7', seed: 25, score: 99.44 }, t2: { name: 'POA Klingons', seed: 104, score: 91.46 }, winnerName: 'Melca7' },
      { id: 226, t1: { name: 'FalcaoReal', seed: 26, score: 142.02 }, t2: { name: 'Hijos de Rivers', seed: 103, score: 147.22 }, winnerName: 'Hijos de Rivers' },
      { id: 227, t1: { name: 'vilsonm', seed: 230, score: 73.28 }, t2: { name: 'Carneiros Felpudos', seed: 155, score: 112.82 }, winnerName: 'Carneiros Felpudos' },
      { id: 228, t1: { name: 'WillPro', seed: 28, score: 103.62 }, t2: { name: 'Corvos Caolhos', seed: 101, score: 101.66 }, winnerName: 'WillPro' },
      { id: 229, t1: { name: 'volnandy', seed: 29, score: 111.52 }, t2: { name: 'Brazilian Colts', seed: 157, score: 100.32 }, winnerName: 'volnandy' },
      { id: 230, t1: { name: 'Green Bay Diamonds', seed: 227, score: 84.12 }, t2: { name: 'AleZucco', seed: 158, score: 131.12 }, winnerName: 'AleZucco' },
      { id: 231, t1: { name: 'Love Thy Nabers', seed: 226, score: 93.62 }, t2: { name: 'Quack Attack', seed: 98, score: 123.72 }, winnerName: 'Quack Attack' },
      { id: 232, t1: { name: 'frostzx', seed: 32, score: 144.52 }, t2: { name: 'Maringá Fans', seed: 160, score: 95.72 }, winnerName: 'frostzx' },
      { id: 233, t1: { name: 'FlaFalcons', seed: 33, score: 88.20 }, t2: { name: 'AlisonBecker', seed: 161, score: 117.52 }, winnerName: 'AlisonBecker' },
      { id: 234, t1: { name: 'Eduardocfilho', seed: 223, score: 98.92 }, t2: { name: 'SipansBr', seed: 162, score: 91.58 }, winnerName: 'Eduardocfilho' },
      { id: 235, t1: { name: 'Marau Bitu', seed: 163, score: 118.56 }, t2: { name: 'RESPIRAÇÃO TOUCHDOWN', seed: 35, score: 94.82 }, winnerName: 'Marau Bitu' },
      { id: 236, t1: { name: 'SaintsJP', seed: 36, score: 80.84 }, t2: { name: 'AndreLimas', seed: 164, score: 77.48 }, winnerName: 'SaintsJP' },
      { id: 237, t1: { name: '“MaHomies”', seed: 220, score: 128.76 }, t2: { name: 'JoaoElGringo', seed: 92, score: 97.72 }, winnerName: '“MaHomies”' },
      { id: 238, t1: { name: 'GaloMG', seed: 38, score: 112.14 }, t2: { name: 'RafaelKoehler', seed: 91, score: 96.76 }, winnerName: 'GaloMG' },
      { id: 239, t1: { name: 'MateusThomazini', seed: 39, score: 89.62 }, t2: { name: 'Claudianosilva', seed: 90, score: 125.22 }, winnerName: 'Claudianosilva' },
      { id: 240, t1: { name: 'Àlumani', seed: 40, score: 132.94 }, t2: { name: 'Giants Suzano', seed: 89, score: 96.46 }, winnerName: 'Àlumani' },
      { id: 241, t1: { name: 'RegisCarrara', seed: 216, score: 109.62 }, t2: { name: 'Rictus FC', seed: 169, score: 110.44 }, winnerName: 'Rictus FC' },
      { id: 242, t1: { name: 'Last but not least', seed: 42, score: 101.12 }, t2: { name: 'Salimporto', seed: 87, score: 145.14 }, winnerName: 'Salimporto' },
      { id: 243, t1: { name: 'Mamutes do Cerrado', seed: 43, score: 125.62 }, t2: { name: 'Flessakianos', seed: 86, score: 146.22 }, winnerName: 'Flessakianos' },
      { id: 244, t1: { name: 'migliorinisa', seed: 44, score: 93.12 }, t2: { name: 'yasminfariadias', seed: 172, score: 113.36 }, winnerName: 'yasminfariadias' },
      { id: 245, t1: { name: 'Cyber Rats', seed: 45, score: 120.44 }, t2: { name: 'Urubroncos FC', seed: 173, score: 103.64 }, winnerName: 'Cyber Rats' },
      { id: 246, t1: { name: 'KauEdelman11', seed: 211, score: 94.28 }, t2: { name: 'AndreBruz', seed: 83, score: 119.64 }, winnerName: 'AndreBruz' },
      { id: 247, t1: { name: 'Blitz do Chama', seed: 210, score: 133.32 }, t2: { name: 'ThiagoW', seed: 175, score: 90.26 }, winnerName: 'Blitz do Chama' }
    ],
    3: [
      { id: 301, t1: { name: 'American Bulldogs', seed: 1, score: 132.54 }, t2: { name: 'AlisonBecker', seed: 161, score: 151.34 }, winnerName: 'AlisonBecker' },
      { id: 302, t1: { name: 'Genipabus Dromedarios', seed: 2, score: 129.06 }, t2: { name: 'Eduardocfilho', seed: 223, score: 145.98 }, winnerName: 'Eduardocfilho' },
      { id: 303, t1: { name: 'pedrotti', seed: 3, score: 157.32 }, t2: { name: 'Marau Bitu', seed: 163, score: 111.90 }, winnerName: 'pedrotti' },
      { id: 304, t1: { name: 'Butt Fumble', seed: 4, score: 131.04 }, t2: { name: 'SaintsJP', seed: 36, score: 79.38 }, winnerName: 'Butt Fumble' },
      { id: 305, t1: { name: 'DGlad', seed: 5, score: 109.16 }, t2: { name: '“MaHomies”', seed: 220, score: 124.90 }, winnerName: '“MaHomies”' },
      { id: 306, t1: { name: 'Inno9', seed: 6, score: 100.88 }, t2: { name: 'GaloMG', seed: 38, score: 156.30 }, winnerName: 'GaloMG' },
      { id: 307, t1: { name: 'Green frogs', seed: 7, score: 114.22 }, t2: { name: 'Claudianosilva', seed: 90, score: 128.38 }, winnerName: 'Claudianosilva' },
      { id: 308, t1: { name: 'In AR we trust', seed: 136, score: 93.78 }, t2: { name: 'Àlumani', seed: 40, score: 101.60 }, winnerName: 'Àlumani' },
      { id: 309, t1: { name: 'Lunatkicks', seed: 9, score: 100.70 }, t2: { name: 'Rictus FC', seed: 169, score: 107.90 }, winnerName: 'Rictus FC' },
      { id: 310, t1: { name: 'Real Garruchos F.C', seed: 10, score: 97.86 }, t2: { name: 'Salimporto', seed: 87, score: 105.80 }, winnerName: 'Salimporto' },
      { id: 311, t1: { name: 'HeidlonG', seed: 139, score: 151.20 }, t2: { name: 'Flessakianos', seed: 86, score: 129.14 }, winnerName: 'HeidlonG' },
      { id: 312, t1: { name: 'Green Bay Lakers', seed: 140, score: 101.68 }, t2: { name: 'yasminfariadias', seed: 172, score: 91.50 }, winnerName: 'Green Bay Lakers' },
      { id: 313, t1: { name: 'Leitinho Dolphins', seed: 13, score: 144.28 }, t2: { name: 'Cyber Rats', seed: 45, score: 81.16 }, winnerName: 'Leitinho Dolphins' },
      { id: 314, t1: { name: 'FelipePatriots', seed: 115, score: 75.40 }, t2: { name: 'AndreBruz', seed: 83, score: 72.50 }, winnerName: 'FelipePatriots' },
      { id: 315, t1: { name: 'ThomasM3l00', seed: 114, score: 124.88 }, t2: { name: 'Blitz do Chama', seed: 210, score: 131.14 }, winnerName: 'Blitz do Chama' },
      { id: 316, t1: { name: 'osmar', seed: 144, score: 97.80 }, t2: { name: 'LucasKP', seed: 176, score: 110.98 }, winnerName: 'LucasKP' },
      { id: 317, t1: { name: 'Sporting Braunschweig', seed: 145, score: 111.06 }, t2: { name: 'LucasPFerreira', seed: 80, score: 102.92 }, winnerName: 'Sporting Braunschweig' },
      { id: 318, t1: { name: 'vagnercf', seed: 239, score: 121.20 }, t2: { name: 'Bragil', seed: 79, score: 112.82 }, winnerName: 'vagnercf' },
      { id: 319, t1: { name: 'KFC Kings', seed: 238, score: 94.70 }, t2: { name: 'Lutfi Lycans', seed: 179, score: 123.24 }, winnerName: 'Lutfi Lycans' },
      { id: 320, t1: { name: 'Planet Hampton', seed: 148, score: 133.44 }, t2: { name: 'Redskins RS', seed: 52, score: 100.26 }, winnerName: 'Planet Hampton' },
      { id: 321, t1: { name: 'Angeloni99', seed: 236, score: 94.30 }, t2: { name: 'Kaepernick squad', seed: 204, score: 135.12 }, winnerName: 'Kaepernick squad' },
      { id: 322, t1: { name: 'Borgo Hawks', seed: 107, score: 121.80 }, t2: { name: 'Henry’s Kingdom', seed: 75, score: 86.18 }, winnerName: 'Borgo Hawks' },
      { id: 323, t1: { name: 'Old No. 7th Round Picks', seed: 23, score: 95.16 }, t2: { name: 'SiaraBigheads', seed: 55, score: 137.56 }, winnerName: 'SiaraBigheads' },
      { id: 324, t1: { name: 'Verdigris Calamities', seed: 24, score: 132.26 }, t2: { name: 'Vulgo Malvadão', seed: 184, score: 108.28 }, winnerName: 'Verdigris Calamities' },
      { id: 325, t1: { name: 'Melca7', seed: 25, score: 111.50 }, t2: { name: 'Zorzella', seed: 200, score: 108.48 }, winnerName: 'Melca7' },
      { id: 326, t1: { name: 'Hijos de Rivers', seed: 103, score: 128.16 }, t2: { name: 'AaronFavre', seed: 58, score: 98.80 }, winnerName: 'Hijos de Rivers' },
      { id: 327, t1: { name: 'Carneiros Felpudos', seed: 155, score: 125.66 }, t2: { name: 'Reds disfarçados', seed: 198, score: 115.56 }, winnerName: 'Carneiros Felpudos' },
      { id: 328, t1: { name: 'WillPro', seed: 28, score: 96.86 }, t2: { name: 'Ué', seed: 69, score: 78.32 }, winnerName: 'WillPro' }
    ],
    4: [
      { id: 401, t1: { name: 'AlisonBecker', seed: 161, score: 105.32 }, t2: { name: 'Sporting Braunschweig', seed: 145, score: 131.14 }, winnerName: 'Sporting Braunschweig' },
      { id: 402, t1: { name: 'Eduardocfilho', seed: 223, score: 99.84 }, t2: { name: 'vagnercf', seed: 239, score: 86.50 }, winnerName: 'Eduardocfilho' },
      { id: 403, t1: { name: 'pedrotti', seed: 3, score: 96.52 }, t2: { name: 'Lutfi Lycans', seed: 179, score: 97.38 }, winnerName: 'Lutfi Lycans' },
      { id: 404, t1: { name: 'Butt Fumble', seed: 4, score: 131.02 }, t2: { name: 'Planet Hampton', seed: 148, score: 78.48 }, winnerName: 'Butt Fumble' },
      { id: 405, t1: { name: '“MaHomies”', seed: 220, score: 121.44 }, t2: { name: 'Kaepernick squad', seed: 204, score: 116.34 }, winnerName: '“MaHomies”' },
      { id: 406, t1: { name: 'GaloMG', seed: 38, score: 90.60 }, t2: { name: 'Borgo Hawks', seed: 107, score: 128.50 }, winnerName: 'Borgo Hawks' },
      { id: 407, t1: { name: 'Claudianosilva', seed: 90, score: 167.52 }, t2: { name: 'SiaraBigheads', seed: 55, score: 106.22 }, winnerName: 'Claudianosilva' },
      { id: 408, t1: { name: 'Àlumani', seed: 40, score: 86.10 }, t2: { name: 'Verdigris Calamities', seed: 24, score: 113.56 }, winnerName: 'Verdigris Calamities' },
      { id: 409, t1: { name: 'Rictus FC', seed: 169, score: 108.60 }, t2: { name: 'Melca7', seed: 25, score: 77.70 }, winnerName: 'Rictus FC' },
      { id: 410, t1: { name: 'Salimporto', seed: 87, score: 84.32 }, t2: { name: 'Hijos de Rivers', seed: 103, score: 133.74 }, winnerName: 'Hijos de Rivers' },
      { id: 411, t1: { name: 'HeidlonG', seed: 139, score: 103.20 }, t2: { name: 'Carneiros Felpudos', seed: 155, score: 100.76 }, winnerName: 'HeidlonG' },
      { id: 412, t1: { name: 'Green Bay Lakers', seed: 140, score: 98.62 }, t2: { name: 'WillPro', seed: 28, score: 151.76 }, winnerName: 'WillPro' },
      { id: 413, t1: { name: 'Leitinho Dolphins', seed: 13, score: 91.50 }, t2: { name: 'FELIPERAMS', seed: 68, score: 91.82 }, winnerName: 'FELIPERAMS' },
      { id: 414, t1: { name: 'FelipePatriots', seed: 115, score: 128.14 }, t2: { name: 'AleZucco', seed: 158, score: 102.80 }, winnerName: 'FelipePatriots' },
      { id: 415, t1: { name: 'Blitz do Chama', seed: 210, score: 140.22 }, t2: { name: 'Quack Attack', seed: 98, score: 130.18 }, winnerName: 'Blitz do Chama' },
      { id: 416, t1: { name: 'LucasKP', seed: 176, score: 65.50 }, t2: { name: 'frostzx', seed: 32, score: 145.22 }, winnerName: 'frostzx' }
    ],
    5: [
      { id: 501, t1: { name: 'Sporting Braunschweig', seed: 145, score: 112.40 }, t2: { name: 'Rictus FC', seed: 169, score: 114.22 }, winnerName: 'Rictus FC' },
      { id: 502, t1: { name: 'Eduardocfilho', seed: 223, score: 85.36 }, t2: { name: 'Hijos de Rivers', seed: 103, score: 116.70 }, winnerName: 'Hijos de Rivers' },
      { id: 503, t1: { name: 'Lutfi Lycans', seed: 179, score: 100.26 }, t2: { name: 'HeidlonG', seed: 139, score: 138.34 }, winnerName: 'HeidlonG' },
      { id: 504, t1: { name: 'Butt Fumble', seed: 4, score: 106.44 }, t2: { name: 'WillPro', seed: 28, score: 95.64 }, winnerName: 'Butt Fumble' },
      { id: 505, t1: { name: '“MaHomies”', seed: 220, score: 119.38 }, t2: { name: 'FELIPERAMS', seed: 68, score: 107.84 }, winnerName: '“MaHomies”' },
      { id: 506, t1: { name: 'Borgo Hawks', seed: 107, score: 117.10 }, t2: { name: 'FelipePatriots', seed: 115, score: 78.38 }, winnerName: 'Borgo Hawks' },
      { id: 507, t1: { name: 'Claudianosilva', seed: 90, score: 112.56 }, t2: { name: 'Blitz do Chama', seed: 210, score: 97.16 }, winnerName: 'Claudianosilva' },
      { id: 508, t1: { name: 'Verdigris Calamities', seed: 24, score: 91.46 }, t2: { name: 'frostzx', seed: 32, score: 88.04 }, winnerName: 'Verdigris Calamities' }
    ],
    6: [
      { id: 601, t1: { name: 'Rictus FC', seed: 169, score: 109.18 }, t2: { name: '“MaHomies”', seed: 220, score: 101.34 }, winnerName: 'Rictus FC' },
      { id: 602, t1: { name: 'Hijos de Rivers', seed: 103, score: 150.06 }, t2: { name: 'Borgo Hawks', seed: 107, score: 86.12 }, winnerName: 'Hijos de Rivers' },
      { id: 603, t1: { name: 'HeidlonG', seed: 139, score: 132.24 }, t2: { name: 'Claudianosilva', seed: 90, score: 129.84 }, winnerName: 'HeidlonG' },
      { id: 604, t1: { name: 'Butt Fumble', seed: 4, score: 166.14 }, t2: { name: 'Verdigris Calamities', seed: 24, score: 93.36 }, winnerName: 'Butt Fumble' }
    ],
    7: [
      { id: 701, t1: { name: 'Rictus FC', seed: 169, score: 93.20 }, t2: { name: 'HeidlonG', seed: 139, score: 99.46 }, winnerName: 'HeidlonG' },
      { id: 702, t1: { name: 'Hijos de Rivers', seed: 103, score: 124.52 }, t2: { name: 'Butt Fumble', seed: 4, score: 80.12 }, winnerName: 'Hijos de Rivers' }
    ],
    8: [
      { id: 801, t1: { name: 'Rictus FC', seed: 169, score: 115.40 }, t2: { name: 'Butt Fumble', seed: 4, score: 93.72 }, winnerName: 'Rictus FC' }
    ],
    9: [
      { id: 901, t1: { name: 'HeidlonG', seed: 139, score: 99.00 }, t2: { name: 'Hijos de Rivers', seed: 103, score: 115.72 }, winnerName: 'Hijos de Rivers' }
    ]
  };

  const currentRoundMatches = useMemo(() => {
    return STATIC_BRACKET[activeRoundTab] || [];
  }, [activeRoundTab]);

  const filteredMatches = useMemo(() => {
    if (!searchTerm) return currentRoundMatches;
    const lower = searchTerm.toLowerCase();
    return currentRoundMatches.filter(m => 
      m.t1.name.toLowerCase().includes(lower) || 
      m.t2.name.toLowerCase().includes(lower)
    );
  }, [currentRoundMatches, searchTerm]);

  return (
    <div className="min-h-screen bg-[#0a0f1d] text-slate-200">
      {/* Header */}
      <header className="bg-[#1e293b]/50 backdrop-blur-xl border-b border-white/5 sticky top-0 z-[100]">
        <div className="max-w-4xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full text-slate-500 hover:text-white transition-all">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-black text-white italic uppercase tracking-tighter leading-none">Playoffs Challenge</h1>
              <p className="text-[10px] font-bold text-yellow-500 uppercase tracking-widest mt-1">Torneio Consolidado 2025</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-yellow-500/10 border border-yellow-500/20 rounded-full">
            <Flame className="w-3 h-3 text-yellow-500" />
            <span className="text-[8px] font-black text-yellow-500 uppercase tracking-widest">Live Updates</span>
          </div>
        </div>

        <nav className="max-w-4xl mx-auto px-6 flex items-center gap-4 overflow-x-auto no-scrollbar pb-2">
          {roundsInfo.map(round => (
            <button
              key={round.id}
              onClick={() => setActiveRoundTab(round.id)}
              className={`flex flex-col items-center min-w-[100px] px-4 py-3 border-b-2 transition-all ${
                activeRoundTab === round.id 
                ? 'border-yellow-500 text-yellow-500 bg-yellow-500/5' 
                : 'border-transparent text-slate-500 hover:text-slate-300'
              }`}
            >
              <span className="text-[10px] font-black uppercase tracking-widest whitespace-nowrap">{round.label}</span>
              <span className="text-[8px] font-bold opacity-50 uppercase whitespace-nowrap">{round.desc}</span>
            </button>
          ))}
        </nav>
      </header>

      <main className="max-w-4xl mx-auto p-6 space-y-8 pb-32">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input 
            type="text" 
            placeholder="Buscar por equipe no mata-mata..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#1e293b]/40 border border-white/5 rounded-2xl pl-12 pr-6 py-4 text-sm text-white focus:border-yellow-500 outline-none transition-all"
          />
        </div>

        {/* Matches Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-500">
          {loadingMapping && (
            <div className="col-span-full py-20 text-center flex flex-col items-center gap-4">
              <RefreshCw className="w-10 h-10 text-yellow-500 animate-spin" />
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Cruzando dados de managers...</p>
            </div>
          )}

          {!loadingMapping && filteredMatches.length > 0 ? (
            filteredMatches.map((match) => {
              const info1 = getManagerInfo(match.t1.name);
              const info2 = getManagerInfo(match.t2.name);
              
              return (
                <div key={match.id} className="bg-[#1e293b]/30 border border-white/5 rounded-3xl overflow-hidden hover:border-yellow-500/20 transition-all group relative">
                  <div className="absolute top-0 left-0 w-1 h-full bg-slate-800 group-hover:bg-yellow-500 transition-colors"></div>
                  
                  <div className="p-6 space-y-4">
                    {/* Team 1 */}
                    <div className={`flex items-center justify-between gap-4 ${match.winnerName === match.t1.name ? 'opacity-100' : 'opacity-40'}`}>
                      <div className="flex items-center gap-3 overflow-hidden">
                        <div className="relative shrink-0">
                          <img 
                            src={getAvatarUrl(info1.avatar)} 
                            className={`w-10 h-10 rounded-full border-2 ${match.winnerName === match.t1.name ? 'border-yellow-500' : 'border-slate-800'}`} 
                            alt="" 
                          />
                          <span className="absolute -bottom-1 -right-1 bg-slate-900 text-[7px] font-black text-white px-1 py-0.5 rounded border border-white/10">#{match.t1.seed}</span>
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span className="text-xs font-bold text-white truncate leading-tight">{match.t1.name}</span>
                          <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest truncate">@{info1.username}</span>
                        </div>
                      </div>
                      <div className={`text-xl font-black italic tracking-tighter ${match.winnerName === match.t1.name ? 'text-yellow-500' : 'text-slate-600'}`}>
                        {match.t1.score.toFixed(2)}
                      </div>
                    </div>

                    <div className="flex items-center gap-4 px-2">
                      <div className="h-[1px] flex-1 bg-white/5"></div>
                      <span className="text-[8px] font-black text-slate-700 italic">VS</span>
                      <div className="h-[1px] flex-1 bg-white/5"></div>
                    </div>

                    {/* Team 2 */}
                    <div className={`flex items-center justify-between gap-4 ${match.winnerName === match.t2.name ? 'opacity-100' : 'opacity-40'}`}>
                      <div className="flex items-center gap-3 overflow-hidden">
                        <div className="relative shrink-0">
                          <img 
                            src={getAvatarUrl(info2.avatar)} 
                            className={`w-10 h-10 rounded-full border-2 ${match.winnerName === match.t2.name ? 'border-yellow-500' : 'border-slate-800'}`} 
                            alt="" 
                          />
                          <span className="absolute -bottom-1 -right-1 bg-slate-900 text-[7px] font-black text-white px-1 py-0.5 rounded border border-white/10">#{match.t2.seed}</span>
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span className="text-xs font-bold text-white truncate leading-tight">{match.t2.name}</span>
                          <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest truncate">@{info2.username}</span>
                        </div>
                      </div>
                      <div className={`text-xl font-black italic tracking-tighter ${match.winnerName === match.t2.name ? 'text-yellow-500' : 'text-slate-600'}`}>
                        {match.t2.score.toFixed(2)}
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 px-6 py-2 flex items-center justify-between">
                    <span className="text-[8px] font-black text-yellow-500 uppercase tracking-[0.2em] italic">Vencedor: {match.winnerName}</span>
                    {info1.isPending || info2.isPending ? <ShieldCheck className="w-3 h-3 text-slate-700" /> : <ShieldCheck className="w-3 h-3 text-blue-500" />}
                  </div>
                </div>
              );
            })
          ) : (
            !loadingMapping && (
              <div className="col-span-full py-20 text-center bg-white/5 rounded-[2rem] border border-dashed border-white/10">
                <AlertCircle className="w-10 h-10 text-slate-700 mx-auto mb-4 opacity-20" />
                <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Nenhum confronto encontrado.</p>
              </div>
            )
          )}
        </div>
      </main>

      <footer className="fixed bottom-0 left-0 w-full bg-[#0a0f1d]/95 backdrop-blur-md border-t border-white/[0.05] py-5 px-6 z-50">
        <div className="max-w-4xl mx-auto flex items-center justify-between text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] italic">
           <div className="flex items-center gap-3 text-yellow-500">
             <Trophy className="w-4 h-4" />
             <span>FWL Playoffs Challenge • High-Fidelity Data Engine v2.0</span>
           </div>
           <span>Tournament Explorer • Series 2025</span>
        </div>
      </footer>
    </div>
  );
};

export default PlayoffsChallenge;