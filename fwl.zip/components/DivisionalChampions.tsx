
import React, { useState, useEffect, useCallback } from 'react';
import { fetchLeagueData, fetchMatchupsForWeek, getAvatarUrl } from '../services/sleeper';
import { User, Roster, Matchup } from '../types';
import { 
  Trophy, 
  ArrowLeft, 
  Medal, 
  RefreshCw, 
  ShieldCheck,
  Award,
  Crown,
  AlertTriangle,
  CheckCircle2,
  Circle
} from 'lucide-react';

interface DivisionalChampionsProps {
  leagues: { id: string, name: string, avatar: string | null }[];
  onBack: () => void;
}

interface TeamScore {
  rosterId: number;
  user: User | undefined;
  points: number;
}

interface LeagueMatchups {
  leagueId: string;
  leagueName: string;
  leagueAvatar: string | null;
  final: { t1: TeamScore; t2: TeamScore };
  thirdPlace: { t1: TeamScore; t2: TeamScore } | null;
}

interface UserChoice {
  finalWinnerId: number | null;
  thirdWinnerId: number | null;
}

const DivisionalChampions: React.FC<DivisionalChampionsProps> = ({ leagues, onBack }) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [leaguesMatches, setLeaguesMatches] = useState<LeagueMatchups[]>([]);
  const [choices, setChoices] = useState<Record<string, UserChoice>>({});
  const [errorCount, setErrorCount] = useState(0);

  const loadData = useCallback(async () => {
    setLoading(true);
    const results: LeagueMatchups[] = [];
    
    const divLeagues = leagues.filter(l => 
      l.name.toLowerCase().includes('divis') || 
      l.name.toLowerCase().includes('league') ||
      /d[1-4]/i.test(l.name)
    );

    try {
      for (let i = 0; i < divLeagues.length; i++) {
        const leagueRef = divLeagues[i];
        setProgress(Math.round(((i + 1) / divLeagues.length) * 100));
        
        try {
          const { league, rosters, users, winnersBracket } = await fetchLeagueData(leagueRef.id);
          const w17Matchups = await fetchMatchupsForWeek(leagueRef.id, 17).catch(() => []);
          
          if (!winnersBracket || winnersBracket.length === 0) continue;

          const champNode = winnersBracket.find(m => m.p === 1);
          const thirdNode = winnersBracket.find(m => m.p === 3);

          if (!champNode || !champNode.t1 || !champNode.t2) continue;

          const getTeamScore = (rosterId: number | null): TeamScore => {
            const roster = rosters.find(r => r.roster_id === rosterId);
            const user = users.find(u => u.user_id === roster?.owner_id);
            const match = w17Matchups.find(m => m.roster_id === rosterId);
            return {
              rosterId: rosterId || 0,
              user,
              points: match?.points || 0
            };
          };

          const leagueMatch: LeagueMatchups = {
            leagueId: leagueRef.id,
            leagueName: league.name.split(' - ').pop() || league.name,
            leagueAvatar: league.avatar,
            final: {
              t1: getTeamScore(champNode.t1),
              t2: getTeamScore(champNode.t2)
            },
            thirdPlace: (thirdNode && thirdNode.t1 && thirdNode.t2) ? {
              t1: getTeamScore(thirdNode.t1),
              t2: getTeamScore(thirdNode.t2)
            } : null
          };

          results.push(leagueMatch);
        } catch (e) {
          console.error(`Erro ao processar liga ${leagueRef.id}:`, e);
          setErrorCount(prev => prev + 1);
        }
      }
      
      setLeaguesMatches(results.sort((a, b) => a.leagueName.localeCompare(b.leagueName)));
    } catch (err) {
      console.error("Erro fatal ao carregar:", err);
    } finally {
      setLoading(false);
    }
  }, [leagues]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSelectWinner = (leagueId: string, type: 'final' | 'third', rosterId: number) => {
    setChoices(prev => {
      const current = prev[leagueId] || { finalWinnerId: null, thirdWinnerId: null };
      return {
        ...prev,
        [leagueId]: {
          ...current,
          [type === 'final' ? 'finalWinnerId' : 'thirdWinnerId']: rosterId
        }
      };
    });
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8">
        <div className="relative">
          <RefreshCw className="w-16 h-16 text-blue-500 animate-spin" />
          <div className="absolute inset-0 bg-blue-500/20 blur-xl rounded-full"></div>
        </div>
        <div className="text-center space-y-4">
          <h2 className="text-white font-black text-2xl uppercase tracking-[0.2em] italic">Preparando Arena de Decisão</h2>
          <div className="w-64 h-1.5 bg-white/5 rounded-full overflow-hidden mx-auto border border-white/10">
            <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${progress}%` }}></div>
          </div>
          <p className="text-slate-500 font-bold text-[10px] uppercase tracking-widest">{progress}% - Buscando Finalistas Semana 17</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-8 duration-500 pb-24">
      <div className="flex items-center justify-between sticky top-0 bg-[#0a0f1d]/90 backdrop-blur-xl p-4 -m-4 z-50 rounded-t-[3rem] border-b border-white/5">
        <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group">
          <div className="p-2 bg-white/5 rounded-full group-hover:-translate-x-1 transition-transform">
            <ArrowLeft className="w-5 h-5" />
          </div>
          <span className="text-xs font-black uppercase tracking-[0.2em]">Voltar</span>
        </button>
        <div className="text-right">
          <h2 className="text-xl font-black text-white uppercase tracking-tighter italic leading-none">Galeria de Campeões</h2>
          <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Temporada 2025 • Veredito Final</p>
        </div>
      </div>

      <div className="bg-blue-600/5 border border-blue-500/10 p-6 rounded-[2rem] flex items-center gap-6 shadow-xl mb-12">
        <div className="p-4 bg-blue-500/10 rounded-2xl border border-blue-500/20">
          <ShieldCheck className="w-8 h-8 text-blue-400" />
        </div>
        <div>
          <h4 className="text-xs font-black text-white uppercase tracking-widest mb-1">Painel de Coroação</h4>
          <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
            Selecione o vencedor de cada confronto da <strong className="text-white">Semana 17</strong> para montar o pódio oficial. 
            O pódio será gerado automaticamente assim que os vencedores forem marcados.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {leaguesMatches.map((l) => {
          const choice = choices[l.leagueId] || { finalWinnerId: null, thirdWinnerId: null };
          
          const first = choice.finalWinnerId === l.final.t1.rosterId ? l.final.t1 : (choice.finalWinnerId === l.final.t2.rosterId ? l.final.t2 : null);
          const second = choice.finalWinnerId === l.final.t1.rosterId ? l.final.t2 : (choice.finalWinnerId === l.final.t2.rosterId ? l.final.t1 : null);
          const third = l.thirdPlace ? (choice.thirdWinnerId === l.thirdPlace.t1.rosterId ? l.thirdPlace.t1 : (choice.thirdWinnerId === l.thirdPlace.t2.rosterId ? l.thirdPlace.t2 : null)) : null;

          return (
            <div key={l.leagueId} className="bg-[#1e293b]/20 border border-white/5 rounded-[3rem] overflow-hidden shadow-2xl flex flex-col relative group">
              {/* Header Liga */}
              <div className="p-6 bg-white/5 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-white/10 flex items-center justify-center overflow-hidden">
                    {l.leagueAvatar ? <img src={getAvatarUrl(l.leagueAvatar)} className="w-full h-full object-cover" alt="" /> : <Award className="w-6 h-6 text-blue-500" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-white uppercase italic tracking-tight">{l.leagueName}</h3>
                    <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Semana 17 Finalistas</p>
                  </div>
                </div>
                {first && second && (
                  <div className="px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full flex items-center gap-1.5">
                    <CheckCircle2 className="w-3 h-3 text-green-500" />
                    <span className="text-[8px] font-black text-green-500 uppercase">Definido</span>
                  </div>
                )}
              </div>

              <div className="p-6 space-y-8">
                {/* FINAL MATCHUP */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-[9px] font-black text-yellow-500 uppercase tracking-[0.2em] px-2">
                    <Crown className="w-3 h-3" /> Grande Final
                  </div>
                  <div className="grid grid-cols-1 gap-2">
                    {[l.final.t1, l.final.t2].map((team) => (
                      <button 
                        key={team.rosterId}
                        onClick={() => handleSelectWinner(l.leagueId, 'final', team.rosterId)}
                        className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${
                          choice.finalWinnerId === team.rosterId 
                          ? 'bg-yellow-500/10 border-yellow-500/50 shadow-[0_0_15px_rgba(234,179,8,0.1)]' 
                          : 'bg-white/5 border-white/5 hover:border-white/10'
                        }`}
                      >
                        <div className="flex items-center gap-4 text-left">
                          <img src={getAvatarUrl(team.user?.avatar || null)} className="w-10 h-10 rounded-full border-2 border-slate-800" alt="" />
                          <div>
                            <p className="text-sm font-bold text-white truncate max-w-[120px]">{team.user?.display_name || 'Manager'}</p>
                            <p className="text-[10px] font-mono text-slate-500">{team.points.toFixed(2)} pts</p>
                          </div>
                        </div>
                        {choice.finalWinnerId === team.rosterId ? <CheckCircle2 className="w-5 h-5 text-yellow-500" /> : <Circle className="w-5 h-5 text-slate-700" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* THIRD PLACE MATCHUP */}
                {l.thirdPlace && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-[9px] font-black text-orange-600 uppercase tracking-[0.2em] px-2">
                      <Medal className="w-3 h-3" /> Disputa de 3º Lugar
                    </div>
                    <div className="grid grid-cols-1 gap-2">
                      {[l.thirdPlace.t1, l.thirdPlace.t2].map((team) => (
                        <button 
                          key={team.rosterId}
                          onClick={() => handleSelectWinner(l.leagueId, 'third', team.rosterId)}
                          className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                            choice.thirdWinnerId === team.rosterId 
                            ? 'bg-orange-700/10 border-orange-700/50 shadow-[0_0_15px_rgba(194,65,12,0.1)]' 
                            : 'bg-white/5 border-white/5 hover:border-white/10'
                          }`}
                        >
                          <div className="flex items-center gap-3 text-left">
                            <img src={getAvatarUrl(team.user?.avatar || null)} className="w-8 h-8 rounded-full border border-slate-800" alt="" />
                            <div>
                              <p className="text-xs font-bold text-slate-300 truncate max-w-[100px]">{team.user?.display_name || 'Manager'}</p>
                              <p className="text-[9px] font-mono text-slate-600">{team.points.toFixed(2)} pts</p>
                            </div>
                          </div>
                          {choice.thirdWinnerId === team.rosterId ? <CheckCircle2 className="w-4 h-4 text-orange-600" /> : <Circle className="w-4 h-4 text-slate-800" />}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* PODIUM PREVIEW (ONLY SHOW IF FINAL IS SELECTED) */}
                {first && second && (
                  <div className="pt-6 border-t border-white/5 space-y-4 animate-in slide-in-from-top-2 duration-300">
                    <p className="text-[9px] font-black text-blue-500 uppercase tracking-widest text-center">Pódio Consolidado</p>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="bg-yellow-500/5 border border-yellow-500/10 rounded-2xl p-3 text-center">
                        <Trophy className="w-4 h-4 text-yellow-500 mx-auto mb-2" />
                        <p className="text-[7px] font-black text-yellow-500 uppercase">Campeão</p>
                        <p className="text-[10px] font-bold text-white truncate">{first.user?.display_name}</p>
                      </div>
                      <div className="bg-slate-400/5 border border-slate-400/10 rounded-2xl p-3 text-center">
                        <Medal className="w-4 h-4 text-slate-400 mx-auto mb-2" />
                        <p className="text-[7px] font-black text-slate-400 uppercase">Vice</p>
                        <p className="text-[10px] font-bold text-white truncate">{second.user?.display_name}</p>
                      </div>
                      <div className="bg-orange-700/5 border border-orange-700/10 rounded-2xl p-3 text-center">
                        <Medal className="w-4 h-4 text-orange-700 mx-auto mb-2" />
                        <p className="text-[7px] font-black text-orange-700 uppercase">3º Lugar</p>
                        <p className="text-[10px] font-bold text-white truncate">{third?.user?.display_name || 'TBD'}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {errorCount > 0 && (
        <div className="flex items-center gap-3 p-4 bg-red-500/5 border border-red-500/10 rounded-2xl text-red-500/60 text-[9px] font-bold uppercase tracking-widest">
          <AlertTriangle className="w-3 h-3" />
          {errorCount} ligas não puderam carregar os dados da W17.
        </div>
      )}
    </div>
  );
};

export default DivisionalChampions;
