
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { fetchLeagueData, fetchMatchupsForWeek, getAvatarUrl } from '../services/sleeper';
import { League, User, Matchup } from '../types';
import { 
  Trophy, 
  ChevronLeft, 
  Plus, 
  Minus, 
  Maximize,
  Target,
  Medal
} from 'lucide-react';

interface BradyPlayoffsProps {
  leagues: League[];
  onBack: () => void;
}

interface QualifiedTeam {
  roster_id: number;
  user: User | undefined;
  league_id: string;
  league_name: string;
  wins: number;
  fpts: number;
  league_rank: number;
  seed?: number;
}

interface MatchNode {
  t1: QualifiedTeam | undefined;
  t2: QualifiedTeam | undefined;
  winner: QualifiedTeam | undefined;
  p1: number;
  p2: number;
}

const BRACKET_HEIGHT = 2800; // Aumentado para 64 times

const BradyPlayoffs: React.FC<BradyPlayoffsProps> = ({ leagues, onBack }) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [qualifiedTeams, setQualifiedTeams] = useState<QualifiedTeam[]>([]);
  const [weeklyScores, setWeeklyScores] = useState<Record<string, Record<number, Record<number, number>>>>({}); 
  const [scale, setScale] = useState(0.4);
  const touchRef = useRef<{ dist: number | null }>({ dist: null });

  const loadAllData = useCallback(async () => {
    setLoading(true);
    try {
      const rankPools: Record<number, QualifiedTeam[]> = { 1: [], 2: [], 3: [], 4: [] };
      const scoresMap: Record<string, Record<number, Record<number, number>>> = {};

      for (let i = 0; i < leagues.length; i++) {
        const league = leagues[i];
        setProgress(Math.round(((i + 1) / leagues.length) * 100));
        const { rosters, users, league: leagueInfo } = await fetchLeagueData(league.league_id);
        
        const stats: Record<number, { wins: number, fpts: number }> = {};
        rosters.forEach(r => stats[r.roster_id] = { wins: 0, fpts: 0 });

        const weekPromises = [];
        // Semana 1-11 para ranking
        for (let w = 1; w <= 11; w++) weekPromises.push(fetchMatchupsForWeek(league.league_id, w).catch(() => []));
        // Semana 12-17 para playoffs
        for (let w = 12; w <= 17; w++) weekPromises.push(fetchMatchupsForWeek(league.league_id, w).then(m => ({ week: w, matchups: m })).catch(() => ({ week: w, matchups: [] })));
        
        const results = await Promise.all(weekPromises);
        results.forEach((res: any) => {
          if (Array.isArray(res)) {
            const pairs: Record<number, any[]> = {};
            res.forEach(m => {
              if (!pairs[m.matchup_id]) pairs[m.matchup_id] = [];
              pairs[m.matchup_id].push(m);
              if (stats[m.roster_id]) stats[m.roster_id].fpts += m.points;
            });
            Object.values(pairs).forEach(p => {
              if (p.length === 2) {
                const [t1, t2] = p;
                if (t1.points > t2.points) stats[t1.roster_id].wins++;
                else if (t2.points > t1.points) stats[t2.roster_id].wins++;
              }
            });
          } else if (res.week >= 12) {
            if (!scoresMap[league.league_id]) scoresMap[league.league_id] = {};
            res.matchups.forEach((m: Matchup) => {
              if (!scoresMap[league.league_id][m.roster_id]) scoresMap[league.league_id][m.roster_id] = {};
              scoresMap[league.league_id][m.roster_id][res.week] = m.points;
            });
          }
        });

        const sorted = [...rosters].sort((a, b) => {
          const sA = stats[a.roster_id];
          const sB = stats[b.roster_id];
          if (sB.wins !== sA.wins) return sB.wins - sA.wins;
          return sB.fpts - sA.fpts;
        });

        sorted.forEach((r, idx) => {
          const rank = idx + 1;
          if (rank <= 4) { 
            const user = users.find(u => u.user_id === r.owner_id);
            if (!rankPools[rank]) rankPools[rank] = [];
            rankPools[rank].push({
              roster_id: r.roster_id,
              user,
              league_id: league.league_id,
              league_name: leagueInfo.name,
              wins: stats[r.roster_id].wins,
              fpts: stats[r.roster_id].fpts,
              league_rank: rank
            });
          }
        });
      }

      const finalRanking: QualifiedTeam[] = [];
      [1, 2, 3, 4].forEach(rank => {
        if (rankPools[rank]) {
          const pool = rankPools[rank].sort((a, b) => {
            if (b.wins !== a.wins) return b.wins - a.wins;
            return b.fpts - a.fpts;
          });
          finalRanking.push(...pool);
        }
      });

      // SLICE 64 para Super League 64
      const top64 = finalRanking.slice(0, 64).map((t, idx) => ({ ...t, seed: idx + 1 }));
      setQualifiedTeams(top64);
      setWeeklyScores(scoresMap);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [leagues]);

  useEffect(() => { loadAllData(); }, [loadAllData]);

  const bracket = useMemo(() => {
    if (qualifiedTeams.length === 0) return null;
    const rounds: MatchNode[][] = [];
    
    // R64 (W12)
    let currentRoundMatches: MatchNode[] = [];
    for (let i = 0; i < 32; i++) {
      const s1 = i + 1;
      const s2 = 64 - i;
      const t1 = qualifiedTeams.find(t => t.seed === s1);
      const t2 = qualifiedTeams.find(t => t.seed === s2);
      const p1 = t1 ? (weeklyScores[t1.league_id]?.[t1.roster_id]?.[12] || 0) : 0;
      const p2 = t2 ? (weeklyScores[t2.league_id]?.[t2.roster_id]?.[12] || 0) : 0;
      const winner = (t1 || t2) ? (p1 >= p2 ? t1 : t2) : undefined;
      currentRoundMatches.push({ t1, t2, winner, p1, p2 });
    }
    rounds.push(currentRoundMatches);

    let week = 13;
    let prevRound = currentRoundMatches;
    while (prevRound.length > 1) {
      const nextRound: MatchNode[] = [];
      for (let i = 0; i < prevRound.length; i += 2) {
        const t1 = prevRound[i].winner;
        const t2 = prevRound[i + 1].winner;
        const p1 = t1 ? (weeklyScores[t1.league_id]?.[t1.roster_id]?.[week] || 0) : 0;
        const p2 = t2 ? (weeklyScores[t2.league_id]?.[t2.roster_id]?.[week] || 0) : 0;
        const winner = (t1 || t2) ? (p1 >= p2 ? t1 : t2) : undefined;
        nextRound.push({ t1, t2, winner, p1, p2 });
      }
      rounds.push(nextRound);
      prevRound = nextRound;
      week++;
      if (week > 17) break;
    }
    return rounds;
  }, [qualifiedTeams, weeklyScores]);

  const TeamBlock = ({ team, points, side = 'left', type = 'silver' }: { team?: QualifiedTeam, points?: number, side?: 'left' | 'right', type?: 'silver' | 'gold' }) => {
    const isGold = type === 'gold';
    return (
      <div className={`relative group ${side === 'right' ? 'flex-row-reverse' : 'flex-row'} flex items-center shrink-0`}>
        <div 
          className={`
            w-[210px] h-[48px] relative
            bg-gradient-to-r ${isGold ? 'from-[#facc15] via-[#a16207] to-[#facc15]' : 'from-[#94a3b8] via-[#475569] to-[#94a3b8]'}
            rounded-md overflow-hidden shadow-[0_10px_30px_-10px_rgba(0,0,0,0.5)]
            flex items-center transition-all duration-300 group-hover:scale-105 group-hover:brightness-110
            before:absolute before:inset-[1px] before:bg-gradient-to-br ${isGold ? 'before:from-[#854d0e] before:to-[#451a03]' : 'before:from-[#334155] before:to-[#0f172a]'} before:rounded-[5px]
          `}
          style={{ clipPath: side === 'left' ? 'polygon(0% 0%, 90% 0%, 100% 100%, 0% 100%)' : 'polygon(10% 0%, 100% 0%, 100% 100%, 0% 100%)' }}
        >
          <div className={`relative z-10 w-full h-full flex items-center px-4 ${side === 'right' ? 'flex-row-reverse text-right' : 'flex-row'}`}>
            <div className={`w-7 h-7 rounded-full border border-white/10 overflow-hidden bg-slate-900 shadow-lg shrink-0`}>
              <img src={getAvatarUrl(team?.user?.avatar || null)} alt="" className="w-full h-full object-cover" />
            </div>
            <div className={`flex-1 mx-3 flex flex-col justify-center min-w-0`}>
              <span className={`text-[10px] font-black uppercase tracking-tighter ${isGold ? 'text-yellow-100' : 'text-slate-100'} truncate`}>
                {team?.user?.display_name || 'TBD'}
              </span>
              {team && <span className="text-[7px] font-bold text-white/40 uppercase tracking-widest leading-none">SEED {team.seed}</span>}
            </div>
            <div className={`text-base font-black italic tracking-tighter ${isGold ? 'text-yellow-400' : 'text-slate-400'}`}>
              {points !== undefined && points > 0 ? points.toFixed(0) : '--'}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const RoundTitle = ({ text }: { text: string }) => (
    <div className="text-[10px] font-black text-yellow-500/30 uppercase tracking-[0.4em] mb-4 text-center whitespace-nowrap">{text}</div>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-[#000] flex flex-col items-center justify-center p-8">
        <Target className="w-16 h-16 text-yellow-600 animate-pulse mb-8" />
        <h2 className="text-xl font-black text-white uppercase tracking-[0.5em] italic">SUPER LEAGUE 64</h2>
        <div className="w-full max-w-md h-1 bg-white/5 rounded-full mt-6 overflow-hidden">
          <div className="h-full bg-yellow-500 transition-all duration-300" style={{ width: `${progress}%` }}></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] flex flex-col overflow-hidden select-none">
      <header className="p-6 bg-black/80 backdrop-blur-xl border-b border-yellow-500/10 flex items-center justify-between z-[100] shadow-2xl">
        <div className="flex items-center gap-6">
          <button onClick={onBack} className="p-3 bg-white/5 hover:bg-yellow-500/20 border border-white/10 rounded-full text-white transition-all group">
            <ChevronLeft className="w-6 h-6 group-hover:-translate-x-1" />
          </button>
          <div>
            <h1 className="text-2xl font-black text-white uppercase tracking-[0.2em] italic leading-none">SUPER LEAGUE 64</h1>
            <p className="text-[10px] font-bold text-yellow-500/60 uppercase tracking-[0.4em]">SEASON 2025 • TOURNAMENT BRACKET</p>
          </div>
        </div>
        <div className="flex gap-4">
          <button onClick={() => setScale(s => Math.min(s + 0.1, 2.0))} className="p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-yellow-500/20 text-white transition-all"><Plus className="w-5 h-5" /></button>
          <button onClick={() => setScale(s => Math.max(s - 0.1, 0.2))} className="p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-yellow-500/20 text-white transition-all"><Minus className="w-5 h-5" /></button>
          <button onClick={() => setScale(0.4)} className="p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-yellow-500/20 text-white transition-all"><Maximize className="w-5 h-5" /></button>
        </div>
      </header>

      <main 
        className="flex-1 overflow-auto no-scrollbar relative cursor-grab active:cursor-grabbing"
      >
        <div 
          className="relative transition-transform duration-75 origin-top-left flex justify-center p-12 min-w-max"
          style={{ transform: `scale(${scale})`, height: `${BRACKET_HEIGHT + 600}px` }}
        >
          <div className="flex items-center gap-32 pt-32 h-full">
            
            {/* LADO ESQUERDO */}
            <div className="flex items-center gap-24">
              <div className="flex flex-col h-full justify-between" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="R64" />
                {bracket?.[0].slice(0, 16).map((m, i) => (
                  <div key={i} className="relative flex flex-col gap-3 h-[120px] justify-center">
                    <TeamBlock team={m.t1} points={m.p1} />
                    <TeamBlock team={m.t2} points={m.p2} />
                    <div className="absolute -right-24 top-1/2 -translate-y-1/2 w-24 h-[1px] bg-yellow-600/20"></div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col h-full justify-around" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="R32" />
                {bracket?.[1].slice(0, 8).map((m, i) => (
                  <div key={i} className="relative flex flex-col gap-3 h-[120px] justify-center">
                    <TeamBlock team={m.t1} points={m.p1} />
                    <TeamBlock team={m.t2} points={m.p2} />
                    <div className="absolute -right-24 top-1/2 -translate-y-1/2 w-24 h-[1px] bg-yellow-600/20"></div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col h-full justify-around" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="SWEET 16" />
                {bracket?.[2].slice(0, 4).map((m, i) => (
                  <div key={i} className="relative flex flex-col gap-3 h-[120px] justify-center">
                    <TeamBlock team={m.t1} points={m.p1} />
                    <TeamBlock team={m.t2} points={m.p2} />
                    <div className="absolute -right-24 top-1/2 -translate-y-1/2 w-24 h-[1px] bg-yellow-600/20"></div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col h-full justify-around" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="ELITE 8" />
                {bracket?.[3].slice(0, 2).map((m, i) => (
                  <div key={i} className="relative flex flex-col gap-3 h-[120px] justify-center">
                    <TeamBlock team={m.t1} points={m.p1} />
                    <TeamBlock team={m.t2} points={m.p2} />
                    <div className="absolute -right-24 top-1/2 -translate-y-1/2 w-24 h-[1px] bg-yellow-600/20"></div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col h-full justify-around" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="SEMIFINAL" />
                <div className="relative flex flex-col gap-3 h-[120px] justify-center">
                  <TeamBlock team={bracket?.[4][0].t1} points={bracket?.[4][0].p1} />
                  <TeamBlock team={bracket?.[4][0].t2} points={bracket?.[4][0].p2} />
                  <div className="absolute -right-32 top-1/2 -translate-y-1/2 w-32 h-[2px] bg-yellow-500 shadow-xl"></div>
                </div>
              </div>
            </div>

            {/* CENTRO: GRANDE FINAL */}
            <div className="flex flex-col items-center justify-center gap-20 z-50">
               <div className="flex flex-col items-center gap-12">
                  <div className="relative group">
                    <div className="absolute inset-0 bg-yellow-500/20 blur-[80px] rounded-full animate-pulse group-hover:bg-yellow-500/40 transition-all"></div>
                    <Trophy className="w-48 h-48 text-yellow-500 drop-shadow-[0_0_50px_rgba(234,179,8,0.4)] relative z-10" />
                  </div>
                  <div className="flex flex-col items-center gap-6">
                    <RoundTitle text="GRAND CHAMPIONSHIP" />
                    <TeamBlock team={bracket?.[5]?.[0]?.t1} points={bracket?.[5]?.[0]?.p1} type="gold" />
                    <div className="text-white/20 font-black italic text-4xl">VS</div>
                    <TeamBlock team={bracket?.[5]?.[0]?.t2} points={bracket?.[5]?.[0]?.p2} side="right" type="gold" />
                  </div>
               </div>
               
               {bracket?.[5]?.[0]?.winner && (
                  <div className="animate-in zoom-in duration-1000 flex flex-col items-center">
                    <div className="px-16 py-8 bg-gradient-to-br from-yellow-600/20 to-transparent border border-yellow-500/30 rounded-[3rem] backdrop-blur-3xl shadow-3xl text-center">
                      <Medal className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                      <h2 className="text-4xl font-black text-white uppercase italic tracking-tighter">{bracket?.[5][0].winner.user?.display_name}</h2>
                      <p className="text-[10px] font-black text-yellow-500 uppercase tracking-[0.5em] mt-2">GLOBAL CHAMPION 2025</p>
                    </div>
                  </div>
               )}
            </div>

            {/* LADO DIREITO */}
            <div className="flex flex-row-reverse items-center gap-24">
              <div className="flex flex-col h-full justify-between" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="R64" />
                {bracket?.[0].slice(16, 32).map((m, i) => (
                  <div key={i} className="relative flex flex-col gap-3 h-[120px] justify-center">
                    <TeamBlock team={m.t1} points={m.p1} side="right" />
                    <TeamBlock team={m.t2} points={m.p2} side="right" />
                    <div className="absolute -left-24 top-1/2 -translate-y-1/2 w-24 h-[1px] bg-yellow-600/20"></div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col h-full justify-around" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="R32" />
                {bracket?.[1].slice(8, 16).map((m, i) => (
                  <div key={i} className="relative flex flex-col gap-3 h-[120px] justify-center">
                    <TeamBlock team={m.t1} points={m.p1} side="right" />
                    <TeamBlock team={m.t2} points={m.p2} side="right" />
                    <div className="absolute -left-24 top-1/2 -translate-y-1/2 w-24 h-[1px] bg-yellow-600/20"></div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col h-full justify-around" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="SWEET 16" />
                {bracket?.[2].slice(4, 8).map((m, i) => (
                  <div key={i} className="relative flex flex-col gap-3 h-[120px] justify-center">
                    <TeamBlock team={m.t1} points={m.p1} side="right" />
                    <TeamBlock team={m.t2} points={m.p2} side="right" />
                    <div className="absolute -left-24 top-1/2 -translate-y-1/2 w-24 h-[1px] bg-yellow-600/20"></div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col h-full justify-around" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="ELITE 8" />
                {bracket?.[3].slice(2, 4).map((m, i) => (
                  <div key={i} className="relative flex flex-col gap-3 h-[120px] justify-center">
                    <TeamBlock team={m.t1} points={m.p1} side="right" />
                    <TeamBlock team={m.t2} points={m.p2} side="right" />
                    <div className="absolute -left-24 top-1/2 -translate-y-1/2 w-24 h-[1px] bg-yellow-600/20"></div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col h-full justify-around" style={{ height: BRACKET_HEIGHT }}>
                <RoundTitle text="SEMIFINAL" />
                <div className="relative flex flex-col gap-3 h-[120px] justify-center">
                  <TeamBlock team={bracket?.[4][1].t1} points={bracket?.[4][1].p1} side="right" />
                  <TeamBlock team={bracket?.[4][1].t2} points={bracket?.[4][1].p2} side="right" />
                  <div className="absolute -left-32 top-1/2 -translate-y-1/2 w-32 h-[2px] bg-yellow-500 shadow-xl"></div>
                </div>
              </div>
            </div>
          </div>

          <div className="absolute bottom-20 left-1/2 -translate-x-1/2 text-center pointer-events-none opacity-5">
             <h3 className="text-[200px] font-black text-white uppercase tracking-[0.5em] italic leading-none whitespace-nowrap">SUPER 64</h3>
          </div>
        </div>
      </main>

      <footer className="p-6 bg-black border-t border-yellow-500/10 text-center relative z-50">
        <p className="text-[10px] font-black text-yellow-600 uppercase tracking-[0.5em]">FWL SUPER LEAGUE 64 • OFFICIAL TOURNAMENT SYSTEM • 2025</p>
      </footer>
    </div>
  );
};

export default BradyPlayoffs;
