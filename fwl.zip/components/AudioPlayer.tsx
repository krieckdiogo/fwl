
import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

// Utilizando jsDelivr como proxy CDN para o GitHub, que suporta Range Requests e MIME types corretos para áudio
const AUDIO_URL = 'https://cdn.jsdelivr.net/gh/Real-Dev-Labs/media-assets@main/fundo_musical_nfl.mp3'; 

const AudioPlayer: React.FC = () => {
  const [isMuted, setIsMuted] = useState(true); // Inicia no mudo
  const [isPlaying, setIsPlaying] = useState(false); // Inicia pausado
  const [loadError, setLoadError] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Instancia o objeto já com a URL no construtor
    const audio = new Audio(AUDIO_URL);
    
    audio.loop = true;
    audio.volume = 0.35;
    audio.muted = true; 
    audio.preload = "auto"; 
    audioRef.current = audio;

    const handleCanPlay = () => {
      setLoadError(false);
      console.debug("FWL Audio Engine: Fonte verificada via CDN e pronta para execução.");
    };
    
    const handleError = (e: Event) => {
      const target = e.target as HTMLAudioElement;
      const error = target.error;
      
      let message = "Erro desconhecido";
      if (error) {
        switch (error.code) {
          case 1: message = "ABORTADO: O carregamento foi interrompido."; break;
          case 2: message = "REDE: Falha na conexão ou arquivo inexistente."; break;
          case 3: message = "DECODE: O formato do arquivo é inválido ou está corrompido."; break;
          case 4: message = "FONTE_NAO_SUPORTADA: O navegador não conseguiu processar este fluxo de áudio."; break;
        }
      }
      
      console.error(`FWL Audio Error [Code ${error?.code}]: ${message}`);
      setLoadError(true);
    };

    // Usamos 'canplay' que é disparado mais cedo que o 'canplaythrough'
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('error', handleError);

    // Carregamento inicial
    audio.load();

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.removeEventListener('canplay', handleCanPlay);
        audioRef.current.removeEventListener('error', handleError);
        audioRef.current.src = ""; 
        audioRef.current.load();
      }
    };
  }, []);

  const handleToggleAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!audioRef.current || loadError) return;

    if (!isPlaying) {
      // Tenta iniciar a reprodução (necessário clique do usuário)
      audioRef.current.play()
        .then(() => {
          setIsPlaying(true);
          setIsMuted(false);
          audioRef.current!.muted = false;
        })
        .catch((err) => {
          if (err.name === 'NotAllowedError') {
            console.warn("FWL: O navegador bloqueou o autoplay. Tente interagir com a página novamente.");
          } else {
            console.error("FWL: Falha na reprodução:", err.message);
            // Se falhar, tentamos recarregar a fonte uma vez
            audioRef.current?.load();
          }
        });
    } else {
      // Alterna o mudo após o áudio já estar 'em execução'
      const newMuteState = !isMuted;
      audioRef.current.muted = newMuteState;
      setIsMuted(newMuteState);
    }
  };

  return (
    <div className="fixed top-6 right-6 z-[300] flex items-center gap-3">
      {isPlaying && !isMuted && !loadError && (
        <div className="flex items-end gap-[3px] h-4 mb-1">
          <div className="w-[3px] bg-blue-500 animate-[sound_0.5s_ease-in-out_infinite] h-full rounded-full shadow-[0_0_8px_rgba(59,130,246,0.5)]"></div>
          <div className="w-[3px] bg-blue-400 animate-[sound_0.7s_ease-in-out_infinite] h-3 rounded-full"></div>
          <div className="w-[3px] bg-blue-600 animate-[sound_0.4s_ease-in-out_infinite] h-4 rounded-full"></div>
          <div className="w-[3px] bg-blue-300 animate-[sound_0.6s_ease-in-out_infinite] h-2 rounded-full"></div>
        </div>
      )}
      
      <button 
        onClick={handleToggleAudio}
        disabled={loadError}
        className={`relative p-4 rounded-full backdrop-blur-2xl border transition-all duration-500 group flex items-center justify-center shadow-2xl ${
          loadError
          ? 'bg-slate-800/50 border-white/10 text-slate-500 cursor-not-allowed'
          : isMuted 
            ? 'bg-slate-800/80 border-white/10 text-slate-400 hover:border-blue-500/50' 
            : 'bg-blue-600/20 border-blue-500/50 text-blue-400 hover:scale-110'
        }`}
        title={loadError ? "Áudio indisponível" : (isMuted ? "Ativar som" : "Desativar som")}
      >
        {loadError ? (
          <VolumeX className="w-6 h-6" />
        ) : isMuted ? (
          <VolumeX className="w-6 h-6 group-hover:text-blue-400 transition-colors" />
        ) : (
          <Volume2 className="w-6 h-6 group-hover:scale-110 transition-transform" />
        )}

        {isMuted && !loadError && (
          <span className="absolute -bottom-10 right-0 whitespace-nowrap text-[8px] font-black uppercase tracking-widest bg-blue-600 text-white px-2 py-1 rounded shadow-lg animate-pulse">
            Clique para ativar o som
          </span>
        )}

        {!isMuted && isPlaying && !loadError && (
          <div className="absolute inset-0 rounded-full bg-blue-500/20 blur-md -z-10 animate-pulse"></div>
        )}
      </button>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes sound {
          0%, 100% { height: 6px; opacity: 0.4; }
          50% { height: 16px; opacity: 1; }
        }
      `}} />
    </div>
  );
};

export default AudioPlayer;
