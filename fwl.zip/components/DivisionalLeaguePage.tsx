
import React, { useState, useEffect } from 'react';
import { ArrowLeft, ChevronRight, Layers, RefreshCw } from 'lucide-react';
import { fetchLeagueInfo, getAvatarUrl } from '../services/sleeper';
import { League } from '../types';

interface DivisionalLeaguePageProps {
  onBack: () => void;
  onSelectLeague: (id: string) => void;
}

const DivisionalLeaguePage: React.FC<DivisionalLeaguePageProps> = ({ onBack, onSelectLeague }) => {
  const [leagues, setLeagues] = useState<League[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadLeagues = async () => {
      setLoading(true);
      try {
        const divisionalIds = [
          '1204159865153388544', // Alabama (Existente)
          '1227151609222414336',
          '1203718439328288768',
          '1228196172506615808',
          '1204160977872883712',
          '1208069127642558464',
          '1228858492396249088',
          '1205275237512380416',
          '1230678720927256576',
          '1204161934232911872',
          '1208069811418976256',
          '1228075640113086464',
          '1230631997513154560',
          '1229611593545826304',
          '1228008558625292288',
          '1205275488969306112',
          '1230004768844283904',
          '1205274747131150336',
          '1227150862938284032',
          '1205275066451906560',
          '1230515275959377920'
        ];
        
        // Buscamos as informações de todas as ligas em paralelo
        const fetched = await Promise.all(
          divisionalIds.map(id => fetchLeagueInfo(id))
        );
        
        // Ordenamos por nome para melhor navegação
        setLeagues(fetched.sort((a, b) => a.name.localeCompare(b.name)));
      } catch (error) {
        console.error("Failed to load Divisional divisions:", error);
      } finally {
        setLoading(false);
      }
    };
    loadLeagues();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0f1d] flex flex-col items-center justify-center space-y-4">
        <RefreshCw className="w-10 h-10 text-slate-500 animate-spin" />
        <p className="text-slate-500 font-black uppercase tracking-widest text-[10px]">Acessando Divisões Divisional League...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0f1d] py-12 px-6">
      <div className="max-w-2xl mx-auto space-y-10">
        <header className="flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Voltar</span>
          </button>
          <div className="text-right">
            <h1 className="text-2xl font-black text-white uppercase italic leading-none">Divisional League</h1>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Semanas 1-14 • 2025</p>
          </div>
        </header>

        <div className="grid gap-4">
          {leagues.map((league) => (
            <button
              key={league.league_id}
              onClick={() => onSelectLeague(league.league_id)}
              className="group relative flex items-center justify-between p-6 bg-[#1e293b]/30 border border-white/5 rounded-3xl transition-all hover:bg-white/5 hover:border-slate-500/30 hover:-translate-y-1 shadow-xl text-left"
            >
              <div className="flex items-center gap-6">
                <div className="w-14 h-14 rounded-2xl bg-slate-950 border border-white/10 flex items-center justify-center overflow-hidden shadow-lg group-hover:scale-105 transition-transform">
                  {league.avatar ? (
                    <img src={getAvatarUrl(league.avatar)} className="w-full h-full object-cover" alt="" />
                  ) : (
                    <Layers className="w-6 h-6 text-slate-500" />
                  )}
                </div>
                <div>
                  <h3 className="font-black text-white text-lg uppercase tracking-tighter italic leading-none mb-1">
                    {league.name.replace('FWL 2025 - ', '').replace('FWL 2026 - ', '')}
                  </h3>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    <span>{league.total_rosters} Times</span>
                    <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
                    <span>Final W14</span>
                  </div>
                </div>
              </div>
              <ChevronRight className="w-6 h-6 text-slate-700 group-hover:text-white group-hover:translate-x-1 transition-all" />
            </button>
          ))}
        </div>

        {leagues.length === 0 && (
          <div className="text-center py-20 bg-white/5 rounded-[2.5rem] border border-dashed border-white/10">
            <p className="text-slate-500 font-black uppercase tracking-widest text-xs">Nenhuma divisão encontrada.</p>
          </div>
        )}

        <footer className="text-center pt-8 opacity-30">
          <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.5em]">FWL Data Protocol • Divisional Series</p>
        </footer>
      </div>
    </div>
  );
};

export default DivisionalLeaguePage;
