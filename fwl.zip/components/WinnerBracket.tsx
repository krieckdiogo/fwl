
import React, { useMemo } from 'react';
import { BracketMatch, User, Roster } from '../types';
import { getAvatarUrl } from '../services/sleeper';
import { Trophy, Medal, Star } from 'lucide-react';

interface WinnerBracketProps {
  bracket: BracketMatch[];
  users: User[];
  rosters: Roster[];
  playoffScores?: Record<number, Record<number, number>>; // week -> roster_id -> score
}

const WinnerBracket: React.FC<WinnerBracketProps> = ({ bracket, users, rosters, playoffScores }) => {
  const rounds = useMemo(() => {
    const rMap: Record<number, BracketMatch[]> = {};
    bracket.forEach(m => {
      if (!rMap[m.r]) rMap[m.r] = [];
      rMap[m.r].push(m);
    });
    return Object.entries(rMap).sort((a, b) => Number(a[0]) - Number(b[0]));
  }, [bracket]);

  const getTeamInfo = (rosterId: number | null, round: number) => {
    if (!rosterId) return { name: 'TBD', avatar: null, score: null };
    const roster = rosters.find(r => r.roster_id === rosterId);
    const user = users.find(u => u.user_id === roster?.owner_id);
    
    // Mapeamento Alabama: Rodada 1=W15, 2=W16, 3=W17
    let score = null;
    if (playoffScores) {
      const week = 14 + round;
      score = playoffScores[week]?.[rosterId] ?? null;
    }

    return {
      name: user?.display_name || 'Desconhecido',
      avatar: user?.avatar || null,
      score
    };
  };

  if (!bracket || bracket.length === 0) {
    return (
      <div className="py-24 text-center bg-white/5 rounded-[3rem] border border-dashed border-white/10 space-y-4">
        <Star className="w-12 h-12 text-slate-700 mx-auto" />
        <div>
          <p className="text-white font-black uppercase tracking-widest text-sm">Bracket Não Gerado</p>
          <p className="text-slate-500 font-bold uppercase tracking-widest text-[9px] mt-1">Os playoffs ainda não começaram nesta liga.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-12 overflow-x-auto no-scrollbar pb-12 animate-in fade-in slide-in-from-right-8 duration-500">
      {rounds.map(([roundNum, matches]) => {
        const r = Number(roundNum);
        return (
          <div key={roundNum} className="flex flex-col gap-12 min-w-[280px]">
            <div className="text-center px-4 py-2 bg-white/5 border border-white/10 rounded-xl">
               <h3 className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em]">Rodada {roundNum} {playoffScores ? `(W${14 + r})` : ''}</h3>
            </div>
            
            <div className="flex flex-col justify-around flex-1 gap-8">
              {matches.map((match) => {
                const t1 = getTeamInfo(match.t1, r);
                const t2 = getTeamInfo(match.t2, r);
                const isW1 = match.w === match.t1;
                const isW2 = match.w === match.t2;

                return (
                  <div key={match.m} className="bg-[#1f2937] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
                    <div className={`p-4 flex items-center justify-between border-b border-white/5 ${isW1 ? 'bg-blue-500/10' : ''}`}>
                      <div className="flex items-center gap-3 overflow-hidden">
                        <img src={getAvatarUrl(t1.avatar)} className={`w-8 h-8 rounded-full border ${isW1 ? 'border-blue-500' : 'border-slate-700'}`} alt="" />
                        <span className={`text-xs font-bold truncate ${isW1 ? 'text-white' : 'text-slate-500'}`}>{t1.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {t1.score !== null && (
                          <span className={`text-xs font-black ${isW1 ? 'text-blue-400' : 'text-slate-600'}`}>{t1.score.toFixed(2)}</span>
                        )}
                        {isW1 && <Trophy className="w-3 h-3 text-yellow-500" />}
                      </div>
                    </div>
                    <div className={`p-4 flex items-center justify-between ${isW2 ? 'bg-blue-500/10' : ''}`}>
                      <div className="flex items-center gap-3 overflow-hidden">
                        <img src={getAvatarUrl(t2.avatar)} className={`w-8 h-8 rounded-full border ${isW2 ? 'border-blue-500' : 'border-slate-700'}`} alt="" />
                        <span className={`text-xs font-bold truncate ${isW2 ? 'text-white' : 'text-slate-500'}`}>{t2.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {t2.score !== null && (
                          <span className={`text-xs font-black ${isW2 ? 'text-blue-400' : 'text-slate-600'}`}>{t2.score.toFixed(2)}</span>
                        )}
                        {isW2 && <Trophy className="w-3 h-3 text-yellow-500" />}
                      </div>
                    </div>
                    {match.p === 1 && (
                      <div className="bg-yellow-500/20 py-1 text-center border-t border-yellow-500/30">
                         <span className="text-[8px] font-black text-yellow-500 uppercase tracking-widest">GRAND FINAL</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default WinnerBracket;
