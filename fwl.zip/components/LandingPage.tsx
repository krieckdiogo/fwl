import React, { useState } from 'react';
import { 
  ChevronRight, 
  ArrowLeft, 
  Trophy, 
  Zap, 
  Sword,
  UserPlus,
  Shield,
  Layers,
  BarChart3,
  FileText,
  Crown
} from 'lucide-react';
import Logo from './Logo';
import PlayoffsChallenge from './PlayoffsChallenge';
import { getAvatarUrl } from '../services/sleeper';

interface LeagueOption {
  id: string;
  name: string;
  avatar: string | null;
}

interface LandingPageProps {
  leagues: LeagueOption[];
  onSelect: (id: string) => void;
  onOpenPlayoffs: () => void;
  onOpenRegistration: () => void;
  onOpenBradyBowl?: () => void;
  onOpenDivisionalLeague?: () => void;
  onOpenRanking?: () => void;
  onOpenRegulation?: () => void;
  onOpenHallOfFame?: () => void;
  onLookupLeague?: (id: string) => void;
  fwlLogoAvatar: string | null;
  atlantaLeagueAvatar?: string | null;
  playoffsChallengeAvatar?: string | null;
  divisionalLeagueAvatar?: string | null;
  rankingIconAvatar?: string | null;
  finalsLogoAvatar: string | null;
  finalsLeagueId?: string;
  regulationIconAvatar?: string | null;
}

type ViewState = 'years' | 'categories' | 'playoffsChallenge';

const LandingPage: React.FC<LandingPageProps> = ({ 
  onOpenRegistration,
  onOpenBradyBowl,
  onOpenDivisionalLeague,
  onOpenRanking,
  onOpenRegulation,
  onOpenHallOfFame,
  fwlLogoAvatar,
  atlantaLeagueAvatar,
  playoffsChallengeAvatar,
  divisionalLeagueAvatar,
  rankingIconAvatar,
  regulationIconAvatar
}) => {
  const [view, setView] = useState<ViewState>('years');
  const [selectedYear, setSelectedYear] = useState<string | null>(null);

  const handleYearSelect = (year: string) => {
    setSelectedYear(year);
    setView('categories');
  };

  const handleBack = () => {
    if (view === 'playoffsChallenge') {
      setView('categories');
    } else if (view === 'categories') {
      setView('years');
      setSelectedYear(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0f1d] flex flex-col items-center justify-center p-6 text-slate-200 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-20">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/30 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-slate-500/20 blur-[120px] rounded-full"></div>
      </div>

      <div className={`w-full ${view === 'playoffsChallenge' ? 'max-w-4xl' : 'max-w-md'} space-y-10 relative z-10 transition-all duration-500`}>
        {/* Logo Section */}
        {view !== 'playoffsChallenge' && (
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center w-28 h-28 rounded-full bg-slate-950/40 border border-white/5 shadow-[0_0_80px_rgba(59,130,246,0.15)] mb-6 overflow-hidden relative group">
              <Logo className="w-full h-full" leagueAvatar={fwlLogoAvatar} />
            </div>
            <div className="space-y-2">
              <h1 className="text-5xl font-black text-white tracking-tighter italic leading-tight uppercase">FWL</h1>
              <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em] opacity-60">Fantasy World League</p>
            </div>
          </div>
        )}

        {/* View: Years Selection (Home Page) */}
        {view === 'years' && (
          <div className="grid gap-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-2 text-center">Acesse a Plataforma</p>
            <div className="grid gap-4">
              <button
                onClick={() => handleYearSelect('2025')}
                className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-[#1e293b]/40 to-[#1e293b]/10 border border-white/5 rounded-[2.5rem] transition-all hover:bg-white/5 hover:border-blue-500/30 hover:-translate-y-1 shadow-2xl"
              >
                <div className="flex items-center gap-6">
                  <div className="text-left">
                    <h3 className="font-black text-white text-3xl leading-none mb-1 italic">2025</h3>
                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Temporada Anterior</p>
                  </div>
                </div>
                <ChevronRight className="w-8 h-8 text-slate-600 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
              </button>

              <button
                onClick={onOpenRegistration}
                className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-blue-600/30 to-blue-900/10 border border-blue-500/50 rounded-[2.5rem] transition-all hover:bg-blue-600/20 hover:border-blue-400 hover:-translate-y-1 shadow-2xl"
              >
                <div className="flex items-center gap-6">
                  <div className="text-left">
                    <h3 className="font-black text-white text-3xl leading-none mb-1 italic">2026</h3>
                    <p className="text-[10px] font-black text-blue-200 uppercase tracking-widest">Inscrições Abertas!</p>
                  </div>
                </div>
                <ChevronRight className="w-8 h-8 text-blue-300 group-hover:translate-x-1 transition-all" />
              </button>

              <button
                onClick={onOpenRegulation}
                className="group relative flex items-center justify-between p-8 bg-white/5 border border-white/10 rounded-[2.5rem] transition-all hover:bg-white/10 hover:-translate-y-1 shadow-xl"
              >
                <div className="flex items-center gap-6">
                  <div className="text-left">
                    <h3 className="font-black text-white text-2xl uppercase tracking-tighter italic leading-none mb-1">Regulamento</h3>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Regras e Formato 2026</p>
                  </div>
                </div>
                <ChevronRight className="w-8 h-8 text-slate-600 group-hover:text-white transition-colors" />
              </button>
            </div>
          </div>
        )}

        {/* View: Categories / Season Hub */}
        {view === 'categories' && (
          <div className="grid gap-4 animate-in fade-in slide-in-from-right-4 duration-500">
            <div className="flex items-center justify-between mb-2 px-2">
               <button onClick={handleBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group">
                 <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                 <span className="text-[10px] font-black uppercase tracking-widest">Voltar</span>
               </button>
               <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Temporada {selectedYear}</span>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <button
                onClick={onOpenHallOfFame}
                className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-yellow-600/30 to-amber-900/10 border border-yellow-500/50 rounded-[2.5rem] transition-all hover:bg-yellow-600/20 hover:border-yellow-400 hover:-translate-y-1 shadow-2xl overflow-hidden"
              >
                <div className="flex items-center gap-6 relative z-10">
                  <div className="w-16 h-16 rounded-2xl bg-slate-950 border border-yellow-500/30 flex items-center justify-center shadow-[0_0_20px_rgba(234,179,8,0.2)] group-hover:scale-110 transition-transform overflow-hidden">
                    <Crown className="w-8 h-8 text-yellow-500" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-black text-white text-2xl uppercase tracking-tighter italic leading-none mb-1">Quadro de Honra</h3>
                    <p className="text-[10px] font-black text-yellow-500 uppercase tracking-widest">Hall of Fame 2025</p>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-yellow-500" />
              </button>

              <button
                onClick={onOpenRanking}
                className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-slate-200/10 to-transparent border border-white/20 rounded-[2.5rem] transition-all hover:bg-white/10 hover:-translate-y-1 shadow-2xl overflow-hidden"
              >
                <div className="flex items-center gap-6 relative z-10">
                  <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/20 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform overflow-hidden">
                    {rankingIconAvatar ? (
                      <img 
                        src={getAvatarUrl(rankingIconAvatar)} 
                        className="w-full h-full object-cover" 
                        alt="Ranking Icon" 
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                          e.currentTarget.parentElement?.querySelector('.fallback-icon')?.classList.remove('hidden');
                        }}
                      />
                    ) : null}
                    <BarChart3 className={`fallback-icon w-8 h-8 text-white ${rankingIconAvatar ? 'hidden' : ''}`} />
                  </div>
                  <div className="text-left">
                    <h3 className="font-black text-white text-2xl uppercase tracking-tighter italic leading-none mb-1">Ranking Geral</h3>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Consolidado 252 Managers</p>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-white" />
              </button>

              <button
                onClick={onOpenBradyBowl}
                className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-blue-600/20 to-transparent border border-blue-500/50 rounded-[2.5rem] transition-all hover:bg-blue-600/30 hover:-translate-y-1 shadow-2xl overflow-hidden"
              >
                <div className="flex items-center gap-6 relative z-10">
                  <div className="w-16 h-16 rounded-2xl bg-slate-950 border border-blue-500/30 flex items-center justify-center shadow-[0_0_20px_rgba(59,130,246,0.2)] group-hover:scale-110 transition-transform overflow-hidden">
                    {atlantaLeagueAvatar ? (
                      <img src={getAvatarUrl(atlantaLeagueAvatar)} className="w-full h-full object-cover" alt="Atlanta Logo" />
                    ) : (
                      <Shield className="w-8 h-8 text-blue-500" />
                    )}
                  </div>
                  <div className="text-left">
                    <h3 className="font-black text-white text-2xl uppercase tracking-tighter italic leading-none mb-1">Brady Bowl</h3>
                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">11 semanas / Playoff Geral</p>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-blue-500" />
              </button>

              <button
                onClick={onOpenDivisionalLeague}
                className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-slate-600/20 to-transparent border border-white/10 rounded-[2.5rem] transition-all hover:bg-white/5 hover:border-slate-400 hover:-translate-y-1 shadow-2xl overflow-hidden"
              >
                <div className="flex items-center gap-6 relative z-10">
                  <div className="w-16 h-16 rounded-2xl bg-slate-950 border border-white/10 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform overflow-hidden">
                    {divisionalLeagueAvatar ? (
                      <img src={getAvatarUrl(divisionalLeagueAvatar)} className="w-full h-full object-cover" alt="Divisional Logo" />
                    ) : (
                      <Layers className="w-8 h-8 text-slate-500" />
                    )}
                  </div>
                  <div className="text-left">
                    <h3 className="font-black text-white text-2xl uppercase tracking-tighter italic leading-none mb-1">Divisional League</h3>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">14 semanas / Playoff interno</p>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-slate-400" />
              </button>

              <button
                onClick={() => setView('playoffsChallenge')}
                className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-yellow-600/20 to-transparent border border-yellow-500/50 rounded-[2.5rem] transition-all hover:bg-yellow-600/30 hover:-translate-y-1 shadow-2xl overflow-hidden"
              >
                <div className="flex items-center gap-6 relative z-10">
                  <div className="w-16 h-16 rounded-2xl bg-slate-950 border border-yellow-500/30 flex items-center justify-center shadow-[0_0_20px_rgba(234,179,8,0.2)] group-hover:scale-110 transition-transform overflow-hidden">
                    {playoffsChallengeAvatar ? (
                      <img src={getAvatarUrl(playoffsChallengeAvatar)} className="w-full h-full object-cover" alt="Playoffs Challenge Logo" />
                    ) : (
                      <Sword className="w-8 h-8 text-yellow-500" />
                    )}
                  </div>
                  <div className="text-left">
                    <h3 className="font-black text-white text-2xl uppercase tracking-tighter italic leading-none mb-1">Playoffs Challenge</h3>
                    <p className="text-[10px] font-black text-yellow-500 uppercase tracking-widest">Mata-Mata Consolidado</p>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-yellow-500" />
              </button>
            </div>
          </div>
        )}

        {/* Specialized Views */}
        {view === 'playoffsChallenge' && <PlayoffsChallenge onBack={handleBack} />}
      </div>
    </div>
  );
};

export default LandingPage;