
import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { fetchLeagueData, getAvatarUrl } from '../services/sleeper';
import { FWL_LEAGUES } from '../App';
// Import User type from types
import { User } from '../types';
import { 
  ArrowLeft, 
  Search, 
  Medal, 
  Star, 
  RefreshCw, 
  Clock,
  Award,
  Circle
} from 'lucide-react';

interface RankingBonusPageProps {
  onBack: () => void;
}

const wait = (ms: number) => new Promise(res => setTimeout(res, ms));

const RankingBonusPage: React.FC<RankingBonusPageProps> = ({ onBack }) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [isRetrying, setIsRetrying] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [allUsers, setAllUsers] = useState<Record<string, { displayName: string, avatar: string | null }>>({});

  const fetchWithRetry = async <T extends unknown>(fn: () => Promise<T>): Promise<T> => {
    let attempts = 0;
    while (true) {
      try {
        const result = await fn();
        if (isRetrying) setIsRetrying(false);
        return result;
      } catch (e: any) {
        attempts++;
        setIsRetrying(true);
        const delayTime = e?.status === 429 ? 30000 : 2000;
        await wait(delayTime);
      }
    }
  };

  const loadAllUsers = useCallback(async () => {
    setLoading(true);
    const usersMap: Record<string, { displayName: string, avatar: string | null }> = {};
    try {
      for (let i = 0; i < FWL_LEAGUES.length; i++) {
        const league = FWL_LEAGUES[i];
        setProgress(Math.round(((i + 1) / FWL_LEAGUES.length) * 100));
        // Cast result to specific type to avoid 'unknown' errors
        const { users } = (await fetchWithRetry(() => fetchLeagueData(league.id))) as { users: User[] };
        users.forEach(u => {
          const key = u.display_name.toLowerCase().trim();
          if (!usersMap[key]) {
            usersMap[key] = { displayName: u.display_name, avatar: u.avatar };
          }
        });
      }
      setAllUsers(usersMap);
    } catch (err) { console.error(err); } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAllUsers(); }, [loadAllUsers]);

  const ranking = useMemo(() => {
    const staticBonuses = [
      { name: "Passarelli80", total: 500, items: [{p: 500, l: "CAMPEÃO CHALLENGE"}] },
      { name: "HeidlonG", total: 300, items: [{p: 300, l: "VICE CHALLENGE"}] },
      { name: "AmaraLynch", total: 200, items: [{p: 200, l: "3º CHALLENGE"}] },
      { name: "Coutinho15", total: 500, items: [{p: 500, l: "CAMPEÃO BRADY BOWL"}] },
      { name: "kaueborges", total: 300, items: [{p: 300, l: "VICE BRADY BOWL"}] },
      { name: "RafaMartineli", total: 200, items: [{p: 200, l: "3º BRADY BOWL"}] },
      { name: "thev0id", total: 20, items: [{p: 20, l: "BYE R1 CHALLENGE"}] },
      { name: "pedrotti", total: 20, items: [{p: 20, l: "BYE R1 CHALLENGE"}] },
      { name: "srpinguim", total: 20, items: [{p: 20, l: "BYE R1 CHALLENGE"}] },
      { name: "ivanborgo", total: 20, items: [{p: 20, l: "BYE R1 CHALLENGE"}] }
    ];

    const finalScores: Record<string, any> = {};

    // Fixed: Explicitly type the entries to prevent 'displayName' on 'unknown' error
    (Object.entries(allUsers) as [string, { displayName: string, avatar: string | null }][]).forEach(([key, u]) => {
      finalScores[key] = { name: u.displayName, avatar: u.avatar, total: 0, items: [] };
    });

    // Adicionamos bônus estáticos
    staticBonuses.forEach(b => {
      const key = b.name.toLowerCase().trim();
      if (finalScores[key]) {
        finalScores[key].total = b.total;
        finalScores[key].items = b.items;
      }
    });

    return Object.values(finalScores)
      .filter((u: any) => u.name.toLowerCase().includes(searchTerm.toLowerCase()))
      .sort((a: any, b: any) => b.total - a.total);
  }, [allUsers, searchTerm]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8 p-6">
        <div className="relative">
          {isRetrying ? <Clock className="w-16 h-16 text-yellow-500 animate-pulse" /> : <RefreshCw className="w-16 h-16 text-blue-500 animate-spin" />}
          <div className="absolute inset-0 bg-blue-500/20 blur-2xl rounded-full"></div>
        </div>
        <div className="text-center space-y-4 max-w-sm">
          <h2 className="text-white font-black text-2xl uppercase italic tracking-widest">Sincronizando 252 Managers</h2>
          <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/10">
            <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${progress}%` }}></div>
          </div>
          <p className="text-[10px] font-bold uppercase text-slate-500 tracking-[0.2em]">Estabelecendo População Total da FWL...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex items-center justify-between sticky top-0 bg-[#0a0f1d]/90 backdrop-blur-xl p-4 -m-4 z-50 border-b border-white/5">
        <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
          <span className="text-[10px] font-black uppercase tracking-widest">Voltar</span>
        </button>
        <div className="text-right">
          <h2 className="text-xl font-black text-white italic uppercase tracking-tighter leading-none">Pódios & Bônus</h2>
          <p className="text-[9px] font-bold text-purple-500 uppercase tracking-widest">Master List (252 Managers)</p>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input 
          type="text" placeholder="Buscar Manager..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white/5 border border-white/10 rounded-full pl-14 pr-6 py-4 text-sm focus:border-blue-500 outline-none transition-all"
        />
      </div>

      <div className="bg-[#1e293b]/20 border border-white/5 rounded-[2.5rem] overflow-hidden shadow-2xl">
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-white/5 border-b border-white/5">
                <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase w-16 text-center">#</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-500 uppercase">Manager</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-500 uppercase">Badges & Conquistas</th>
                <th className="px-6 py-5 text-[10px] font-black text-white uppercase text-right">Total Bônus</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {ranking.map((u, idx) => (
                <tr key={u.name} className="hover:bg-purple-500/5 transition-colors group">
                  <td className="px-6 py-5 font-black text-slate-600 text-center">{idx + 1}</td>
                  <td className="px-4 py-5">
                    <div className="flex items-center gap-3">
                      <img src={getAvatarUrl(u.avatar)} className="w-9 h-9 rounded-full border border-slate-800" alt="" />
                      <span className="text-sm font-bold text-white leading-tight truncate">{u.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-5">
                    <div className="flex flex-wrap gap-2">
                      {u.items.length > 0 ? (
                        u.items.map((b: any, bi: number) => (
                          <span key={bi} className="px-2.5 py-1 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-[8px] font-black text-yellow-500 uppercase flex items-center gap-1.5 shadow-sm">
                            <Medal className="w-2.5 h-2.5" /> {b.l}
                          </span>
                        ))
                      ) : (
                        <span className="text-[9px] font-bold text-slate-600 uppercase tracking-widest italic opacity-40">-</span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-5 text-right font-black text-lg text-yellow-500">{u.total} pts</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="text-center py-8">
        <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.5em]">Mostrando {ranking.length} de {Object.keys(allUsers).length} Managers</p>
      </div>
    </div>
  );
};

export default RankingBonusPage;
