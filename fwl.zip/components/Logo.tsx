
import React, { useState, useEffect } from 'react';
import { Upload, Image as ImageIcon } from 'lucide-react';

interface LogoProps {
  className?: string;
  leagueAvatar?: string | null;
}

/**
 * COMPONENTE DE LOGO INTELIGENTE
 * Persiste a logo customizada no localStorage.
 * Se não houver logo customizada, tenta usar o avatar da liga.
 */
const Logo: React.FC<LogoProps> = ({ className = "", leagueAvatar }) => {
  const [logoSrc, setLogoSrc] = useState<string | null>(localStorage.getItem('fwl_custom_logo'));
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    // Sincroniza entre abas e instâncias do componente
    const syncLogo = () => {
      setLogoSrc(localStorage.getItem('fwl_custom_logo'));
    };
    window.addEventListener('storage', syncLogo);
    
    // Polling simples para mudanças no mesmo contexto caso necessário
    const interval = setInterval(syncLogo, 1000);

    return () => {
      window.removeEventListener('storage', syncLogo);
      clearInterval(interval);
    };
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        localStorage.setItem('fwl_custom_logo', base64String);
        setLogoSrc(base64String);
        setHasError(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const getSleeperAvatarUrl = (id: string) => `https://sleepercdn.com/avatars/thumbs/${id}`;
  
  const currentSrc = logoSrc || (leagueAvatar ? getSleeperAvatarUrl(leagueAvatar) : null);

  if (!currentSrc && hasError) {
    return (
      <label className={`${className} flex flex-col items-center justify-center border-2 border-dashed border-slate-700 rounded-full cursor-pointer hover:border-blue-500 hover:bg-blue-500/10 transition-all group overflow-hidden bg-slate-900/50`}>
        <Upload className="w-1/2 h-1/2 text-slate-600 group-hover:text-blue-500" />
        <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
      </label>
    );
  }

  return (
    <div className={`${className} relative group cursor-pointer overflow-hidden rounded-full flex items-center justify-center bg-slate-900/20`}>
      {currentSrc ? (
        <img 
          src={currentSrc} 
          alt="League Logo" 
          className="w-full h-full object-cover"
          onError={() => setHasError(true)}
        />
      ) : (
        <ImageIcon className="w-1/2 h-1/2 text-slate-700" />
      )}
      <label className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity rounded-full text-white backdrop-blur-sm">
        <Upload className="w-5 h-5 mb-1" />
        <span className="text-[8px] font-bold uppercase tracking-widest">Alterar Logo</span>
        <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
      </label>
    </div>
  );
};

export default Logo;
