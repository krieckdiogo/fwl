
import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Zap, 
  Trophy, 
  Star, 
  ChevronRight,
  TrendingUp,
  Award,
  Users
} from 'lucide-react';
import RankingRegularPage from './RankingRegularPage';
import RankingPlayoffsPage from './RankingPlayoffsPage';
import RankingBonusPage from './RankingBonusPage';

interface RankingHubProps {
  onBack: () => void;
}

type RankingView = 'hub' | 'regular' | 'playoffs' | 'bonus';

const RankingHub: React.FC<RankingHubProps> = ({ onBack }) => {
  const [view, setView] = useState<RankingView>('hub');

  const handleBackToHub = () => setView('hub');

  if (view === 'regular') return <RankingRegularPage onBack={handleBackToHub} />;
  if (view === 'playoffs') return <RankingPlayoffsPage onBack={handleBackToHub} />;
  if (view === 'bonus') return <RankingBonusPage onBack={handleBackToHub} />;

  return (
    <div className="space-y-10 animate-in fade-in zoom-in duration-500 pb-20">
      {/* HEADER */}
      <div className="flex items-center justify-between sticky top-0 bg-[#0a0f1d]/90 backdrop-blur-xl p-4 -m-4 z-50 border-b border-white/5">
        <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group">
          <div className="p-2 bg-white/5 rounded-full group-hover:-translate-x-1 transition-transform">
            <ArrowLeft className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-widest">Voltar ao Menu</span>
        </button>
        <div className="text-right">
          <h2 className="text-xl font-black text-white italic uppercase tracking-tighter">Rankings FWL</h2>
          <p className="text-[9px] font-bold text-blue-500 uppercase tracking-widest">Central de Estatísticas 2025</p>
        </div>
      </div>

      <div className="text-center space-y-2">
        <h3 className="text-3xl font-black text-white uppercase italic tracking-tighter">Selecione o Ranking</h3>
        <p className="text-xs text-slate-500 font-medium uppercase tracking-[0.2em]">Os dados serão carregados sob demanda</p>
      </div>

      {/* MENU CARDS */}
      <div className="grid grid-cols-1 gap-6">
        <button 
          onClick={() => setView('regular')}
          className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-blue-600/10 via-[#1e293b]/40 to-transparent border border-blue-500/20 rounded-[2.5rem] transition-all hover:bg-blue-600/10 hover:border-blue-500/40 hover:-translate-y-1 active:scale-[0.98] shadow-2xl overflow-hidden"
        >
          <div className="flex items-center gap-6 relative z-10">
            <div className="w-20 h-20 rounded-3xl bg-slate-950 border border-blue-500/30 flex items-center justify-center shadow-[0_0_30px_rgba(59,130,246,0.15)] group-hover:scale-110 transition-transform">
              <Zap className="w-10 h-10 text-blue-400" />
            </div>
            <div className="text-left">
              <h4 className="text-2xl font-black text-white uppercase italic leading-none mb-2">Temporada Regular</h4>
              <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Vitórias & PF (Brady + Divisões)</p>
            </div>
          </div>
          <ChevronRight className="w-8 h-8 text-slate-700 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
          <div className="absolute -right-10 -bottom-10 opacity-5 group-hover:opacity-10 transition-opacity">
            <Zap className="w-48 h-48 text-white" />
          </div>
        </button>

        <button 
          onClick={() => setView('playoffs')}
          className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-yellow-600/10 via-[#1e293b]/40 to-transparent border border-yellow-500/20 rounded-[2.5rem] transition-all hover:bg-yellow-600/10 hover:border-yellow-500/40 hover:-translate-y-1 active:scale-[0.98] shadow-2xl overflow-hidden"
        >
          <div className="flex items-center gap-6 relative z-10">
            <div className="w-20 h-20 rounded-3xl bg-slate-950 border border-yellow-500/30 flex items-center justify-center shadow-[0_0_30px_rgba(234,179,8,0.15)] group-hover:scale-110 transition-transform">
              <Trophy className="w-10 h-10 text-yellow-500" />
            </div>
            <div className="text-left">
              <h4 className="text-2xl font-black text-white uppercase italic leading-none mb-2">Playoffs Challenge</h4>
              <p className="text-[10px] font-black text-yellow-500 uppercase tracking-widest">Mata-Mata Consolidado</p>
            </div>
          </div>
          <ChevronRight className="w-8 h-8 text-slate-700 group-hover:text-yellow-500 group-hover:translate-x-1 transition-all" />
          <div className="absolute -right-10 -bottom-10 opacity-5 group-hover:opacity-10 transition-opacity">
            <Trophy className="w-48 h-48 text-white" />
          </div>
        </button>

        <button 
          onClick={() => setView('bonus')}
          className="group relative flex items-center justify-between p-8 bg-gradient-to-br from-purple-600/10 via-[#1e293b]/40 to-transparent border border-purple-500/20 rounded-[2.5rem] transition-all hover:bg-purple-600/10 hover:border-purple-500/40 hover:-translate-y-1 active:scale-[0.98] shadow-2xl overflow-hidden"
        >
          <div className="flex items-center gap-6 relative z-10">
            <div className="w-20 h-20 rounded-3xl bg-slate-950 border border-purple-500/30 flex items-center justify-center shadow-[0_0_30px_rgba(168,85,247,0.15)] group-hover:scale-110 transition-transform">
              <Star className="w-10 h-10 text-purple-400" />
            </div>
            <div className="text-left">
              <h4 className="text-2xl font-black text-white uppercase italic leading-none mb-2">Pódios & Bônus</h4>
              <p className="text-[10px] font-black text-purple-400 uppercase tracking-widest">Títulos e Conquistas Especiais</p>
            </div>
          </div>
          <ChevronRight className="w-8 h-8 text-slate-700 group-hover:text-purple-500 group-hover:translate-x-1 transition-all" />
          <div className="absolute -right-10 -bottom-10 opacity-5 group-hover:opacity-10 transition-opacity">
            <Star className="w-48 h-48 text-white" />
          </div>
        </button>
      </div>

      {/* INFO FOOTER */}
      <div className="bg-white/5 p-6 rounded-[2.5rem] border border-white/5 text-center">
        <div className="flex items-center justify-center gap-3 mb-3 text-slate-500">
          <TrendingUp className="w-4 h-4" />
          <span className="text-[10px] font-black uppercase tracking-widest">Atualização Dinâmica</span>
        </div>
        <p className="text-[10px] text-slate-400 leading-relaxed font-medium px-4">
          Alguns rankings exigem o processamento de mais de 40 ligas simultaneamente. 
          O tempo de carregamento pode variar de acordo com a API do Sleeper.
        </p>
      </div>
    </div>
  );
};

export default RankingHub;
