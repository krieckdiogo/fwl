
import React, { useState } from 'react';
// Added Zap to imports to fix "Cannot find name 'Zap'" error on line 90
import { ArrowLeft, Send, CheckCircle2, Lock, HelpCircle, Copy, Loader2, XCircle, MessageCircle, CreditCard, Mail, Zap } from 'lucide-react';
import { saveRegistration } from '../services/database';

interface RegistrationPageProps {
  onBack: () => void;
  onAdmin: () => void;
}

const RegistrationPage: React.FC<RegistrationPageProps> = ({ onBack, onAdmin }) => {
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  
  const [formData, setFormData] = useState({
    played2025: '',
    fullName: '',
    cpf: '',
    sleeperId: '',
    whatsapp: '',
    email: '',
    howDidYouKnow: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      await saveRegistration({
        played_2025: formData.played2025,
        full_name: formData.fullName,
        cpf: formData.cpf,
        sleeper_id: formData.sleeperId,
        whatsapp: formData.whatsapp,
        email: formData.email,
        origin: formData.howDidYouKnow
      });
      setSubmitted(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const copyPix = () => {
    const pixKey = "worldleaguefantasy@gmail.com";
    navigator.clipboard.writeText(pixKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-[#0a0f1d] flex flex-col items-center justify-center p-6 text-slate-200 animate-in zoom-in duration-500 overflow-y-auto pb-20">
        <div className="max-w-xl w-full bg-[#1e293b]/30 border border-white/10 rounded-[3rem] p-8 md:p-12 shadow-2xl space-y-8 relative overflow-hidden backdrop-blur-xl">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-cyan-400"></div>
          
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="w-20 h-20 rounded-3xl bg-blue-500/20 border border-blue-500/50 flex items-center justify-center mb-4 relative">
              <CheckCircle2 className="w-10 h-10 text-blue-400" />
              <div className="absolute inset-0 bg-blue-500/10 blur-xl rounded-full"></div>
            </div>
            <div className="space-y-1">
              <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter">Inscrição Confirmada!</h2>
              <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em]">Bem-vindo à FWL 2026</p>
            </div>
            <p className="text-slate-400 font-medium leading-relaxed">
              Parabéns <strong className="text-white">@{formData.sleeperId}</strong>! Sua pré-inscrição foi realizada com sucesso.
            </p>
          </div>

          <div className="space-y-6">
            <div className="p-6 bg-white/5 border border-white/10 rounded-3xl space-y-6">
              {/* Header Pagamento */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-blue-400" />
                  <span className="text-xs font-black uppercase tracking-widest text-slate-300">Taxa de Inscrição</span>
                </div>
                <span className="text-xl font-black text-white italic">R$ 10,00</span>
              </div>

              {/* PIX Section */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest px-1">
                   <Zap className="w-3 h-3 text-yellow-500" /> Pagamento via PIX
                </div>
                <div className="relative group">
                  <div className="w-full bg-black/40 border border-white/5 rounded-2xl p-4 pr-16 text-sm font-mono text-blue-300 break-all">
                    worldleaguefantasy@gmail.com
                  </div>
                  <button 
                    onClick={copyPix}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-all shadow-lg active:scale-90"
                    title="Copiar PIX"
                  >
                    {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                {copied && <p className="text-[9px] font-black text-green-500 uppercase tracking-widest text-center animate-in fade-in">Copiado para a área de transferência!</p>}
              </div>

              <div className="h-[1px] bg-white/5 w-full"></div>

              {/* Bank Transfer Section */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest px-1">
                   <CreditCard className="w-3 h-3 text-slate-500" /> Transferência Bancária
                </div>
                <div className="grid grid-cols-2 gap-4 text-[11px]">
                   <div className="space-y-1">
                      <p className="text-slate-600 font-black uppercase tracking-tighter">Banco</p>
                      <p className="text-white font-bold">Nu Pagamentos SA</p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-slate-600 font-black uppercase tracking-tighter">Agência</p>
                      <p className="text-white font-bold">0001</p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-slate-600 font-black uppercase tracking-tighter">Conta</p>
                      <p className="text-white font-bold">81349185-1</p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-slate-600 font-black uppercase tracking-tighter">CNPJ</p>
                      <p className="text-white font-bold">009.908.719-75</p>
                   </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] text-center">Envie o comprovante para confirmar sua vaga:</p>
              <a 
                href={`https://wa.me/5548988110881?text=Olá Diogo, segue comprovante de inscrição na FWL 2026 para o manager @${formData.sleeperId}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-3 w-full py-5 bg-green-600 hover:bg-green-500 text-white font-black uppercase tracking-[0.15em] rounded-2xl shadow-xl shadow-green-600/20 transition-all active:scale-95 group"
              >
                <MessageCircle className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                Enviar no WhatsApp
              </a>
            </div>
          </div>

          <div className="pt-8 border-t border-white/5 text-center space-y-6">
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Dúvidas? Entre em contato com a comissão.</p>
              <p className="text-xs font-black text-white italic uppercase tracking-tighter">Atenciosamente,</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm font-black text-blue-400 uppercase italic">Diogo Krieck</p>
              <p className="text-[8px] font-black text-slate-600 uppercase tracking-[0.4em]">Comissário FWL</p>
            </div>
            <button 
              onClick={onBack}
              className="text-[10px] font-black text-slate-500 hover:text-white uppercase tracking-[0.3em] transition-colors"
            >
              Voltar ao Menu
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0f1d] py-12 px-6 overflow-x-hidden">
      <div className="max-w-2xl mx-auto space-y-12 relative">
        <header className="flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Voltar</span>
          </button>
          <div className="text-right">
            <h1 className="text-2xl font-black text-white uppercase italic leading-none">FWL 2026</h1>
            <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Ficha de Inscrição</p>
          </div>
        </header>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 p-6 rounded-3xl flex items-start gap-5 text-red-500 animate-in slide-in-from-top-4 duration-300">
            <XCircle className="w-8 h-8 shrink-0 mt-1" />
            <div className="flex flex-col gap-2">
              <p className="text-sm font-black uppercase tracking-widest">Erro de Conexão com a Nuvem</p>
              <div className="bg-black/20 p-3 rounded-xl border border-red-500/20">
                <p className="text-[11px] font-mono leading-relaxed break-words">{error}</p>
              </div>
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mt-2">
                Dica: Certifique-se de que a tabela 'registrations' existe e as chaves de API estão corretas.
              </p>
            </div>
          </div>
        )}

        <div className="bg-[#1e293b]/20 border border-white/5 rounded-[2.5rem] p-8 md:p-12 shadow-2xl relative">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-4">
              <label className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <HelpCircle className="w-3 h-3 text-blue-500" /> Jogou a FWL 2025?
              </label>
              <div className="grid grid-cols-2 gap-4">
                {['Sim', 'Não'].map(opt => (
                  <button
                    key={opt}
                    type="button"
                    disabled={submitting}
                    onClick={() => setFormData({...formData, played2025: opt})}
                    className={`py-4 rounded-2xl font-black uppercase text-xs tracking-widest border transition-all ${
                      formData.played2025 === opt 
                      ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-500/20' 
                      : 'bg-white/5 border-white/10 text-slate-500 hover:bg-white/10'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-2">Nome Completo</label>
                <input required disabled={submitting} type="text" value={formData.fullName} onChange={(e) => setFormData({...formData, fullName: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm text-white focus:border-blue-500 outline-none transition-all disabled:opacity-50" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-2">CPF</label>
                <input required disabled={submitting} type="text" value={formData.cpf} onChange={(e) => setFormData({...formData, cpf: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm text-white focus:border-blue-500 outline-none transition-all disabled:opacity-50" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-2">ID no Sleeper</label>
                <input required disabled={submitting} type="text" value={formData.sleeperId} onChange={(e) => setFormData({...formData, sleeperId: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm text-white focus:border-blue-500 outline-none transition-all disabled:opacity-50" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-2">Contato WhatsApp</label>
                <input required disabled={submitting} type="tel" value={formData.whatsapp} onChange={(e) => setFormData({...formData, whatsapp: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm text-white focus:border-blue-500 outline-none transition-all disabled:opacity-50" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-2">E-mail</label>
              <input required disabled={submitting} type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm text-white focus:border-blue-500 outline-none transition-all disabled:opacity-50" />
            </div>

            <div className="space-y-4 pt-4">
              <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-2">Como conheceu a FWL?</label>
              <div className="grid grid-cols-1 gap-2">
                {['Joguei em 2025', 'Indicação de amigo', 'Google ou Midias Sociais', 'Convite do Comissário', 'outros'].map(opt => (
                  <button key={opt} type="button" disabled={submitting} onClick={() => setFormData({...formData, howDidYouKnow: opt})} className={`px-6 py-4 rounded-2xl text-left text-sm font-bold border transition-all ${formData.howDidYouKnow === opt ? 'bg-blue-600/20 border-blue-500 text-blue-400' : 'bg-white/5 border-white/5 text-slate-500 hover:bg-white/10'}`}>
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            <button 
              type="submit" 
              disabled={submitting || !formData.played2025}
              className="w-full py-5 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white font-black uppercase tracking-[0.2em] rounded-2xl shadow-xl shadow-blue-500/20 transition-all active:scale-[0.98] flex items-center justify-center gap-3"
            >
              {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
              {submitting ? 'Acessando Banco de Dados...' : 'Enviar Inscrição'}
            </button>
          </form>
        </div>

        <footer className="text-center py-8 opacity-40 hover:opacity-100 transition-opacity">
           <button onClick={onAdmin} className="inline-flex items-center gap-2 text-[9px] font-black text-slate-500 uppercase tracking-widest">
             <Lock className="w-3 h-3" /> Área Restrita
           </button>
        </footer>
      </div>
    </div>
  );
};

export default RegistrationPage;
