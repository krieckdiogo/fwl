
import React, { useState, useEffect, useCallback } from 'react';
import { 
  fetchLeagueData, 
  fetchMatchupsForWeek, 
  fetchTransactions, 
  fetchDrafts, 
  fetchDraftPicks,
  getAvatarUrl, 
  fetchPlayers 
} from '../services/sleeper';
import { League, User, Roster, Matchup, Player, Transaction } from '../types';
import { 
  ArrowLeft, 
  LayoutGrid, 
  Zap, 
  Users, 
  History, 
  Award, 
  Shield, 
  RefreshCw, 
  AlertCircle,
  Clock
} from 'lucide-react';

interface SleeperLeaguePageProps {
  leagueId: string;
  onBack: () => void;
}

type Tab = 'standings' | 'matchups' | 'rosters' | 'activity' | 'draft';

const SleeperLeaguePage: React.FC<SleeperLeaguePageProps> = ({ leagueId, onBack }) => {
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>('standings');
  const [data, setData] = useState<{
    league: League;
    users: User[];
    rosters: Roster[];
    matchups: Matchup[];
    transactions: Transaction[];
    drafts: any[];
    players: Record<string, Player>;
  } | null>(null);
  const [week, setWeek] = useState(1);
  const [error, setError] = useState<string | null>(null);

  const loadLeagueData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const baseData = await fetchLeagueData(leagueId);
      const drafts = await fetchDrafts(leagueId);
      const players = await fetchPlayers();
      
      setData({
        ...baseData,
        drafts,
        players
      });
      setWeek(baseData.league.settings.leg || 1);
    } catch (err) {
      console.error(err);
      setError("Não foi possível carregar a liga. Verifique se o ID está correto.");
    } finally {
      setLoading(false);
    }
  }, [leagueId]);

  useEffect(() => { loadLeagueData(); }, [loadLeagueData]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex flex-col items-center justify-center space-y-6">
        <RefreshCw className="w-12 h-12 text-blue-500 animate-spin" />
        <p className="text-slate-400 font-black uppercase tracking-widest text-[10px]">Conectando com Sleeper API...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex flex-col items-center justify-center p-6 text-center space-y-6">
        <AlertCircle className="w-16 h-16 text-red-500" />
        <div className="space-y-2">
          <h2 className="text-xl font-black text-white uppercase italic">Erro na Consulta</h2>
          <p className="text-slate-400 text-sm max-w-xs mx-auto">{error}</p>
        </div>
        <button onClick={onBack} className="px-8 py-3 bg-white/5 border border-white/10 rounded-full text-xs font-black uppercase tracking-widest hover:bg-white/10 transition-all">Voltar</button>
      </div>
    );
  }

  const { league, users, rosters, matchups, transactions, players } = data;

  const sortedStandings = [...rosters].sort((a, b) => {
    if (b.settings.wins !== a.settings.wins) return b.settings.wins - a.settings.wins;
    return b.settings.fpts - a.settings.fpts;
  });

  const getSleeperUser = (ownerId: string) => users.find(u => u.user_id === ownerId);

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200">
      {/* Dynamic Sidebar/Header feel */}
      <header className="bg-[#1e293b]/50 backdrop-blur-xl border-b border-white/5 sticky top-0 z-[100]">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full text-slate-500 hover:text-white transition-all">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-white/10 overflow-hidden shadow-2xl">
                {league.avatar ? <img src={getAvatarUrl(league.avatar)} className="w-full h-full object-cover" /> : <Shield className="w-full h-full p-3 text-blue-500" />}
              </div>
              <div>
                <h1 className="text-xl font-black text-white italic uppercase tracking-tighter leading-none">{league.name}</h1>
                <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest mt-1">Season {league.season} • {league.total_rosters} Teams</p>
              </div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-4 px-4 py-2 bg-black/20 rounded-2xl border border-white/5">
             <div className="text-right">
                <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">League ID</p>
                <p className="text-xs font-mono text-blue-400">{leagueId}</p>
             </div>
          </div>
        </div>

        <nav className="max-w-7xl mx-auto px-6 flex items-center gap-8 overflow-x-auto no-scrollbar">
          {[
            { id: 'standings', label: 'Classificação', icon: LayoutGrid },
            { id: 'matchups', label: 'Matchups', icon: Zap },
            { id: 'rosters', label: 'Teams', icon: Users },
            { id: 'activity', label: 'Activity', icon: History },
            { id: 'draft', label: 'Draft', icon: Award }
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as Tab)}
              className={`flex items-center gap-2 py-4 border-b-2 transition-all text-[11px] font-black uppercase tracking-widest whitespace-nowrap ${activeTab === tab.id ? 'border-blue-500 text-blue-500' : 'border-transparent text-slate-500 hover:text-slate-300'}`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="max-w-7xl mx-auto p-6 md:p-10 pb-32">
        {activeTab === 'standings' && (
          <div className="bg-[#1e293b]/30 border border-white/5 rounded-[2rem] overflow-hidden shadow-2xl animate-in fade-in duration-500">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-black/20 text-[10px] font-black text-slate-500 uppercase tracking-widest">
                  <tr>
                    <th className="px-8 py-5 text-center w-16">Rank</th>
                    <th className="px-4 py-5">Manager / Team</th>
                    <th className="px-4 py-5 text-center">Record</th>
                    <th className="px-8 py-5 text-right">Points</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {sortedStandings.map((r, idx) => {
                    const user = getSleeperUser(r.owner_id);
                    return (
                      <tr key={r.roster_id} className="hover:bg-white/5 transition-colors group">
                        <td className="px-8 py-6 text-center font-black text-sm text-slate-500 group-hover:text-white transition-colors">{idx + 1}</td>
                        <td className="px-4 py-6">
                          <div className="flex items-center gap-4">
                            <img src={getAvatarUrl(user?.avatar || null)} className="w-10 h-10 rounded-full border border-slate-700 p-0.5" />
                            <div className="flex flex-col min-w-0">
                               <span className="text-sm font-bold text-white leading-none">{user?.display_name || 'Anonymous'}</span>
                               <span className="text-[10px] font-black text-slate-500 uppercase tracking-tighter truncate max-w-[200px] mt-1 italic">{user?.metadata?.team_name || 'Team Name'}</span>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-6 text-center text-sm font-black text-blue-400">{r.settings.wins}W - {r.settings.losses}L</td>
                        <td className="px-8 py-6 text-right">
                          <div className="text-sm font-black text-white leading-none">{r.settings.fpts}.{r.settings.fpts_decimal}</div>
                          <div className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mt-1">Points For</div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'matchups' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
             <div className="flex items-center justify-between">
                <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest">Weekly Matchups • Week {week}</h3>
                <div className="flex items-center gap-2">
                   <Clock className="w-3 h-3 text-blue-500" />
                   <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Regular Season</span>
                </div>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {(() => {
                  const pairs: Record<number, Matchup[]> = {};
                  matchups.forEach(m => {
                    if (!pairs[m.matchup_id]) pairs[m.matchup_id] = [];
                    pairs[m.matchup_id].push(m);
                  });
                  return Object.entries(pairs).map(([id, teams]) => (
                    <div key={id} className="bg-[#1e293b]/30 border border-white/5 rounded-3xl p-6 space-y-4 hover:border-blue-500/30 transition-all shadow-xl">
                      {teams.map((t, idx) => {
                        const u = getSleeperUser(rosters.find(r => r.roster_id === t.roster_id)?.owner_id || "");
                        const isWin = teams.length === 2 && t.points > teams[idx === 0 ? 1 : 0].points;
                        return (
                          <div key={t.roster_id} className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                               <img src={getAvatarUrl(u?.avatar || null)} className={`w-9 h-9 rounded-full border ${isWin ? 'border-blue-500' : 'border-slate-800'}`} />
                               <span className={`text-xs font-bold truncate max-w-[120px] ${isWin ? 'text-white' : 'text-slate-500'}`}>{u?.display_name}</span>
                            </div>
                            <div className={`text-lg font-black italic ${isWin ? 'text-blue-400' : 'text-slate-600'}`}>{t.points.toFixed(2)}</div>
                          </div>
                        );
                      })}
                    </div>
                  ));
                })()}
             </div>
          </div>
        )}

        {activeTab === 'rosters' && (
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in duration-500">
             {rosters.map(r => {
               const user = getSleeperUser(r.owner_id);
               return (
                 <div key={r.roster_id} className="bg-[#1e293b]/20 border border-white/5 rounded-[2.5rem] p-8 space-y-6">
                   <div className="flex items-center gap-4 pb-4 border-b border-white/5">
                      <img src={getAvatarUrl(user?.avatar || null)} className="w-14 h-14 rounded-full border border-blue-500/50 p-0.5" />
                      <div>
                        <h4 className="text-lg font-black text-white italic uppercase tracking-tighter">{user?.display_name}</h4>
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">{user?.metadata?.team_name || 'Team Unknown'}</p>
                      </div>
                   </div>
                   <div className="grid grid-cols-1 gap-2">
                     <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-1">Roster Players</p>
                     {r.players.slice(0, 10).map(pid => {
                       const p = players[pid];
                       return (
                         <div key={pid} className="flex items-center justify-between py-2 px-4 bg-white/5 rounded-xl border border-transparent hover:border-white/10">
                           <div className="flex items-center gap-3">
                             <div className="w-8 h-8 rounded-full bg-slate-900 border border-white/5 flex items-center justify-center overflow-hidden">
                               <img src={`https://sleepercdn.com/content/nfl/players/thumb/${pid}.jpg`} className="w-full h-full object-cover" onError={(e) => (e.currentTarget.src = 'https://sleepercdn.com/images/v2/icons/player_default.webp')} />
                             </div>
                             <span className="text-xs font-bold text-slate-300">{p?.full_name || pid}</span>
                           </div>
                           <span className="text-[9px] font-black text-blue-500 uppercase">{p?.position} • {p?.team}</span>
                         </div>
                       );
                     })}
                     {r.players.length > 10 && <p className="text-center text-[9px] font-bold text-slate-600 uppercase pt-2">... and {r.players.length - 10} more players</p>}
                   </div>
                 </div>
               );
             })}
           </div>
        )}

        {activeTab === 'activity' && (
           <div className="max-w-3xl mx-auto space-y-6 animate-in slide-in-from-right-4 duration-500">
             <div className="flex items-center gap-3 mb-6">
                <History className="w-5 h-5 text-blue-500" />
                <h3 className="text-xs font-black text-white uppercase tracking-widest">Recent League Activity</h3>
             </div>
             {transactions.length > 0 ? transactions.map(t => (
               <div key={t.transaction_id} className="bg-white/5 border border-white/5 rounded-[2rem] p-8 flex items-start gap-6 hover:bg-white/[0.07] transition-all">
                  <div className={`p-3 rounded-2xl ${t.type === 'trade' ? 'bg-purple-500/10 text-purple-500' : 'bg-green-500/10 text-green-500'}`}>
                    {t.type === 'trade' ? <Users className="w-5 h-5" /> : <Zap className="w-5 h-5" />}
                  </div>
                  <div className="space-y-3 flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-black text-white uppercase tracking-widest">{t.type === 'trade' ? 'Player Trade' : 'Waiver/FA Add'}</p>
                      <span className="text-[9px] font-mono text-slate-500">{new Date(t.created).toLocaleDateString()}</span>
                    </div>
                    <div className="space-y-2">
                       {t.adds && Object.keys(t.adds).map(pid => (
                         <div key={pid} className="flex items-center gap-2">
                           <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                           <span className="text-xs text-slate-300">Added <strong className="text-white">{players[pid]?.full_name || pid}</strong></span>
                         </div>
                       ))}
                       {t.drops && Object.keys(t.drops).map(pid => (
                         <div key={pid} className="flex items-center gap-2">
                           <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div>
                           <span className="text-xs text-slate-300">Dropped <strong className="text-white">{players[pid]?.full_name || pid}</strong></span>
                         </div>
                       ))}
                    </div>
                  </div>
               </div>
             )) : (
               <div className="text-center py-20 bg-white/5 rounded-[2.5rem] border border-dashed border-white/10">
                 <p className="text-slate-500 font-black uppercase tracking-widest text-xs">Sem transações recentes para a semana {week}.</p>
               </div>
             )}
           </div>
        )}

        {activeTab === 'draft' && (
           <div className="text-center py-32 space-y-6 animate-in zoom-in duration-500">
              <Award className="w-20 h-20 text-blue-500 mx-auto opacity-30" />
              <div>
                <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter">Draft Central</h3>
                <p className="text-slate-500 text-sm max-w-sm mx-auto mt-2">Esta funcionalidade está em beta. O histórico completo de picks de cada rodada estará disponível na próxima atualização.</p>
              </div>
              <div className="flex flex-wrap justify-center gap-4">
                 {data.drafts.map((d: any) => (
                   <div key={d.draft_id} className="px-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-left">
                      <p className="text-[8px] font-black text-blue-500 uppercase tracking-widest mb-1">Draft Type: {d.type}</p>
                      <p className="text-sm font-bold text-white">Status: {d.status}</p>
                      <p className="text-[10px] text-slate-500 mt-1">{d.rounds} Rounds • {d.settings.teams} Teams</p>
                   </div>
                 ))}
              </div>
           </div>
        )}
      </main>

      <footer className="fixed bottom-0 left-0 w-full bg-[#0f172a]/95 backdrop-blur-md border-t border-white/[0.05] py-5 px-6 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] italic">
           <div className="flex items-center gap-3 text-blue-500">
             <Shield className="w-4 h-4" />
             <span>Sleeper High-Fidelity Data Engine v1.0</span>
           </div>
           <span>League Explorer • ID {leagueId}</span>
        </div>
      </footer>
    </div>
  );
};

export default SleeperLeaguePage;
