
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  fetchLeagueData, 
  fetchMatchupsForWeek, 
  fetchTransactions, 
  fetchDrafts, 
  fetchDraftPicks,
  getAvatarUrl, 
  fetchPlayers,
  getPlayerImageUrl
} from '../services/sleeper';
import { League, User, Roster, Matchup, Player, Transaction } from '../types';
// Added Crown to fix "Cannot find name 'Crown'" error on line 310
import { 
  ArrowLeft, 
  LayoutGrid, 
  Zap, 
  Users, 
  History, 
  Award, 
  Shield, 
  RefreshCw, 
  AlertCircle,
  Clock,
  ExternalLink,
  ChevronRight,
  User as UserIcon,
  TrendingUp,
  Filter,
  Calendar,
  Crown
} from 'lucide-react';

interface SleeperLeaguePageProps {
  leagueId: string;
  onBack: () => void;
}

type Tab = 'standings' | 'matchups' | 'rosters' | 'activity' | 'draft';

const SleeperLeaguePage: React.FC<SleeperLeaguePageProps> = ({ leagueId, onBack }) => {
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>('standings');
  const [data, setData] = useState<{
    league: League;
    users: User[];
    rosters: Roster[];
    matchups: Matchup[];
    transactions: Transaction[];
    drafts: any[];
    draftPicks: any[];
    players: Record<string, Player>;
  } | null>(null);
  const [week, setWeek] = useState(1);
  const [selectedWeek, setSelectedWeek] = useState(1);
  const [error, setError] = useState<string | null>(null);
  const [loadingContent, setLoadingContent] = useState(false);

  const loadLeagueData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const baseData = await fetchLeagueData(leagueId);
      const drafts = await fetchDrafts(leagueId);
      const players = await fetchPlayers();
      
      let draftPicks: any[] = [];
      if (drafts.length > 0) {
        draftPicks = await fetchDraftPicks(drafts[0].draft_id);
      }
      
      setData({
        ...baseData,
        drafts,
        draftPicks,
        players
      });
      const currentWeek = baseData.league.settings.leg || 1;
      setWeek(currentWeek);
      setSelectedWeek(currentWeek);
    } catch (err) {
      console.error(err);
      setError("Não foi possível carregar a liga. Verifique se o ID está correto ou se a liga é pública.");
    } finally {
      setLoading(false);
    }
  }, [leagueId]);

  useEffect(() => { loadLeagueData(); }, [loadLeagueData]);

  const handleWeekChange = async (w: number) => {
    if (!data) return;
    setSelectedWeek(w);
    setLoadingContent(true);
    try {
      const newMatchups = await fetchMatchupsForWeek(leagueId, w);
      const newTransactions = await fetchTransactions(leagueId, w);
      setData(prev => prev ? { ...prev, matchups: newMatchups, transactions: newTransactions } : null);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingContent(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex flex-col items-center justify-center space-y-6">
        <div className="relative">
          <RefreshCw className="w-16 h-16 text-blue-500 animate-spin" />
          <div className="absolute inset-0 bg-blue-500/20 blur-2xl rounded-full"></div>
        </div>
        <div className="text-center space-y-2">
          <h2 className="text-white font-black text-xl uppercase tracking-[0.2em] italic">High-Fidelity Link</h2>
          <p className="text-slate-400 font-black uppercase tracking-widest text-[10px] animate-pulse">Sincronizando Sleeper Engine para ID {leagueId}</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex flex-col items-center justify-center p-6 text-center space-y-8">
        <div className="p-6 bg-red-500/10 rounded-full border border-red-500/20">
          <AlertCircle className="w-16 h-16 text-red-500" />
        </div>
        <div className="space-y-3">
          <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter">Erro na Conexão</h2>
          <p className="text-slate-400 text-sm max-w-xs mx-auto leading-relaxed font-medium">{error}</p>
        </div>
        <button onClick={onBack} className="px-10 py-4 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-all active:scale-95 flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" /> Voltar ao Início
        </button>
      </div>
    );
  }

  const { league, users, rosters, matchups, transactions, players, draftPicks } = data;

  const sortedStandings = [...rosters].sort((a, b) => {
    if (b.settings.wins !== a.settings.wins) return b.settings.wins - a.settings.wins;
    return (b.settings.fpts + b.settings.fpts_decimal / 100) - (a.settings.fpts + a.settings.fpts_decimal / 100);
  });

  const getSleeperUser = (ownerId: string) => users.find(u => u.user_id === ownerId);

  const getPosColor = (pos: string) => {
    switch (pos) {
      case 'QB': return 'bg-pink-500/20 text-pink-400 border-pink-500/30';
      case 'RB': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'WR': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'TE': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'DEF': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'K': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-200 flex flex-col font-sans selection:bg-blue-500/30">
      {/* Sleeper-inspired Sticky Header */}
      <header className="bg-[#111827]/80 backdrop-blur-2xl border-b border-white/5 sticky top-0 z-[100] shadow-2xl">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <button onClick={onBack} className="p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-2xl text-slate-400 hover:text-white transition-all active:scale-90">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-5">
              <div className="w-14 h-14 rounded-[1.25rem] bg-slate-900 border border-white/10 overflow-hidden shadow-[0_0_30px_rgba(59,130,246,0.15)] group relative">
                {league.avatar ? (
                  <img src={getAvatarUrl(league.avatar)} className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                ) : (
                  <Shield className="w-full h-full p-4 text-blue-500" />
                )}
              </div>
              <div className="min-w-0">
                <h1 className="text-xl font-black text-white italic uppercase tracking-tighter leading-none mb-1.5 truncate">{league.name}</h1>
                <div className="flex items-center gap-2.5">
                   <div className="px-2 py-0.5 bg-blue-600/10 border border-blue-500/20 rounded text-[8px] font-black text-blue-400 uppercase tracking-widest">Season {league.season}</div>
                   <div className="w-1 h-1 bg-slate-700 rounded-full"></div>
                   <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{league.total_rosters} Teams Registered</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             <div className="hidden lg:flex flex-col text-right px-4 border-r border-white/10">
                <p className="text-[8px] font-black text-slate-500 uppercase tracking-[0.2em]">Platform Instance</p>
                <p className="text-[10px] font-mono text-blue-400 tracking-tighter">sleeper_v1_api_link_{leagueId}</p>
             </div>
             <a 
               href={`https://sleeper.app/leagues/${leagueId}`} 
               target="_blank" 
               rel="noreferrer"
               className="p-4 bg-blue-600 hover:bg-blue-500 text-white rounded-[1.25rem] transition-all shadow-xl shadow-blue-600/20 flex items-center gap-3 group"
             >
               <span className="text-[10px] font-black uppercase tracking-widest hidden sm:inline">App View</span>
               <ExternalLink className="w-4 h-4 group-hover:rotate-12 transition-transform" />
             </a>
          </div>
        </div>

        {/* Improved Navigation Tabs */}
        <nav className="max-w-7xl mx-auto px-6 flex items-center gap-2 sm:gap-6 overflow-x-auto no-scrollbar pt-2">
          {[
            { id: 'standings', label: 'League', icon: LayoutGrid },
            { id: 'matchups', label: 'Matchups', icon: Zap },
            { id: 'rosters', label: 'Teams', icon: Users },
            { id: 'activity', label: 'Feed', icon: History },
            { id: 'draft', label: 'Draft Board', icon: Award }
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as Tab)}
              className={`flex items-center gap-3 px-6 py-5 border-b-[3px] transition-all text-[11px] font-black uppercase tracking-[0.15em] whitespace-nowrap group ${
                activeTab === tab.id 
                ? 'border-blue-500 text-blue-500 bg-blue-500/5' 
                : 'border-transparent text-slate-500 hover:text-slate-300'
              }`}
            >
              <tab.icon className={`w-4 h-4 transition-transform group-hover:scale-110 ${activeTab === tab.id ? 'text-blue-500' : 'text-slate-600 group-hover:text-slate-400'}`} />
              {tab.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="max-w-7xl mx-auto w-full p-6 md:p-8 flex-1">
        {/* Tab Content Header */}
        {['matchups', 'activity'].includes(activeTab) && (
          <div className="mb-8 flex items-center justify-between animate-in fade-in slide-in-from-top-2">
             <div className="flex items-center gap-4">
                <Calendar className="w-5 h-5 text-blue-500" />
                <h3 className="text-sm font-black text-white uppercase tracking-[0.2em] italic">Sincronização: Semana {selectedWeek}</h3>
             </div>
             <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar max-w-[200px] sm:max-w-none">
                {Array.from({ length: 18 }, (_, i) => i + 1).map(w => (
                  <button
                    key={w}
                    onClick={() => handleWeekChange(w)}
                    className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center text-[10px] font-black border transition-all ${
                      selectedWeek === w 
                      ? 'bg-blue-600 border-blue-500 text-white shadow-lg' 
                      : 'bg-[#1e293b]/40 border-white/5 text-slate-500 hover:border-white/20'
                    }`}
                  >
                    {w}
                  </button>
                ))}
             </div>
          </div>
        )}

        {loadingContent ? (
          <div className="py-40 flex flex-col items-center justify-center gap-6">
             <RefreshCw className="w-12 h-12 text-blue-500 animate-spin" />
             <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Querying Database...</p>
          </div>
        ) : (
          <div className="animate-in fade-in duration-500">
            {activeTab === 'standings' && (
              <div className="space-y-10">
                 {/* Standings Summary Grid */}
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-blue-600/5 border border-blue-500/20 p-8 rounded-[2.5rem] space-y-4">
                       <TrendingUp className="w-8 h-8 text-blue-400" />
                       <div>
                          <h4 className="text-xl font-black text-white leading-none mb-1">{sortedStandings[0] ? getSleeperUser(sortedStandings[0].owner_id)?.display_name : '---'}</h4>
                          <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Líder Atual da Liga</p>
                       </div>
                    </div>
                    <div className="bg-[#1e293b]/20 border border-white/5 p-8 rounded-[2.5rem] space-y-4">
                       <Zap className="w-8 h-8 text-yellow-500" />
                       <div>
                          <h4 className="text-xl font-black text-white leading-none mb-1">{Math.max(...rosters.map(r => r.settings.fpts)).toFixed(1)}</h4>
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Recorde de Pontos (PF)</p>
                       </div>
                    </div>
                    <div className="bg-[#1e293b]/20 border border-white/5 p-8 rounded-[2.5rem] space-y-4">
                       <Award className="w-8 h-8 text-purple-500" />
                       <div>
                          <h4 className="text-xl font-black text-white leading-none mb-1">{rosters.length} Managers</h4>
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">População Ativa</p>
                       </div>
                    </div>
                 </div>

                 <div className="bg-[#1e293b]/20 border border-white/5 rounded-[3rem] overflow-hidden shadow-2xl">
                    <div className="overflow-x-auto no-scrollbar">
                      <table className="w-full text-left">
                        <thead className="bg-black/40 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">
                          <tr>
                            <th className="px-8 py-6 text-center w-20">Rank</th>
                            <th className="px-4 py-6">Manager / Team Name</th>
                            <th className="px-4 py-6 text-center">Record</th>
                            <th className="px-4 py-6 text-center">PF (Points For)</th>
                            <th className="px-8 py-6 text-right">PA (Against)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {sortedStandings.map((r, idx) => {
                            const user = getSleeperUser(r.owner_id);
                            return (
                              <tr key={r.roster_id} className="hover:bg-white/5 transition-all group cursor-default">
                                <td className="px-8 py-7 text-center font-mono font-black text-lg text-slate-600 group-hover:text-blue-400 transition-colors">{idx + 1}</td>
                                <td className="px-4 py-7">
                                  <div className="flex items-center gap-5">
                                    <div className="relative shrink-0">
                                      <img src={getAvatarUrl(user?.avatar || null)} className="w-12 h-12 rounded-full border-2 border-slate-800 p-0.5 transition-transform group-hover:scale-110" alt="" />
                                      {idx === 0 && <Crown className="absolute -top-2 -right-2 w-5 h-5 text-yellow-500 drop-shadow-[0_0_8px_rgba(234,179,8,0.5)] fill-current" />}
                                    </div>
                                    <div className="flex flex-col min-w-0">
                                       <span className="text-base font-bold text-white leading-tight truncate">{user?.display_name || 'Anonymous'}</span>
                                       <span className="text-[10px] font-black text-slate-500 uppercase tracking-tighter truncate max-w-[240px] mt-1 italic">{user?.metadata?.team_name || 'Team Name Undefined'}</span>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-4 py-7 text-center">
                                   <div className="text-base font-black text-blue-400 leading-none mb-1">{r.settings.wins}W - {r.settings.losses}L</div>
                                   <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Pct: {((r.settings.wins / (r.settings.wins + r.settings.losses || 1)) * 100).toFixed(0)}%</p>
                                </td>
                                <td className="px-4 py-7 text-center">
                                  <div className="text-base font-black text-white">{r.settings.fpts}.{String(r.settings.fpts_decimal).padStart(2, '0')}</div>
                                </td>
                                <td className="px-8 py-7 text-right">
                                  <div className="text-base font-black text-slate-400">{r.settings.ppts || 0}.{String(r.settings.ppts_decimal || 0).padStart(2, '0')}</div>
                                  <div className="text-[8px] font-bold text-slate-700 uppercase tracking-widest mt-1">Difficulty metric</div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                 </div>
              </div>
            )}

            {activeTab === 'matchups' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {matchups.length > 0 ? (() => {
                  const pairs: Record<number, Matchup[]> = {};
                  matchups.forEach(m => {
                    if (!pairs[m.matchup_id]) pairs[m.matchup_id] = [];
                    pairs[m.matchup_id].push(m);
                  });
                  return Object.entries(pairs).map(([id, teams]) => (
                    <div key={id} className="bg-[#1e293b]/30 border border-white/5 rounded-[2.5rem] p-8 space-y-8 hover:border-blue-500/40 transition-all shadow-2xl relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                         <Zap className="w-20 h-20 text-white" />
                      </div>
                      {teams.map((t, idx) => {
                        const u = getSleeperUser(rosters.find(r => r.roster_id === t.roster_id)?.owner_id || "");
                        const otherTeam = teams[idx === 0 ? 1 : 0];
                        const isWin = otherTeam && t.points > otherTeam.points;
                        return (
                          <div key={t.roster_id} className="flex items-center justify-between relative z-10">
                            <div className="flex items-center gap-5">
                               <img src={getAvatarUrl(u?.avatar || null)} className={`w-12 h-12 rounded-full border-2 transition-all ${isWin ? 'border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.3)]' : 'border-slate-800'}`} />
                               <div className="flex flex-col min-w-0">
                                  <span className={`text-sm font-bold truncate max-w-[120px] transition-colors ${isWin ? 'text-white' : 'text-slate-500'}`}>{u?.display_name}</span>
                                  <span className="text-[8px] font-black text-slate-600 uppercase tracking-widest">Roster #{t.roster_id}</span>
                               </div>
                            </div>
                            <div className={`text-2xl font-black italic tracking-tighter ${isWin ? 'text-blue-400 drop-shadow-[0_0_8px_rgba(96,165,250,0.4)]' : 'text-slate-600'}`}>{t.points.toFixed(2)}</div>
                          </div>
                        );
                      })}
                      {teams.length === 2 && (
                         <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                            <span className="text-[8px] font-black text-slate-600 uppercase tracking-widest">Spread: {Math.abs(teams[0].points - teams[1].points).toFixed(2)} pts</span>
                            <ChevronRight className="w-4 h-4 text-slate-800 group-hover:text-blue-500 transition-colors" />
                         </div>
                      )}
                    </div>
                  ));
                })() : (
                  <div className="col-span-full py-40 text-center bg-[#1e293b]/10 rounded-[3rem] border border-dashed border-white/5 space-y-6">
                     <AlertCircle className="w-16 h-16 text-slate-800 mx-auto" />
                     <div className="space-y-1">
                        <p className="text-white font-black uppercase tracking-widest text-lg italic">Sem Jogos Carregados</p>
                        <p className="text-slate-500 font-medium text-xs max-w-xs mx-auto">Não encontramos dados de confrontos para a liga {leagueId} na semana {selectedWeek}.</p>
                     </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'rosters' && (
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                 {rosters.map(r => {
                   const user = getSleeperUser(r.owner_id);
                   return (
                     <div key={r.roster_id} className="bg-[#1e293b]/20 border border-white/5 rounded-[3rem] p-8 space-y-8 flex flex-col hover:bg-[#1e293b]/30 transition-all shadow-xl group">
                       <div className="flex items-center gap-5 pb-6 border-b border-white/5">
                          <img src={getAvatarUrl(user?.avatar || null)} className="w-16 h-16 rounded-full border-2 border-blue-500/50 p-0.5 group-hover:scale-105 transition-transform" />
                          <div className="min-w-0">
                            <h4 className="text-lg font-black text-white italic uppercase tracking-tighter truncate leading-tight">{user?.display_name}</h4>
                            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1 truncate">{user?.metadata?.team_name || 'Generic Team'}</p>
                          </div>
                       </div>
                       <div className="space-y-3 flex-1 overflow-y-auto no-scrollbar max-h-[400px]">
                         <p className="text-[8px] font-black text-slate-600 uppercase tracking-[0.25em] px-2">Official Roster Composition</p>
                         {r.starters.map(pid => {
                           const p = players[pid];
                           return (
                             <div key={pid} className="flex items-center justify-between p-3 bg-white/5 rounded-2xl border border-transparent hover:border-blue-500/20 group/pl transition-all">
                               <div className="flex items-center gap-4">
                                 <div className="w-10 h-10 rounded-full bg-slate-800 border border-white/5 overflow-hidden shadow-lg group-hover/pl:scale-110 transition-transform">
                                   <img src={getPlayerImageUrl(pid, p?.position || '')} className="w-full h-full object-cover" onError={(e) => (e.currentTarget.src = 'https://sleepercdn.com/images/v2/icons/player_default.webp')} />
                                 </div>
                                 <div className="flex flex-col">
                                   <span className="text-xs font-bold text-slate-200 group-hover/pl:text-white transition-colors">{p?.full_name || pid}</span>
                                   <span className="text-[9px] font-black text-slate-500 uppercase tracking-tighter italic">{p?.team || 'FA'} • STARTER</span>
                                 </div>
                               </div>
                               <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase border ${getPosColor(p?.position || '')}`}>{p?.position}</span>
                             </div>
                           );
                         })}
                         <div className="pt-4 px-2 space-y-2">
                           <p className="text-[7px] font-black text-slate-700 uppercase tracking-widest">Bench Players ({r.players.length - r.starters.length})</p>
                           <div className="flex flex-wrap gap-2">
                              {r.players.filter(p => !r.starters.includes(p)).slice(0, 8).map(pid => (
                                <div key={pid} className={`px-2 py-1 rounded-lg text-[8px] font-bold uppercase border bg-black/40 ${getPosColor(players[pid]?.position || '')}`}>{players[pid]?.position || '??'}</div>
                              ))}
                              {r.players.length > (r.starters.length + 8) && <div className="text-[8px] text-slate-600 font-black">+ {r.players.length - r.starters.length - 8} MORE</div>}
                           </div>
                         </div>
                       </div>
                     </div>
                   );
                 })}
               </div>
            )}

            {activeTab === 'activity' && (
               <div className="max-w-3xl mx-auto space-y-8">
                 {transactions.length > 0 ? transactions.map(t => (
                   <div key={t.transaction_id} className="bg-[#1e293b]/30 border border-white/5 rounded-[2.5rem] p-10 flex items-start gap-8 hover:bg-white/[0.05] transition-all group shadow-xl relative overflow-hidden">
                      <div className={`p-5 rounded-3xl shrink-0 shadow-lg ${t.type === 'trade' ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'}`}>
                        {t.type === 'trade' ? <Users className="w-8 h-8" /> : <Zap className="w-8 h-8" />}
                      </div>
                      <div className="space-y-6 flex-1 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="space-y-1">
                             <p className="text-sm font-black text-white uppercase italic tracking-widest leading-none">{t.type === 'trade' ? 'Blockbuster Trade' : (t.type === 'waiver' ? 'Waiver Claim' : 'Free Agent Move')}</p>
                             <div className="flex items-center gap-3">
                                {t.roster_ids.map(rid => {
                                   const u = getSleeperUser(rosters.find(r => r.roster_id === rid)?.owner_id || "");
                                   return (
                                     <span key={rid} className="text-[10px] font-black text-blue-500 uppercase tracking-tighter group-hover:text-blue-400 transition-colors">@{u?.display_name}</span>
                                   );
                                })}
                             </div>
                          </div>
                          <div className="flex items-center gap-3 px-3 py-1 bg-black/40 rounded-full border border-white/5">
                            <Clock className="w-3 h-3 text-slate-600" />
                            <span className="text-[9px] font-mono text-slate-500">{new Date(t.created).toLocaleDateString()}</span>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4 border-t border-white/5">
                           {t.adds && (
                             <div className="space-y-4">
                                <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest flex items-center gap-2">
                                   <Shield className="w-3 h-3" /> Acquisition List
                                </p>
                                <div className="space-y-3">
                                   {Object.keys(t.adds).map(pid => (
                                     <div key={pid} className="flex items-center gap-4 bg-emerald-500/5 p-3 rounded-2xl border border-emerald-500/10">
                                       <div className="w-8 h-8 rounded-full bg-slate-800 overflow-hidden border border-emerald-500/20">
                                          <img src={getPlayerImageUrl(pid, players[pid]?.position || '')} className="w-full h-full object-cover" />
                                       </div>
                                       <div className="flex flex-col min-w-0">
                                          <span className="text-xs font-bold text-white truncate">{players[pid]?.full_name || pid}</span>
                                          <span className="text-[8px] font-black text-emerald-600 uppercase">{players[pid]?.position} • {players[pid]?.team}</span>
                                       </div>
                                     </div>
                                   ))}
                                </div>
                             </div>
                           )}
                           {t.drops && (
                             <div className="space-y-4">
                                <p className="text-[9px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2">
                                   <AlertCircle className="w-3 h-3" /> Drop Record
                                </p>
                                <div className="space-y-3">
                                   {Object.keys(t.drops).map(pid => (
                                     <div key={pid} className="flex items-center gap-4 bg-red-500/5 p-3 rounded-2xl border border-red-500/10 opacity-60 grayscale-[0.5]">
                                       <div className="w-8 h-8 rounded-full bg-slate-800 overflow-hidden border border-red-500/20">
                                          <img src={getPlayerImageUrl(pid, players[pid]?.position || '')} className="w-full h-full object-cover" />
                                       </div>
                                       <div className="flex flex-col min-w-0">
                                          <span className="text-xs font-bold text-slate-300 truncate">{players[pid]?.full_name || pid}</span>
                                          <span className="text-[8px] font-black text-red-700 uppercase">{players[pid]?.position} • {players[pid]?.team}</span>
                                       </div>
                                     </div>
                                   ))}
                                </div>
                             </div>
                           )}
                        </div>
                      </div>
                   </div>
                 )) : (
                   <div className="text-center py-40 bg-white/5 rounded-[3rem] border border-dashed border-white/5 space-y-6">
                     <History className="w-16 h-16 text-slate-800 mx-auto" />
                     <div className="space-y-1">
                        <p className="text-white font-black uppercase tracking-widest text-lg italic">Nenhuma Atividade</p>
                        <p className="text-slate-500 font-medium text-xs max-w-xs mx-auto">Sem transações registradas para esta semana na liga.</p>
                     </div>
                   </div>
                 )}
               </div>
            )}

            {activeTab === 'draft' && (
               <div className="space-y-10">
                 <div className="flex items-center justify-between bg-blue-600/10 border border-blue-500/30 p-8 rounded-[2.5rem] shadow-xl">
                    <div className="flex items-center gap-6">
                       <Award className="w-10 h-10 text-blue-400" />
                       <div>
                          <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter leading-none mb-1.5">Draft Board</h3>
                          <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Season Foundation • Consolidated Picks</p>
                       </div>
                    </div>
                    <div className="text-right">
                       <p className="text-xs font-mono text-slate-500">{data.drafts[0]?.draft_id || 'ID_PENDING'}</p>
                       <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mt-1">Status: {data.drafts[0]?.status || 'FINISHED'}</p>
                    </div>
                 </div>

                 {draftPicks.length > 0 ? (
                   <div className="bg-[#1e293b]/20 border border-white/5 rounded-[3rem] p-4 lg:p-10 shadow-2xl">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                         {draftPicks.map((pick: any) => {
                           const p = players[pick.player_id];
                           const user = users.find(u => u.user_id === pick.picked_by);
                           return (
                             <div key={`${pick.round}-${pick.pick_no}`} className="bg-black/40 border border-white/10 p-5 rounded-3xl flex items-center gap-4 hover:border-blue-500/40 transition-all group/pick overflow-hidden relative">
                               <div className="absolute top-2 right-4 text-[40px] font-black text-white/5 font-mono italic leading-none group-hover/pick:text-blue-500/10 transition-colors">{pick.round}.{String(pick.draft_slot).padStart(2, '0')}</div>
                               <div className="relative shrink-0">
                                 <div className="w-12 h-12 rounded-full bg-slate-900 border border-white/10 overflow-hidden group-hover/pick:scale-105 transition-transform">
                                   <img src={getPlayerImageUrl(pick.player_id, p?.position || '')} className="w-full h-full object-cover" onError={(e) => (e.currentTarget.src = 'https://sleepercdn.com/images/v2/icons/player_default.webp')} />
                                 </div>
                                 <div className={`absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded text-[7px] font-black uppercase border ${getPosColor(p?.position || '')}`}>{p?.position || '??'}</div>
                               </div>
                               <div className="flex-1 min-w-0 relative z-10">
                                  <h5 className="text-xs font-black text-white uppercase truncate">{p?.full_name || pick.metadata.full_name || 'Unknown'}</h5>
                                  <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mt-0.5 truncate">{p?.team || pick.metadata.team || 'FA'} • Pick {pick.pick_no}</p>
                                  <div className="flex items-center gap-1.5 mt-2">
                                     <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                                     <span className="text-[8px] font-bold text-blue-400 uppercase tracking-widest truncate">@{user?.display_name || 'Manager'}</span>
                                  </div>
                               </div>
                             </div>
                           );
                         })}
                      </div>
                   </div>
                 ) : (
                   <div className="text-center py-40 bg-white/5 rounded-[3rem] border border-dashed border-white/5 space-y-6">
                     <Award className="w-16 h-16 text-slate-800 mx-auto" />
                     <div className="space-y-1">
                        <p className="text-white font-black uppercase tracking-widest text-lg italic">Draft Data Missing</p>
                        <p className="text-slate-500 font-medium text-xs max-w-xs mx-auto">Os dados do draft ainda estão sendo compilados ou não estão públicos para esta liga.</p>
                     </div>
                   </div>
                 )}
               </div>
            )}
          </div>
        )}
      </main>

      <footer className="bg-[#111827]/95 backdrop-blur-md border-t border-white/[0.05] py-6 px-10 z-[50]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-[9px] font-black text-slate-500 uppercase tracking-[0.3em] italic">
           <div className="flex items-center gap-4">
             <div className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse"></div>
             <span>Sleeper High-Fidelity Data Protocol v2.5.4</span>
           </div>
           <div className="flex items-center gap-8">
              <span>League Instance: {leagueId}</span>
              <span>Ref: API_SLP_NFL_{league.season}</span>
              <span className="text-slate-700">© 2025 FWL Digital Engine</span>
           </div>
        </div>
      </footer>
    </div>
  );
};

export default SleeperLeaguePage;
