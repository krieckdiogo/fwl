import React from 'react';
// Added missing CheckCircle2 and Layers imports
import { ArrowLeft, Shield, Award, Info, Zap, Sword, Trophy, Users, RefreshCw, Star, Ban, CheckCircle2, Layers } from 'lucide-react';

interface RegulationPageProps {
  onBack: () => void;
}

const RegulationPage: React.FC<RegulationPageProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-[#0a0f1d] text-slate-200 py-12 px-6">
      <div className="max-w-3xl mx-auto space-y-12">
        {/* Header */}
        <header className="flex items-center justify-between sticky top-0 bg-[#0a0f1d]/90 backdrop-blur-xl py-4 z-50 border-b border-white/5 -mx-6 px-6">
          <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Voltar</span>
          </button>
          <div className="text-right">
            <h1 className="text-2xl font-black text-white uppercase italic leading-none">Regulamento</h1>
            <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Temporada 2026</p>
          </div>
        </header>

        {/* Content */}
        <div className="bg-[#1e293b]/20 border border-white/5 rounded-[3rem] p-8 md:p-12 shadow-2xl space-y-12 leading-relaxed">
          
          <section className="space-y-4">
            <div className="flex items-center gap-3 text-blue-400">
               <Info className="w-6 h-6" />
               <h2 className="text-2xl font-black uppercase italic tracking-tight">Introdução</h2>
            </div>
            <p className="text-slate-400 font-medium">
              Este regulamento estabelece as diretrizes da Fantasy World League (FWL) para a temporada de 2026. Ao se inscrever na competição, presume-se que cada participante, doravante denominado <strong>Competidor</strong>, tenha lido e aceito integralmente o Regulamento descrito, demonstrando plena compreensão das regras e procedimentos. A FWL reserva-se o direito de alterar o regulamento a qualquer momento, sem notificação prévia.
            </p>
            <div className="grid gap-3 pt-4">
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex gap-4">
                 <Shield className="w-5 h-5 text-blue-500 shrink-0" />
                 <p className="text-xs font-bold text-slate-300">Ao participar da FWL, os Competidores concordam em cumprir as regras estabelecidas e as regras gerais de Fantasy Football.</p>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex gap-4">
                 <Ban className="w-5 h-5 text-red-500 shrink-0" />
                 <p className="text-xs font-bold text-slate-300">Não será permitido que o mesmo competidor tenha mais de um time dentro da FWL (multi-account).</p>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex gap-4">
                 <Trophy className="w-5 h-5 text-yellow-500 shrink-0" />
                 <p className="text-xs font-bold text-slate-300">A FWL é uma associação de ligas. Os pontos obtidos em suas ligas acumulam no Ranking FWL. Ao final da temporada, os 12 classificados disputarão a FWL Finals.</p>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex gap-4">
                 <RefreshCw className="w-5 h-5 text-green-500 shrink-0" />
                 <p className="text-xs font-bold text-slate-300">Utilizaremos a plataforma Sleeper.</p>
              </div>
            </div>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-3 text-blue-400">
               <Zap className="w-6 h-6" />
               <h2 className="text-2xl font-black uppercase italic tracking-tight">Formato da Competição</h2>
            </div>
            <p className="text-slate-400 font-medium">
              Para a temporada de 2026, a liga contará inicialmente com <strong>384 inscritos</strong>. Ao se inscrever, o competidor participará de 2 ligas (Divisional e Brady), porém estará disputando 3 campeonatos simultâneos:
            </p>

            {/* Divisional League Section */}
            <div className="space-y-6 p-8 bg-blue-900/10 border border-blue-500/20 rounded-[2rem]">
               <div className="flex items-center gap-2">
                 <Star className="w-4 h-4 text-blue-400" />
                 <h3 className="text-xl font-black text-white uppercase italic">1. Fantasy Divisional League</h3>
               </div>
               <p className="text-xs text-blue-200/60 uppercase font-black tracking-widest">32 Ligas de 12 Times Cada</p>
               
               <div className="space-y-4">
                 <h4 className="text-sm font-black text-slate-100 uppercase tracking-widest">Formação das Divisões (Sorteio por Potes)</h4>
                 <p className="text-sm text-slate-400">A distribuição dos times nas ligas respeitará o Ranking FWL do ano anterior:</p>
                 <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs font-bold text-slate-500">
                   <li className="p-3 bg-black/20 rounded-xl border border-white/5"><span className="text-blue-400">Pote 1:</span> 32 primeiros colocados</li>
                   <li className="p-3 bg-black/20 rounded-xl border border-white/5"><span className="text-blue-400">Pote 2:</span> 33º ao 64º colocado</li>
                   <li className="p-3 bg-black/20 rounded-xl border border-white/5"><span className="text-blue-400">Pote 3:</span> 65º ao 96º colocado</li>
                   <li className="p-3 bg-black/20 rounded-xl border border-white/5"><span className="text-blue-400">Pote 4:</span> 97º ao 128º colocado</li>
                   <li className="p-3 bg-black/20 rounded-xl border border-white/5 col-span-full"><span className="text-blue-400">Pote 5:</span> Restante dos inscritos (129º ao 384º)</li>
                 </ul>
               </div>

               <div className="space-y-4">
                 <h4 className="text-sm font-black text-slate-100 uppercase tracking-widest">Playoffs da Divisional League</h4>
                 <p className="text-sm text-slate-400">Ao final de 14 semanas, os 6 primeiros colocados de cada liga se classificam. Os 2 primeiros colocados folgam na primeira rodada (Bye). Os confrontos ocorrem dentro da própria liga.</p>
               </div>

               <div className="space-y-4">
                 <h4 className="text-sm font-black text-slate-100 uppercase tracking-widest">Pontuação para o Ranking FWL</h4>
                 <div className="grid grid-cols-2 gap-2 text-[10px] font-black uppercase text-center">
                    <div className="p-3 bg-black/40 rounded-xl border border-white/5">Vitória: 20 pts</div>
                    <div className="p-3 bg-black/40 rounded-xl border border-white/5">Maior Pontuador: 20 pts</div>
                    <div className="p-3 bg-yellow-500/10 rounded-xl border border-yellow-500/20 text-yellow-500">Campeão: 300 pts</div>
                    <div className="p-3 bg-slate-400/10 rounded-xl border border-slate-400/20 text-slate-400">Vice: 200 pts</div>
                    <div className="p-3 bg-orange-700/10 rounded-xl border border-orange-700/20 text-orange-600 col-span-2">3º Colocado: 100 pts</div>
                 </div>
               </div>
            </div>

            {/* Brady Bowl Section */}
            <div className="space-y-6 p-8 bg-yellow-900/10 border border-yellow-500/20 rounded-[2rem]">
               <div className="flex items-center gap-2">
                 <Sword className="w-4 h-4 text-yellow-500" />
                 <h3 className="text-xl font-black text-white uppercase italic">2. Brady Bowl</h3>
               </div>
               <p className="text-xs text-yellow-500/60 uppercase font-black tracking-widest">32 Divisões de 12 Times</p>

               <div className="space-y-4">
                 <h4 className="text-sm font-black text-slate-100 uppercase tracking-widest">Playoffs da Brady Bowl (Misto)</h4>
                 <ul className="space-y-2 text-sm text-slate-400 list-disc list-inside">
                   <li>Temporada Regular: 10 semanas.</li>
                   <li>Playoff de Divisão: 4 primeiros (Semifinal e Final).</li>
                   <li><strong className="text-white">Playoff Geral (Global):</strong> O Campeão de cada uma das 32 divisões avança para o mata-mata geral (organizado externamente).</li>
                 </ul>
               </div>

               <div className="space-y-4">
                 <h4 className="text-sm font-black text-slate-100 uppercase tracking-widest">Pontuação e Premiação</h4>
                 <div className="grid grid-cols-2 gap-2 text-[10px] font-black uppercase text-center">
                    <div className="p-3 bg-black/40 rounded-xl border border-white/5">Vitória: 20 pts</div>
                    <div className="p-3 bg-black/40 rounded-xl border border-white/5">Maior Pontuador: 20 pts</div>
                    <div className="p-3 bg-yellow-500/20 rounded-xl border border-yellow-500/40 text-yellow-500 col-span-2">Campeão Geral: Vaga FWL Finals</div>
                    <div className="p-3 bg-slate-400/10 rounded-xl border border-slate-400/20 text-slate-400">Vice Geral: 300 pts</div>
                    <div className="p-3 bg-orange-700/10 rounded-xl border border-orange-700/20 text-orange-600">3º Geral: 200 pts</div>
                 </div>
               </div>
            </div>

            {/* Playoffs Challenge Section */}
            <div className="space-y-6 p-8 bg-purple-900/10 border border-purple-500/20 rounded-[2rem]">
               <div className="flex items-center gap-2">
                 <Zap className="w-4 h-4 text-purple-400" />
                 <h3 className="text-xl font-black text-white uppercase italic">3. Playoffs Challenge</h3>
               </div>
               <p className="text-xs text-purple-400/60 uppercase font-black tracking-widest">Mata-Mata Integral (Semanas 9-17)</p>

               <div className="space-y-4">
                 <h4 className="text-sm font-black text-slate-100 uppercase tracking-widest">Dinâmica de Jogo</h4>
                 <p className="text-sm text-slate-400">Utiliza o mesmo elenco da Divisional League. Confrontos externos ao Sleeper, permitindo jogadores coincidentes.</p>
                 <div className="p-4 bg-black/30 rounded-xl border border-purple-500/20 text-xs font-bold">
                   <span className="text-purple-400">Desempate:</span> Em caso de empate na pontuação, vence a <strong className="text-white">Melhor Seed</strong> (Ranking no início do Round 1).
                 </div>
               </div>

               <div className="space-y-4">
                 <h4 className="text-sm font-black text-slate-100 uppercase tracking-widest">Formato do Bracket</h4>
                 <ul className="space-y-2 text-xs font-bold text-slate-500">
                    <li className="p-4 bg-black/20 rounded-xl border border-white/5">
                      <span className="text-purple-400">Round 1 (W9):</span> 128 primeiros ganham BYE. Restantes se enfrentam.
                    </li>
                    <li className="p-4 bg-black/20 rounded-xl border border-white/5">
                      <span className="text-purple-400">Round 2 em diante:</span> 256 times em mata-mata simples.
                    </li>
                 </ul>
               </div>

               <div className="space-y-4">
                 <h4 className="text-sm font-black text-slate-100 uppercase tracking-widest">Pontuação e Premiação</h4>
                 <div className="grid grid-cols-2 gap-2 text-[10px] font-black uppercase text-center">
                    <div className="p-3 bg-black/40 rounded-xl border border-white/5 col-span-2">Vitória por Round: 20 pts</div>
                    <div className="p-3 bg-yellow-500/20 rounded-xl border border-yellow-500/40 text-yellow-500 col-span-2">Campeão: Vaga FWL Finals</div>
                    <div className="p-3 bg-slate-400/10 rounded-xl border border-slate-400/20 text-slate-400">Vice: 300 pts</div>
                    <div className="p-3 bg-orange-700/10 rounded-xl border border-orange-700/20 text-orange-600">3º Lugar: 200 pts</div>
                 </div>
               </div>
            </div>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-3 text-blue-400">
               <Trophy className="w-6 h-6 text-yellow-500" />
               <h2 className="text-2xl font-black uppercase italic tracking-tight">FWL Finals 2026</h2>
            </div>
            <p className="text-sm text-slate-400">12 competidores disputarão o título máximo:</p>
            <div className="grid gap-2">
               {["Campeão Temporada Anterior", "Campeão Playoffs Challenge", "Campeão Brady Bowl", "9 Melhores do Ranking FWL"].map((item, i) => (
                 <div key={i} className="px-6 py-4 bg-white/5 rounded-2xl border border-white/5 flex items-center justify-between">
                   <span className="text-sm font-black uppercase tracking-widest">{item}</span>
                   <CheckCircle2 className="w-4 h-4 text-blue-500" />
                 </div>
               ))}
            </div>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-3 text-blue-400">
               <Award className="w-6 h-6" />
               <h2 className="text-2xl font-black uppercase italic tracking-tight">Draft & Trades</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-6 bg-black/20 rounded-3xl border border-white/5 space-y-3">
                <h4 className="text-xs font-black text-blue-400 uppercase tracking-widest">DRAFT 2026</h4>
                <ul className="text-xs font-bold text-slate-500 space-y-2">
                  <li>Início: Sexta, 18:30h</li>
                  <li>Formato: Snake</li>
                  <li>Tempo: 2 horas por pick</li>
                  <li>Local: App Sleeper</li>
                </ul>
              </div>
              <div className="p-6 bg-black/20 rounded-3xl border border-white/5 space-y-3">
                <h4 className="text-xs font-black text-red-400 uppercase tracking-widest">TRADES & WAIVER</h4>
                <ul className="text-xs font-bold text-slate-500 space-y-2">
                  <li>Deadline: Semana 8</li>
                  <li>Veto: 7 votos (24h)</li>
                  <li>Waiver: Terça p/ Quarta</li>
                  <li>Sistema: Rolling Waiver</li>
                </ul>
              </div>
            </div>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-3 text-blue-400">
               <Layers className="w-6 h-6" />
               <h2 className="text-2xl font-black uppercase italic tracking-tight">Configurações Técnicas</h2>
            </div>
            <div className="bg-black/40 p-8 rounded-[2rem] border border-white/5 space-y-6">
               <div>
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Lineup Titular</p>
                 <p className="text-xs font-black text-white bg-white/5 p-4 rounded-xl">1 QB • 2 RB • 2 WR • 1 TE • 1 FLEX • 1 K • 1 DEF (6 BN + 2 IR)</p>
               </div>
               <div>
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Scoring System</p>
                 <ul className="text-xs font-bold text-slate-500 grid grid-cols-2 gap-4">
                   <li>Half-PPR</li>
                   <li>Passe: 0.04/yd</li>
                   <li>Passe TD: 4 pts</li>
                   <li>Corrida/Rec: 0.1/yd</li>
                   <li>Cor/Rec TD: 6 pts</li>
                   <li>Kicker: Distância</li>
                 </ul>
               </div>
            </div>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-3 text-green-500">
               <Zap className="w-6 h-6" />
               <h2 className="text-2xl font-black uppercase italic tracking-tight">Premiações & Inscrição</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-black uppercase">
               <div className="p-6 bg-green-500/10 border border-green-500/20 rounded-3xl text-green-500 flex items-center justify-between">
                 <span>Inscrição: R$ 10,00</span>
                 <CheckCircle2 className="w-4 h-4" />
               </div>
               <div className="p-6 bg-blue-500/10 border border-blue-500/20 rounded-3xl text-blue-400 flex items-center justify-between">
                 <span>Capacidade: 384 Vagas</span>
                 <Users className="w-4 h-4" />
               </div>
            </div>
            <div className="bg-black/20 p-8 rounded-[2rem] border border-white/5 space-y-4">
               <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Distribuição Estimada</p>
               <div className="space-y-3">
                 <div className="flex justify-between items-center text-xs">
                   <span className="text-slate-400 font-bold">Brady Bowl (30%)</span>
                   <span className="text-white font-black">R$ 1.152,00</span>
                 </div>
                 <div className="flex justify-between items-center text-xs">
                   <span className="text-slate-400 font-bold">Playoffs Challenge (20%)</span>
                   <span className="text-white font-black">R$ 768,00</span>
                 </div>
                 <div className="flex justify-between items-center text-xs">
                   <span className="text-slate-400 font-bold">FWL Finals 2027 (50%)</span>
                   <span className="text-white font-black">R$ 1.920,00</span>
                 </div>
               </div>
            </div>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-3 text-red-500">
               <Shield className="w-6 h-6" />
               <h2 className="text-2xl font-black uppercase italic tracking-tight">Regras de Conduta</h2>
            </div>
            <p className="text-sm text-slate-400 italic">"Respeito e Fair Play acima de tudo."</p>
            <div className="grid gap-3">
               <div className="p-4 bg-red-500/5 rounded-2xl border border-red-500/10 flex gap-4">
                 <Ban className="w-4 h-4 text-red-500 shrink-0" />
                 <p className="text-xs font-bold text-slate-300">É proibido "Tanking" (perder de propósito) ou conluio entre times.</p>
               </div>
               <div className="p-4 bg-red-500/5 rounded-2xl border border-red-500/10 flex gap-4">
                 <Ban className="w-4 h-4 text-red-500 shrink-0" />
                 <p className="text-xs font-bold text-slate-300">Ofensas, racismo, homofobia ou desrespeito aos comissários resultarão em banimento.</p>
               </div>
            </div>
          </section>

          <footer className="pt-12 border-t border-white/5 space-y-8">
             <div className="text-center">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.5em] mb-6">Comissários FWL 2026</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  <p>Diogo Krieck</p>
                  <p>Diogo Costa Alencar</p>
                  <p>Fernando Moessa</p>
                  <p>Tiago Vieira Lima Alves</p>
                </div>
             </div>
             <p className="text-[9px] text-slate-600 text-center leading-relaxed">
               A FWL não se responsabiliza por falhas técnicas de terceiros. Casos omissos serão julgados pela comissão organizadora.
             </p>
          </footer>
        </div>
      </div>
    </div>
  );
};

export default RegulationPage;