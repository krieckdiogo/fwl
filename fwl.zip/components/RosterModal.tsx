
import React from 'react';
import { X, User as UserIcon, Shield } from 'lucide-react';
import { Roster, User, Player } from '../types';
import { getAvatarUrl as getAvatar, getPlayerImageUrl } from '../services/sleeper';

interface CustomStats {
  wins: number;
  losses: number;
  fpts: number;
}

interface PlayerItemProps {
  playerId: string;
  isStarter: boolean;
  playersMap: Record<string, Player>;
}

// Moved PlayerItem outside of RosterModal to resolve TypeScript errors where 'key' was not recognized
// as a valid prop on a locally defined function, and to follow React best practices.
const PlayerItem: React.FC<PlayerItemProps> = ({ playerId, isStarter, playersMap }) => {
  const player = playersMap[playerId];
  const imageUrl = player ? getPlayerImageUrl(playerId, player.position) : '';
  const displayName = player ? (player.full_name || `${player.first_name} ${player.last_name}`) : 'Unknown Player';
  
  return (
    <div className={`flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5 hover:border-blue-500/30 transition-all group`}>
      <div className="flex items-center gap-4">
        <div className="relative shrink-0">
          <div className="w-12 h-12 rounded-full bg-slate-800 overflow-hidden border border-white/10">
            <img 
              src={imageUrl} 
              alt={displayName}
              className="w-full h-full object-cover transform transition-transform group-hover:scale-110"
              onError={(e) => {
                (e.target as HTMLImageElement).src = `https://sleepercdn.com/images/v2/icons/player_default.webp`;
              }}
            />
          </div>
          {player && (
            <div className="absolute -bottom-1 -right-1 bg-slate-900 border border-slate-700 rounded-md px-1.5 py-0.5 text-[8px] font-black text-blue-400 uppercase tracking-tighter">
              {player.position}
            </div>
          )}
        </div>
        <div className="flex flex-col">
          <span className="text-sm font-bold text-slate-100 group-hover:text-blue-400 transition-colors leading-tight">
            {displayName}
          </span>
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
            {player?.team || 'FA'} • {isStarter ? 'Titular' : 'Reserva'}
          </span>
        </div>
      </div>
      <div className="flex items-center gap-2">
         <div className={`w-2 h-2 rounded-full ${isStarter ? 'bg-blue-500 animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.5)]' : 'bg-slate-700'}`}></div>
      </div>
    </div>
  );
};

interface RosterModalProps {
  roster: Roster;
  user: User | undefined;
  playersMap: Record<string, Player>;
  onClose: () => void;
  customStats?: CustomStats | null;
}

const RosterModal: React.FC<RosterModalProps> = ({ roster, user, playersMap, onClose, customStats }) => {
  if (!roster) return null;

  const displayWins = customStats ? customStats.wins : roster.settings.wins;
  const displayLosses = customStats ? customStats.losses : roster.settings.losses;
  const displayFpts = customStats 
    ? customStats.fpts.toFixed(2) 
    : `${roster.settings.fpts}.${roster.settings.fpts_decimal}`;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 overflow-hidden">
      <div 
        className="absolute inset-0 bg-[#0a0f1d]/90 backdrop-blur-md"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-xl bg-[#1e293b] border border-white/10 rounded-[2.5rem] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200 flex flex-col max-h-[90vh]">
        <div className="p-6 sm:p-8 border-b border-white/5 bg-gradient-to-b from-white/5 to-transparent flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
            <div className="relative">
              <img 
                src={getAvatar(user?.avatar || null)} 
                className="w-16 h-16 rounded-full border-2 border-blue-500/50 p-0.5"
                alt=""
              />
              <div className="absolute -bottom-1 -right-1 bg-blue-600 text-[10px] font-black px-2 py-0.5 rounded-full border border-white/20">
                #{roster.roster_id}
              </div>
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                {user?.metadata?.team_name || user?.display_name || 'Team Unknown'}
              </h2>
              <p className="text-xs font-black text-blue-400 uppercase tracking-widest">
                {displayWins}W - {displayLosses}L • {displayFpts} PTS
                {customStats && <span className="ml-2 text-slate-500 text-[9px]">(11 SEMANAS)</span>}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-white/5 rounded-full transition-colors group"
          >
            <X className="w-6 h-6 text-slate-500 group-hover:text-white" />
          </button>
        </div>

        <div className="p-6 sm:p-8 overflow-y-auto no-scrollbar flex-1">
          <div className="space-y-8">
            <div>
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                <Shield className="w-3 h-3 text-blue-500" />
                Lineup Titular
              </h3>
              <div className="grid gap-3">
                {roster.starters.map((playerId, idx) => (
                  <PlayerItem key={`${playerId}-${idx}`} playerId={playerId} isStarter={true} playersMap={playersMap} />
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                <UserIcon className="w-3 h-3" />
                Banco de Reservas
              </h3>
              <div className="grid gap-3 opacity-80">
                {roster.players
                  .filter(p => !roster.starters.includes(p))
                  .map((playerId, idx) => (
                    <PlayerItem key={`${playerId}-${idx}`} playerId={playerId} isStarter={false} playersMap={playersMap} />
                  ))
                }
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-6 bg-[#0a0f1d]/50 text-center shrink-0">
          <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">Sincronizado com Sleeper NFL Database</p>
        </div>
      </div>
    </div>
  );
};

export default RosterModal;
