
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { fetchLeagueData, fetchMatchupsForWeek, getAvatarUrl } from '../services/sleeper';
import { User, Matchup, Roster } from '../types';
import { FWL_BRADY_IDS } from '../App';
import { 
  Trophy, 
  ArrowLeft, 
  Search, 
  Zap, 
  Sword, 
  RefreshCw, 
  Info, 
  Medal,
  Crown,
  LayoutGrid
} from 'lucide-react';

interface BradyGeneralPlayoffsProps {
  onBack: () => void;
}

interface QualifiedTeam {
  roster_id: number;
  user: User | undefined;
  league_id: string;
  league_name: string;
  wins: number;
  fpts: number;
  pos: number; // 1st, 2nd, 3rd, 4th
  seed: number;
}

interface PlayoffMatch {
  match_id: number;
  s1: number;
  t1: QualifiedTeam | undefined;
  p1: number;
  s2: number;
  t2: QualifiedTeam | undefined;
  p2: number;
  w: QualifiedTeam | undefined;
}

const BradyGeneralPlayoffs: React.FC<BradyGeneralPlayoffsProps> = ({ onBack }) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [activeRound, setActiveRound] = useState<string>('R1');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [qualifiedTeams, setQualifiedTeams] = useState<QualifiedTeam[]>([]);
  const [weeklyScores, setWeeklyScores] = useState<Record<string, Record<number, Record<number, number>>>>({});

  const rounds = [
    { id: 'R1', label: 'R64', week: 12, desc: '32 confrontos' },
    { id: 'R2', label: 'R32', week: 13, desc: '16 confrontos' },
    { id: 'R3', label: 'S16', week: 14, desc: '8 confrontos' },
    { id: 'QF', label: 'QF', week: 15, desc: '4 confrontos' },
    { id: 'SF', label: 'SF', week: 16, desc: '2 confrontos' },
    { id: 'F', label: 'FINAL', week: 17, desc: 'Grande Final' },
    { id: '3RD', label: 'BRONZE', week: 17, desc: '3º e 4º Lugar' },
  ];

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const allQualifiedPools: Record<number, QualifiedTeam[]> = { 1: [], 2: [], 3: [], 4: [] };
      const scoresMap: Record<string, Record<number, Record<number, number>>> = {};

      for (let i = 0; i < FWL_BRADY_IDS.length; i++) {
        const leagueId = FWL_BRADY_IDS[i];
        setProgress(Math.round(((i + 1) / FWL_BRADY_IDS.length) * 100));

        const { rosters, users, league: leagueInfo } = await fetchLeagueData(leagueId);
        
        // CÁLCULO MANUAL DA TEMPORADA REGULAR (W1-11)
        const stats: Record<number, { wins: number, fpts: number }> = {};
        rosters.forEach(r => stats[r.roster_id] = { wins: 0, fpts: 0 });

        const weekPromises = [];
        for (let w = 1; w <= 11; w++) {
          weekPromises.push(fetchMatchupsForWeek(leagueId, w).catch(() => []));
        }
        
        const allWeeksResults = await Promise.all(weekPromises);
        allWeeksResults.forEach(matchups => {
          const pairs: Record<number, Matchup[]> = {};
          matchups.forEach(m => {
            if (!pairs[m.matchup_id]) pairs[m.matchup_id] = [];
            pairs[m.matchup_id].push(m);
            if (stats[m.roster_id]) stats[m.roster_id].fpts += m.points;
          });
          Object.values(pairs).forEach(p => {
            if (p.length === 2) {
              const [t1, t2] = p;
              if (t1.points > t2.points) stats[t1.roster_id].wins++;
              else if (t2.points > t1.points) stats[t2.roster_id].wins++;
            }
          });
        });

        const sortedInLeague = [...rosters].sort((a, b) => {
          if (stats[b.roster_id].wins !== stats[a.roster_id].wins) return stats[b.roster_id].wins - stats[a.roster_id].wins;
          return stats[b.roster_id].fpts - stats[a.roster_id].fpts;
        });

        sortedInLeague.slice(0, 4).forEach((r, idx) => {
          const pos = idx + 1;
          const user = users.find(u => u.user_id === r.owner_id);
          allQualifiedPools[pos].push({
            roster_id: r.roster_id,
            user,
            league_id: leagueId,
            league_name: leagueInfo.name.replace('FWL 2025 - ', ''),
            wins: stats[r.roster_id].wins,
            fpts: stats[r.roster_id].fpts,
            pos,
            seed: 0
          });
        });

        scoresMap[leagueId] = {};
        const playoffWeekPromises = [];
        for (let w = 12; w <= 17; w++) {
          playoffWeekPromises.push(fetchMatchupsForWeek(leagueId, w).then(m => ({ w, m })).catch(() => ({ w, m: [] })));
        }
        
        const playResults = await Promise.all(playoffWeekPromises);
        playResults.forEach(res => {
          res.m.forEach(m => {
            if (!scoresMap[leagueId][m.roster_id]) scoresMap[leagueId][m.roster_id] = {};
            scoresMap[leagueId][m.roster_id][res.w] = m.points;
          });
        });
      }

      const sortPool = (pool: QualifiedTeam[]) => pool.sort((a, b) => {
        if (b.wins !== a.wins) return b.wins - a.wins;
        return b.fpts - a.fpts;
      });

      const firsts = sortPool(allQualifiedPools[1]);
      const seconds = sortPool(allQualifiedPools[2]);
      const thirds = sortPool(allQualifiedPools[3]);
      const bestFourths = sortPool(allQualifiedPools[4]);
      
      const final64 = [
        ...firsts,
        ...seconds,
        ...thirds,
        bestFourths[0]
      ].slice(0, 64).map((t, idx) => ({ ...t, seed: idx + 1 }));

      setQualifiedTeams(final64);
      setWeeklyScores(scoresMap);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const resolveWinner = (t1: QualifiedTeam | undefined, p1: number, t2: QualifiedTeam | undefined, p2: number) => {
    if (!t1) return t2;
    if (!t2) return t1;
    if (p1 > p2) return t1;
    if (p2 > p1) return t2;
    return t1.seed < t2.seed ? t1 : t2;
  };

  const bracket = useMemo(() => {
    if (qualifiedTeams.length === 0) return {};
    const bracketMap: Record<string, PlayoffMatch[]> = {};
    
    // ROUND 1 (W12): Seed 1 vs 64, 2 vs 63... até 32 vs 33
    const r1: PlayoffMatch[] = [];
    for (let i = 0; i < 32; i++) {
      const s1 = i + 1;
      const s2 = 64 - i;
      const t1 = qualifiedTeams.find(t => t.seed === s1);
      const t2 = qualifiedTeams.find(t => t.seed === s2);
      const p1 = t1 ? (weeklyScores[t1.league_id]?.[t1.roster_id]?.[12] || 0) : 0;
      const p2 = t2 ? (weeklyScores[t2.league_id]?.[t2.roster_id]?.[12] || 0) : 0;
      r1.push({ match_id: i, s1, t1, p1, s2, t2, p2, w: resolveWinner(t1, p1, t2, p2) });
    }
    bracketMap['R1'] = r1;

    // ROUNDS SUBSEQUENTES (W13-W17)
    const roundIds = ['R2', 'R3', 'QF', 'SF', 'F'];
    const weeks = [13, 14, 15, 16, 17];
    let prevWinners = r1.map(m => m.w);
    
    roundIds.forEach((rid, idx) => {
      const currentWeek = weeks[idx];
      const matches: PlayoffMatch[] = [];
      const numMatches = prevWinners.length / 2;

      for (let i = 0; i < numMatches; i++) {
        const t1 = prevWinners[i];
        const t2 = prevWinners[prevWinners.length - 1 - i];
        
        const p1 = t1 ? (weeklyScores[t1.league_id]?.[t1.roster_id]?.[currentWeek] || 0) : 0;
        const p2 = t2 ? (weeklyScores[t2.league_id]?.[t2.roster_id]?.[currentWeek] || 0) : 0;
        
        matches.push({
          match_id: i,
          s1: t1?.seed || 0, t1, p1,
          s2: t2?.seed || 0, t2, p2,
          w: resolveWinner(t1, p1, t2, p2)
        });
      }

      // DISPUTA DE 3º E 4º LUGAR (Calculada na SF, mas exibida na aba 3RD)
      if (rid === 'SF') {
        const sfMatches = matches;
        const loser1 = sfMatches[0].w === sfMatches[0].t1 ? sfMatches[0].t2 : sfMatches[0].t1;
        const loser2 = sfMatches[1].w === sfMatches[1].t1 ? sfMatches[1].t2 : sfMatches[1].t1;
        
        const p1_3rd = loser1 ? (weeklyScores[loser1.league_id]?.[loser1.roster_id]?.[17] || 0) : 0;
        const p2_3rd = loser2 ? (weeklyScores[loser2.league_id]?.[loser2.roster_id]?.[17] || 0) : 0;
        
        bracketMap['3RD'] = [{
          match_id: 999,
          s1: loser1?.seed || 0, t1: loser1, p1: p1_3rd,
          s2: loser2?.seed || 0, t2: loser2, p2: p2_3rd,
          w: resolveWinner(loser1, p1_3rd, loser2, p2_3rd)
        }];
      }

      bracketMap[rid] = matches;
      prevWinners = matches.map(m => m.w);
    });

    return bracketMap;
  }, [qualifiedTeams, weeklyScores]);

  const filteredMatches = useMemo(() => {
    const currentRoundMatches = bracket[activeRound] || [];
    if (!searchTerm) return currentRoundMatches;
    
    return currentRoundMatches.filter(m => 
      m.t1?.user?.display_name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      m.t2?.user?.display_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.t1?.league_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.t2?.league_name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [bracket, activeRound, searchTerm]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050a14] flex flex-col items-center justify-center p-8 space-y-8">
        <RefreshCw className="w-16 h-16 text-yellow-500 animate-spin" />
        <div className="text-center space-y-4">
          <h2 className="text-white font-black text-2xl uppercase tracking-[0.2em] italic">Acessando Dados Brady Bowl</h2>
          <div className="w-64 h-1.5 bg-white/5 rounded-full overflow-hidden mx-auto">
            <div className="h-full bg-yellow-500 transition-all duration-300 shadow-[0_0_15px_rgba(234,179,8,0.5)]" style={{ width: `${progress}%` }}></div>
          </div>
          <p className="text-slate-500 font-bold text-[10px] uppercase tracking-widest">{progress}% - Analisando Semanas 1-11</p>
        </div>
      </div>
    );
  }

  const grandFinalMatch = bracket['F']?.[0];
  const bronzeMatch = bracket['3RD']?.[0];
  const championsPodium = grandFinalMatch?.w;

  return (
    <div className="min-h-screen bg-[#050a14] text-slate-200 p-6 space-y-12 animate-in fade-in duration-500 pb-32">
      {/* Header Fixo com Seletor de Abas */}
      <div className="flex flex-col md:flex-row items-center justify-between sticky top-0 bg-[#050a14]/95 backdrop-blur-xl p-4 -m-4 z-50 border-b border-yellow-500/20 mb-8 gap-4">
        <div className="flex items-center gap-6">
          <button onClick={onBack} className="p-3 bg-white/5 hover:bg-yellow-500/20 border border-white/10 rounded-full text-white transition-all group">
            <ArrowLeft className="w-6 h-6 group-hover:-translate-x-1" />
          </button>
          <div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tighter italic leading-none">Playoffs Geral</h2>
            <p className="text-[10px] font-bold text-yellow-500 uppercase tracking-widest">FWL 2025 • Brady Bowl Series</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2">
          {rounds.map((r) => (
            <button
              key={r.id}
              onClick={() => setActiveRound(r.id)}
              className={`flex flex-col items-center px-5 py-3 rounded-2xl border transition-all ${
                activeRound === r.id 
                ? (r.id === '3RD' ? 'bg-orange-700 border-orange-500' : 'bg-yellow-600 border-yellow-500') + ' text-white shadow-xl scale-105' 
                : 'bg-white/5 border-white/5 text-slate-500 hover:text-slate-300'
              }`}
            >
              <span className="text-[10px] font-black uppercase tracking-widest">{r.label}</span>
              <span className="text-[8px] font-bold opacity-60 uppercase">Week {r.week}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Visualização de Final */}
      {activeRound === 'F' && grandFinalMatch && (
        <section className="animate-in zoom-in duration-700 space-y-12">
           <div className="max-w-xl mx-auto flex flex-col items-center p-12 bg-gradient-to-b from-yellow-500/10 to-transparent border border-yellow-500/30 rounded-[3rem] relative shadow-2xl">
              <div className="absolute top-0 right-0 p-6 opacity-20">
                <Crown className="w-32 h-32 text-yellow-500" />
              </div>
              <Trophy className="w-24 h-24 text-yellow-500 mb-6 drop-shadow-[0_0_20px_rgba(234,179,8,0.5)]" />
              <h3 className="text-[10px] font-black text-yellow-500 uppercase tracking-[0.4em] mb-4">Confronto da Grande Final</h3>
              
              <div className="w-full space-y-8">
                 <div className={`flex items-center justify-between p-6 rounded-3xl bg-white/5 border border-white/10 ${grandFinalMatch.w === grandFinalMatch.t1 ? 'border-yellow-500 bg-yellow-500/10' : ''}`}>
                    <div className="flex items-center gap-4">
                       <img src={getAvatarUrl(grandFinalMatch.t1?.user?.avatar || null)} className="w-14 h-14 rounded-full border-2 border-slate-700" alt="" />
                       <div>
                          <p className="text-lg font-black text-white">{grandFinalMatch.t1?.user?.display_name || 'TBD'}</p>
                          <p className="text-[9px] font-bold text-slate-500 uppercase">SEED #{grandFinalMatch.s1}</p>
                       </div>
                    </div>
                    <div className="text-3xl font-black italic text-white">{grandFinalMatch.p1.toFixed(2)}</div>
                 </div>

                 <div className="flex items-center gap-4">
                    <div className="h-[1px] flex-1 bg-white/10"></div>
                    <span className="text-xs font-black text-yellow-500/50 italic">VS</span>
                    <div className="h-[1px] flex-1 bg-white/10"></div>
                 </div>

                 <div className={`flex items-center justify-between p-6 rounded-3xl bg-white/5 border border-white/10 ${grandFinalMatch.w === grandFinalMatch.t2 ? 'border-yellow-500 bg-yellow-500/10' : ''}`}>
                    <div className="flex items-center gap-4">
                       <img src={getAvatarUrl(grandFinalMatch.t2?.user?.avatar || null)} className="w-14 h-14 rounded-full border-2 border-slate-700" alt="" />
                       <div>
                          <p className="text-lg font-black text-white">{grandFinalMatch.t2?.user?.display_name || 'TBD'}</p>
                          <p className="text-[9px] font-bold text-slate-500 uppercase">SEED #{grandFinalMatch.s2}</p>
                       </div>
                    </div>
                    <div className="text-3xl font-black italic text-white">{grandFinalMatch.p2.toFixed(2)}</div>
                 </div>
              </div>

              {championsPodium && (
                <div className="mt-12 text-center animate-bounce">
                  <p className="text-[10px] font-black text-yellow-500 uppercase tracking-widest mb-1">👑 Atual Campeão</p>
                  <p className="text-2xl font-black text-white italic tracking-tighter uppercase">{championsPodium.user?.display_name}</p>
                </div>
              )}
           </div>
        </section>
      )}

      {/* Visualização de Bronze (3º lugar) */}
      {activeRound === '3RD' && bronzeMatch && (
        <section className="animate-in zoom-in duration-700">
           <div className="max-w-xl mx-auto flex flex-col items-center p-12 bg-gradient-to-b from-orange-500/10 to-transparent border border-orange-500/30 rounded-[3rem] relative shadow-2xl">
              <Medal className="w-20 h-20 text-orange-500 mb-6 drop-shadow-[0_0_20px_rgba(249,115,22,0.4)]" />
              <h3 className="text-[10px] font-black text-orange-500 uppercase tracking-[0.4em] mb-4 text-center">Disputa da Medalha de Bronze</h3>
              
              <div className="w-full space-y-8">
                 <div className={`flex items-center justify-between p-6 rounded-3xl bg-white/5 border border-white/10 ${bronzeMatch.w === bronzeMatch.t1 ? 'border-orange-500 bg-orange-500/10' : ''}`}>
                    <div className="flex items-center gap-4">
                       <img src={getAvatarUrl(bronzeMatch.t1?.user?.avatar || null)} className="w-14 h-14 rounded-full border-2 border-slate-700" alt="" />
                       <div>
                          <p className="text-lg font-black text-white">{bronzeMatch.t1?.user?.display_name || 'TBD'}</p>
                          <p className="text-[9px] font-bold text-slate-500 uppercase">SEED #{bronzeMatch.s1}</p>
                       </div>
                    </div>
                    <div className="text-3xl font-black italic text-white">{bronzeMatch.p1.toFixed(2)}</div>
                 </div>

                 <div className="flex items-center gap-4">
                    <div className="h-[1px] flex-1 bg-white/10"></div>
                    <span className="text-[10px] font-black text-orange-500/50 italic">PELA 3ª POSIÇÃO</span>
                    <div className="h-[1px] flex-1 bg-white/10"></div>
                 </div>

                 <div className={`flex items-center justify-between p-6 rounded-3xl bg-white/5 border border-white/10 ${bronzeMatch.w === bronzeMatch.t2 ? 'border-orange-500 bg-orange-500/10' : ''}`}>
                    <div className="flex items-center gap-4">
                       <img src={getAvatarUrl(bronzeMatch.t2?.user?.avatar || null)} className="w-14 h-14 rounded-full border-2 border-slate-700" alt="" />
                       <div>
                          <p className="text-lg font-black text-white">{bronzeMatch.t2?.user?.display_name || 'TBD'}</p>
                          <p className="text-[9px] font-bold text-slate-500 uppercase">SEED #{bronzeMatch.s2}</p>
                       </div>
                    </div>
                    <div className="text-3xl font-black italic text-white">{bronzeMatch.p2.toFixed(2)}</div>
                 </div>
              </div>

              {bronzeMatch.w && (
                <div className="mt-8 bg-orange-500/20 px-6 py-2 rounded-full border border-orange-500/30">
                  <p className="text-[10px] font-black text-orange-400 uppercase tracking-widest whitespace-nowrap">🥉 Vencedor do Bronze: {bronzeMatch.w.user?.display_name}</p>
                </div>
              )}
           </div>
        </section>
      )}

      {/* Visualização de Rounds Normais (R64 até Semis) */}
      {!['F', '3RD'].includes(activeRound) && (
        <>
          <div className="max-w-4xl mx-auto w-full relative">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder="Buscar manager, time ou divisão..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#1e293b]/40 border border-white/10 rounded-full pl-14 pr-6 py-5 text-sm text-white focus:border-yellow-500 outline-none transition-all shadow-2xl"
            />
          </div>

          <main className="max-w-7xl mx-auto w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMatches.length > 0 ? (
              filteredMatches.map((m) => (
                <div key={m.match_id} className="bg-[#1e293b]/20 border border-white/5 rounded-[2.5rem] overflow-hidden hover:border-yellow-500/30 transition-all group relative">
                   <div className="absolute top-0 left-0 w-1 h-full bg-slate-800 group-hover:bg-yellow-500 transition-colors"></div>
                   
                   <div className="p-8 space-y-6">
                     <div className={`flex items-center justify-between gap-4 ${m.w === m.t1 ? 'opacity-100' : 'opacity-40'}`}>
                        <div className="flex items-center gap-4 overflow-hidden">
                          <div className="relative shrink-0">
                            <img src={getAvatarUrl(m.t1?.user?.avatar || null)} className={`w-12 h-12 rounded-full border-2 ${m.w === m.t1 ? 'border-yellow-500' : 'border-slate-700'}`} alt="" />
                            <span className="absolute -bottom-1 -right-1 bg-slate-900 text-[8px] font-black text-white px-1.5 py-0.5 rounded border border-white/10">#{m.s1}</span>
                          </div>
                          <div className="flex flex-col min-w-0">
                            <span className="text-sm font-bold text-white truncate leading-none mb-1">{m.t1?.user?.display_name || 'TBD'}</span>
                            <span className="text-[9px] font-bold text-slate-500 uppercase truncate">{m.t1?.league_name || 'Division Unknown'}</span>
                          </div>
                        </div>
                        <div className={`text-2xl font-black italic tracking-tighter ${m.w === m.t1 ? 'text-yellow-500' : 'text-slate-600'}`}>
                          {m.p1.toFixed(2)}
                        </div>
                     </div>

                     <div className="flex items-center gap-4 px-4">
                        <div className="h-[1px] flex-1 bg-white/5"></div>
                        <span className="text-[9px] font-black text-slate-700 italic">VS</span>
                        <div className="h-[1px] flex-1 bg-white/5"></div>
                     </div>

                     <div className={`flex items-center justify-between gap-4 ${m.w === m.t2 ? 'opacity-100' : 'opacity-40'}`}>
                        <div className="flex items-center gap-4 overflow-hidden">
                          <div className="relative shrink-0">
                            <img src={getAvatarUrl(m.t2?.user?.avatar || null)} className={`w-12 h-12 rounded-full border-2 ${m.w === m.t2 ? 'border-yellow-500' : 'border-slate-700'}`} alt="" />
                            <span className="absolute -bottom-1 -right-1 bg-slate-900 text-[8px] font-black text-white px-1.5 py-0.5 rounded border border-white/10">#{m.s2}</span>
                          </div>
                          <div className="flex flex-col min-w-0">
                            <span className="text-sm font-bold text-white truncate leading-none mb-1">{m.t2?.user?.display_name || 'TBD'}</span>
                            <span className="text-[9px] font-bold text-slate-500 uppercase truncate">{m.t2?.league_name || 'Division Unknown'}</span>
                          </div>
                        </div>
                        <div className={`text-2xl font-black italic tracking-tighter ${m.w === m.t2 ? 'text-yellow-500' : 'text-slate-600'}`}>
                          {m.p2.toFixed(2)}
                        </div>
                     </div>
                   </div>

                   <div className="bg-white/5 px-6 py-3 flex items-center justify-between">
                     <span className="text-[8px] font-black text-yellow-500 uppercase tracking-widest italic">Winner: {m.w?.user?.display_name || 'TBD'}</span>
                     {m.p1 === m.p2 && m.p1 > 0 && (
                       <span className="text-[7px] font-bold text-slate-500 uppercase bg-black/40 px-2 py-0.5 rounded">TIE-BREAKER: SEED</span>
                     )}
                   </div>
                </div>
              ))
            ) : (
              <div className="col-span-full py-32 text-center bg-white/5 rounded-[3rem] border border-dashed border-white/10">
                 <LayoutGrid className="w-12 h-12 text-slate-700 mx-auto mb-4 opacity-20" />
                 <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Nenhum confronto encontrado.</p>
              </div>
            )}
          </main>
        </>
      )}

      {/* Regras e Info de Qualificação */}
      <footer className="max-w-4xl mx-auto space-y-8 pt-12 border-t border-white/5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
           <div className="space-y-4">
              <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                <Info className="w-4 h-4 text-yellow-500" /> Qualificação Brady Bowl
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed font-medium">
                Confrontos baseados nos resultados das <strong className="text-white">Semanas 1 a 11</strong>. Participam os TOP 3 de cada liga + o melhor 4º colocado geral.
              </p>
           </div>
           <div className="space-y-4">
              <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                <Medal className="w-4 h-4 text-yellow-500" /> Critério de Desempate
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed font-medium">
                Em caso de empate na pontuação da semana do playoff, o time de <strong className="text-white">Melhor Seed</strong> avança para a próxima fase.
              </p>
           </div>
        </div>
      </footer>
    </div>
  );
};

export default BradyGeneralPlayoffs;
