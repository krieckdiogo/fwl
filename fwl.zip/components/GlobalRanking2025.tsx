import React, { useState, useMemo, useEffect } from 'react';
import { 
  ArrowLeft, 
  Search, 
  Zap, 
  Target,
  Activity,
  Hash,
  ArrowUpRight,
  CheckCircle2,
  Sword,
  Shield,
  Layers,
  User as UserIcon,
  RefreshCw
} from 'lucide-react';
import { fetchLeagueData, getAvatarUrl } from '../services/sleeper';
import { FWL_OFFICIAL_IDS } from '../App';

interface GlobalRanking2025Props {
  onBack: () => void;
}

interface RankingEntry {
  rank: number;
  team: string;
  username: string;
  avatar: string | null;
  total: number;
  divisional: number;
  brady: number;
  playoffs: number;
  pf: number;
  badges: string[];
}

const STATIC_RANKING: RankingEntry[] = [
  { rank: 1, team: "Hijos de Rivers", username: "@Passarelli80", avatar: "338903348123287552", total: 1170, divisional: 240, brady: 80, playoffs: 850, pf: 2770.70, badges: [] },
  { rank: 2, team: "HeidlonG", username: "@HeidlonG", avatar: "468551469140029440", total: 1110, divisional: 360, brady: 100, playoffs: 650, pf: 2906.92, badges: ["🥉"] },
  { rank: 3, team: "Rictus FC", username: "@AmaraLynch", avatar: "1157147775981240320", total: 910, divisional: 260, brady: 180, playoffs: 470, pf: 2753.62, badges: ["🥉"] },
  { rank: 4, team: "Claudianosilva", username: "@Claudianosilva", avatar: "468205423851507712", total: 860, divisional: 480, brady: 180, playoffs: 200, pf: 2934.28, badges: ["🏆"] },
  { rank: 5, team: "Texão da Massa", username: "@RafaMartineli", avatar: "336688755913281536", total: 820, divisional: 460, brady: 340, playoffs: 20, pf: 2756.44, badges: ["🏆", "🥉"] },
  { rank: 6, team: "Coutinho15", username: "@Coutinho15", avatar: "867746187652755456", total: 820, divisional: 160, brady: 660, playoffs: 0, pf: 2745.52, badges: ["🏆"] },
  { rank: 7, team: "South Chiefs", username: "@kaueborges", avatar: "338302008800063488", total: 760, divisional: 300, brady: 460, playoffs: 0, pf: 2986.20, badges: ["🥈", "🥉"] },
  { rank: 8, team: "pedrotti", username: "@pedrotti", avatar: "472224673893199872", total: 730, divisional: 480, brady: 160, playoffs: 90, pf: 3098.98, badges: ["🏆"] },
  { rank: 9, team: "AleZucco", username: "@AleZucco", avatar: "863185362485125120", total: 670, divisional: 460, brady: 120, playoffs: 90, pf: 2741.38, badges: ["🏆"] },
  { rank: 10, team: "volnandy", username: "@volnandy", avatar: "472428675629117440", total: 670, divisional: 500, brady: 120, playoffs: 50, pf: 2704.42, badges: ["🏆"] },
  { rank: 11, team: "Kaepernick squad", username: "@TheFamousPh", avatar: "337759546947936256", total: 650, divisional: 400, brady: 160, playoffs: 90, pf: 2872.52, badges: ["🥈"] },
  { rank: 12, team: "BengaoDaMassa", username: "@BengaoDaMassa", avatar: "852654921206304768", total: 640, divisional: 520, brady: 100, playoffs: 20, pf: 2850.56, badges: ["🏆"] },
  { rank: 13, team: "SaloMAYE", username: "@thiagosalomao", avatar: "471120239071068160", total: 640, divisional: 540, brady: 80, playoffs: 20, pf: 2836.40, badges: ["🏆"] },
  { rank: 14, team: "DeflateKing", username: "@DeflateKing", avatar: "1119747355088924672", total: 640, divisional: 500, brady: 120, playoffs: 20, pf: 2830.32, badges: ["🏆"] },
  { rank: 15, team: "DS Valhalla", username: "@DSxDiogo", avatar: "468551469140029440", total: 640, divisional: 480, brady: 140, playoffs: 20, pf: 2693.38, badges: ["🏆"] },
  { rank: 16, team: "Joaoramalho Bandits", username: "@PedroDias", avatar: "740590858712952832", total: 640, divisional: 560, brady: 80, playoffs: 0, pf: 2617.08, badges: ["🏆"] },
  { rank: 17, team: "frostzx", username: "@frostzx", avatar: "468202517865717760", total: 620, divisional: 320, brady: 160, playoffs: 140, pf: 2955.46, badges: ["🥉"] },
  { rank: 18, team: "Seahawks LC", username: "@LucasS", avatar: "469133465809584128", total: 620, divisional: 500, brady: 120, playoffs: 0, pf: 2783.68, badges: ["🏆"] },
  { rank: 19, team: "Borgo Hawks", username: "@ivanborgo", avatar: "471373516593438720", total: 620, divisional: 380, brady: 40, playoffs: 200, pf: 2611.36, badges: ["🥈"] },
  { rank: 20, team: "SaintsJP", username: "@SaintsacreBR", avatar: "338104117082988544", total: 610, divisional: 400, brady: 160, playoffs: 50, pf: 2796.90, badges: ["🥈"] },
  { rank: 21, team: "Blitz do Chama", username: "@damatarafa", avatar: "471830606705352704", total: 600, divisional: 360, brady: 100, playoffs: 140, pf: 2872.30, badges: ["🥈"] },
  { rank: 22, team: "Leobala", username: "@Leobala", avatar: "867776191761612800", total: 600, divisional: 500, brady: 100, playoffs: 0, pf: 2815.78, badges: ["🏆"] },
  { rank: 23, team: "rafaelroxxa", username: "@rafaelroxxa", avatar: "468551469140029440", total: 600, divisional: 500, brady: 100, playoffs: 0, pf: 2649.08, badges: ["🏆"] },
  { rank: 24, team: "Sir Underdog 🏆", username: "@Josiel", avatar: "863836798084579328", total: 600, divisional: 480, brady: 120, playoffs: 0, pf: 2562.38, badges: ["🏆"] },
  { rank: 25, team: "vagnercf", username: "@vagnercf", avatar: "468202517865717760", total: 590, divisional: 420, brady: 80, playoffs: 90, pf: 2815.36, badges: ["🥈"] },
  { rank: 26, team: "San Jose dos Fields", username: "@OscarStrauss", avatar: null, total: 580, divisional: 460, brady: 120, playoffs: 0, pf: 2804.90, badges: ["🏆"] },
  { rank: 27, team: "GuiMartins", username: "@GuiMartins", avatar: null, total: 580, divisional: 440, brady: 140, playoffs: 0, pf: 2775.22, badges: ["🏆"] },
  { rank: 28, team: "Lunatkicks", username: "@Krieck", avatar: null, total: 570, divisional: 380, brady: 140, playoffs: 50, pf: 3136.56, badges: ["🥈"] },
  { rank: 29, team: "Flessakianos", username: "@flessak", avatar: null, total: 570, divisional: 320, brady: 200, playoffs: 50, pf: 2944.58, badges: ["🥉"] },
  { rank: 30, team: "Planet Hampton", username: "@MarcoMiranda05", avatar: null, total: 570, divisional: 300, brady: 180, playoffs: 90, pf: 2852.96, badges: ["🥉"] },
  { rank: 31, team: "Cyber Rats", username: "@OutLaio", avatar: null, total: 570, divisional: 400, brady: 120, playoffs: 50, pf: 2729.70, badges: ["🥈"] },
  { rank: 32, team: "jetro50", username: "@jetro50", avatar: null, total: 560, divisional: 380, brady: 160, playoffs: 20, pf: 2770.72, badges: ["🥈"] },
  { rank: 33, team: "Favela Fangs", username: "@Henrique88", avatar: null, total: 560, divisional: 480, brady: 80, playoffs: 0, pf: 2572.94, badges: ["🏆"] },
  { rank: 34, team: "RafaelKoehler", username: "@RafaelKoehler", avatar: null, total: 560, divisional: 480, brady: 60, playoffs: 20, pf: 2516.06, badges: ["🏆"] },
  { rank: 35, team: "Butt Fumble", username: "@srpinguim", avatar: null, total: 550, divisional: 180, brady: 100, playoffs: 270, pf: 2815.10, badges: [] },
  { rank: 36, team: "LucasPFerreira", username: "@LucasPFerreira", avatar: null, total: 550, divisional: 380, brady: 120, playoffs: 50, pf: 2773.88, badges: ["🥈"] },
  { rank: 37, team: "MBC Bees", username: "@FWeslleyPS", avatar: null, total: 550, divisional: 460, brady: 90, playoffs: 0, pf: 2514.84, badges: ["🏆"] },
  { rank: 38, team: "ライオンズ", username: "@Akiradodo", avatar: null, total: 540, divisional: 400, brady: 120, playoffs: 20, pf: 2906.16, badges: ["🥈"] },
  { rank: 39, team: "LeandroNS", username: "@LeandroNS", avatar: null, total: 540, divisional: 380, brady: 140, playoffs: 20, pf: 2876.14, badges: ["🥈"] },
  { rank: 40, team: "Love Hurts", username: "@JuliioS", avatar: null, total: 540, divisional: 480, brady: 60, playoffs: 0, pf: 2614.74, badges: ["🏆"] },
  { rank: 41, team: "AugustoFuente", username: "@AugustoFuente", avatar: null, total: 540, divisional: 480, brady: 60, playoffs: 0, pf: 2503.38, badges: ["🏆"] },
  { rank: 42, team: "Cerrado Tiger", username: "@Ronny10", avatar: null, total: 520, divisional: 400, brady: 120, playoffs: 0, pf: 2888.68, badges: ["🥈"] },
  { rank: 43, team: "GuiRezende", username: "@GuiRezende", avatar: null, total: 520, divisional: 340, brady: 180, playoffs: 0, pf: 2806.94, badges: ["🥉"] },
  { rank: 44, team: "BKW West Coast", username: "@ThiagoCruz", avatar: null, total: 520, divisional: 380, brady: 140, playoffs: 0, pf: 2786.02, badges: ["🥈"] },
  { rank: 45, team: "FlaFalcons", username: "@FlaFalcons", avatar: null, total: 500, divisional: 380, brady: 100, playoffs: 20, pf: 2782.10, badges: ["🥈"] },
  { rank: 46, team: "Chases da depressão", username: "@MatPio7", avatar: null, total: 500, divisional: 380, brady: 100, playoffs: 20, pf: 2697.74, badges: ["🥈"] },
  { rank: 47, team: "Viúvo do Brady", username: "@loisera", avatar: null, total: 500, divisional: 360, brady: 120, playoffs: 20, pf: 2668.94, badges: ["🥈"] },
  { rank: 48, team: "Blumenau 49ers", username: "@JoaoFillipe", avatar: null, total: 500, divisional: 340, brady: 160, playoffs: 0, pf: 2659.64, badges: ["🥈"] },
  { rank: 49, team: "Ué", username: "@GugaRochas", avatar: null, total: 490, divisional: 340, brady: 100, playoffs: 50, pf: 2839.84, badges: ["🥉"] },
  { rank: 50, team: "KFC Kings", username: "@Damata", avatar: null, total: 490, divisional: 360, brady: 80, playoffs: 50, pf: 2800.70, badges: ["🥈"] },
  { rank: 51, team: "AlisonBecker", username: "@AlisonBecker", avatar: null, total: 470, divisional: 260, brady: 120, playoffs: 90, pf: 2744.22, badges: ["🥉"] },
  { rank: 52, team: "osmar", username: "@osmar", avatar: null, total: 470, divisional: 360, brady: 60, playoffs: 50, pf: 2648.60, badges: ["🥈"] },
  { rank: 53, team: "FalcaoReal", username: "@FalcaoReal", avatar: null, total: 460, divisional: 280, brady: 160, playoffs: 20, pf: 2832.82, badges: ["🥉"] },
  { rank: 54, team: "COLOSSAL", username: "@Yuriidjsantos", avatar: null, total: 460, divisional: 340, brady: 120, playoffs: 0, pf: 2716.02, badges: ["🥈"] },
  { rank: 55, team: "Verdigris Calamities", username: "@CortCambraia", avatar: null, total: 460, divisional: 160, brady: 100, playoffs: 200, pf: 2340.12, badges: [] },
  { rank: 56, team: "Melca7", username: "@BS17", avatar: null, total: 450, divisional: 200, brady: 160, playoffs: 90, pf: 2821.86, badges: [] },
  { rank: 57, team: "Àlumani", username: "@CaioFig", avatar: null, total: 450, divisional: 200, brady: 160, playoffs: 90, pf: 2817.08, badges: [] },
  { rank: 58, team: "Green Bay Lakers", username: "@FernandoMoessa", avatar: null, total: 450, divisional: 280, brady: 80, playoffs: 90, pf: 2740.34, badges: ["🥉"] },
  { rank: 59, team: "American Bulldogs", username: "@lgwells", avatar: null, total: 450, divisional: 300, brady: 100, playoffs: 50, pf: 2702.62, badges: ["🥉"] },
  { rank: 60, team: "mathiascblc", username: "@mathiascblc", avatar: null, total: 440, divisional: 340, brady: 100, playoffs: 0, pf: 2849.16, badges: ["🥈"] },
  { rank: 61, team: "Reds disfarçados", username: "@Fabiobastos", avatar: null, total: 430, divisional: 260, brady: 120, playoffs: 50, pf: 2661.34, badges: ["🥉"] },
  { rank: 62, team: "Inno9", username: "@Inno9", avatar: null, total: 430, divisional: 300, brady: 80, playoffs: 50, pf: 2589.26, badges: ["🥉"] },
  { rank: 63, team: "Tiago_Caldeira", username: "@Tiago_Caldeira", avatar: null, total: 420, divisional: 220, brady: 200, playoffs: 0, pf: 2954.76, badges: ["🥉"] },
  { rank: 64, team: "DanPini", username: "@DanPini", avatar: null, total: 420, divisional: 260, brady: 140, playoffs: 20, pf: 2810.74, badges: ["🥉"] },
  { rank: 65, team: "LeandroGaucho", username: "@LeandroGaucho", avatar: null, total: 420, divisional: 300, brady: 100, playoffs: 20, pf: 2742.82, badges: ["🥉"] },
  { rank: 66, team: "Lutfi Lycans", username: "@renelutfi", avatar: null, total: 420, divisional: 160, brady: 120, playoffs: 140, pf: 2632.96, badges: [] },
  { rank: 67, team: "WillPro", username: "@WillPro", avatar: null, total: 420, divisional: 160, brady: 120, playoffs: 140, pf: 2531.46, badges: [] },
  { rank: 68, team: "SiaraBigheads", username: "@SiaraBigheads", avatar: null, total: 410, divisional: 200, brady: 120, playoffs: 90, pf: 2711.54, badges: [] },
  { rank: 69, team: "JoaoP97", username: "@JoaoP97", avatar: null, total: 400, divisional: 300, brady: 100, playoffs: 0, pf: 2738.58, badges: ["🥉"] },
  { rank: 70, team: "Ghost of Soteropolis", username: "@Rui", avatar: null, total: 400, divisional: 240, brady: 140, playoffs: 20, pf: 2697.00, badges: ["🥉"] },
  { rank: 71, team: "MAGRELÃO BLUEDOGS", username: "@romuloh83", avatar: null, total: 400, divisional: 260, brady: 120, playoffs: 20, pf: 2687.60, badges: ["🥉"] },
  { rank: 72, team: "Henry’s Kingdom", username: "@ericrgbueno87", avatar: null, total: 390, divisional: 240, brady: 100, playoffs: 50, pf: 2673.82, badges: ["🥉"] },
  { rank: 73, team: "Mamutes do Cerrado", username: "@Ortega84", avatar: null, total: 380, divisional: 180, brady: 180, playoffs: 20, pf: 2795.22, badges: [] },
  { rank: 74, team: "Sporting Braunschweig", username: "@LourivalMitto1587", avatar: null, total: 380, divisional: 160, brady: 80, playoffs: 140, pf: 2655.28, badges: [] },
  { rank: 75, team: "FELIPERAMS", username: "@FELIPERAMS", avatar: null, total: 380, divisional: 140, brady: 100, playoffs: 140, pf: 2595.92, badges: [] },
  { rank: 76, team: "FelipePatriots", username: "@FelipePatriots", avatar: null, total: 380, divisional: 140, brady: 100, playoffs: 140, pf: 2562.34, badges: [] },
  { rank: 77, team: "yasminfariadias", username: "@yasminfariadias", avatar: null, total: 370, divisional: 180, brady: 140, playoffs: 50, pf: 2883.22, badges: [] },
  { rank: 78, team: "Quack Attack", username: "@Caofarejador", avatar: null, total: 370, divisional: 180, brady: 100, playoffs: 90, pf: 2726.24, badges: [] },
  { rank: 79, team: "Green frogs", username: "@Sasquatch7899", avatar: null, total: 370, divisional: 180, brady: 140, playoffs: 50, pf: 2608.98, badges: [] },
  { rank: 80, team: "PANTERAS DA BAÊA", username: "@Tomchdown", avatar: null, total: 360, divisional: 140, brady: 200, playoffs: 20, pf: 2887.00, badges: [] },
  { rank: 81, team: "Porto Alegre Immortals", username: "@pnribeiro", avatar: null, total: 360, divisional: 240, brady: 120, playoffs: 0, pf: 2781.16, badges: [] },
  { rank: 82, team: "POA Klingons", username: "@Elieser", avatar: null, total: 360, divisional: 160, brady: 180, playoffs: 20, pf: 2633.20, badges: [] },
  { rank: 83, team: "“MaHomies”", username: "@GiantKiller33", avatar: null, total: 360, divisional: 100, brady: 60, playoffs: 200, pf: 2316.18, badges: [] },
  { rank: 84, team: "DGlad", username: "@DGlad", avatar: null, total: 350, divisional: 200, brady: 100, playoffs: 50, pf: 2847.64, badges: [] },
  { rank: 85, team: "Old No. 7th Round Picks", username: "@josuebrazil", avatar: null, total: 350, divisional: 140, brady: 160, playoffs: 50, pf: 2706.66, badges: [] },
  { rank: 86, team: "Redskins RS", username: "@Schoeninger22", avatar: null, total: 350, divisional: 180, brady: 120, playoffs: 50, pf: 2631.24, badges: [] },
  { rank: 87, team: "Rio Docs", username: "@TPessoa", avatar: null, total: 340, divisional: 180, brady: 160, playoffs: 0, pf: 2994.70, badges: [] },
  { rank: 88, team: "FC Chucruts", username: "@meninodourado", avatar: null, total: 340, divisional: 160, brady: 160, playoffs: 20, pf: 2877.18, badges: [] },
  { rank: 89, team: "VV NIX", username: "@VictorVieiraBR", avatar: null, total: 340, divisional: 220, brady: 120, playoffs: 0, pf: 2874.26, badges: [] },
  { rank: 90, team: "Emerik", username: "@Emerik", avatar: null, total: 340, divisional: 200, brady: 140, playoffs: 0, pf: 2870.90, badges: [] },
  { rank: 91, team: "NegoNey", username: "@CaioFioravanti", avatar: null, total: 340, divisional: 180, brady: 160, playoffs: 0, pf: 2850.76, badges: [] },
  { rank: 92, team: "W’69", username: "@ffroesBR", avatar: null, total: 340, divisional: 180, brady: 140, playoffs: 20, pf: 2831.22, badges: [] },
  { rank: 93, team: "21 Fighters", username: "@alb2106", avatar: null, total: 340, divisional: 200, brady: 120, playoffs: 20, pf: 2784.74, badges: [] },
  { rank: 94, team: "Eduardocfilho", username: "@Eduardocfilho", avatar: null, total: 340, divisional: 100, brady: 100, playoffs: 140, pf: 2531.54, badges: [] },
  { rank: 95, team: "Genipabus Dromedarios", username: "@tiagolagreca", avatar: null, total: 330, divisional: 180, brady: 100, playoffs: 50, pf: 2797.18, badges: [] },
  { rank: 96, team: "Carneiros Felpudos", username: "@Alexsgkobus", avatar: null, total: 330, divisional: 160, brady: 80, playoffs: 90, pf: 2544.12, badges: [] },
  { rank: 97, team: "Leitinho Dolphins", username: "@oleitinho", avatar: null, total: 330, divisional: 160, brady: 80, playoffs: 90, pf: 2433.20, badges: [] },
  { rank: 98, team: "marcobortolotto", username: "@marcobortolotto", avatar: null, total: 320, divisional: 200, brady: 120, playoffs: 0, pf: 2915.60, badges: [] },
  { rank: 99, team: "Brasília Wolfs", username: "@Br4ko", avatar: null, total: 320, divisional: 140, brady: 180, playoffs: 0, pf: 2883.50, badges: [] },
  { rank: 100, team: "bielvicente", username: "@bielvicente", avatar: null, total: 320, divisional: 140, brady: 180, playoffs: 0, pf: 2875.82, badges: [] },
  { rank: 101, team: "Felipesimoes", username: "@Felipesimoes", avatar: null, total: 320, divisional: 180, brady: 140, playoffs: 0, pf: 2726.26, badges: [] },
  { rank: 102, team: "Reagetime2", username: "@Reagetime2", avatar: null, total: 320, divisional: 200, brady: 100, playoffs: 20, pf: 2694.68, badges: [] },
  { rank: 103, team: "Real Garruchos F.C", username: "@pedrords", avatar: null, total: 310, divisional: 120, brady: 140, playoffs: 50, pf: 2881.96, badges: [] },
  { rank: 104, team: "Vader's", username: "@TheFabioGarcia", avatar: null, total: 310, divisional: 120, brady: 140, playoffs: 50, pf: 2739.18, badges: [] },
  { rank: 105, team: "Salimporto", username: "@Salimporto", avatar: null, total: 310, divisional: 120, brady: 100, playoffs: 90, pf: 2706.46, badges: [] },
  { rank: 106, team: "Bragil", username: "@Bragil", avatar: null, total: 310, divisional: 120, brady: 140, playoffs: 50, pf: 2637.50, badges: [] },
  { rank: 107, team: "Pittsburgh Stealers", username: "@Bimbira", avatar: null, total: 300, divisional: 140, brady: 160, playoffs: 0, pf: 2972.50, badges: [] },
  { rank: 108, team: "crflicao", username: "@crflicao", avatar: null, total: 300, divisional: 160, brady: 140, playoffs: 0, pf: 2855.14, badges: [] },
  { rank: 109, team: "Russell Wilson", username: "@HawkDestro", avatar: null, total: 300, divisional: 120, brady: 180, playoffs: 0, pf: 2839.46, badges: [] },
  { rank: 110, team: "Sirigaita", username: "@brusalvador", avatar: null, total: 300, divisional: 80, brady: 200, playoffs: 20, pf: 2682.46, badges: [] },
  { rank: 111, team: "GlockPurdy", username: "@matigianiners", avatar: null, total: 300, divisional: 140, brady: 160, playoffs: 0, pf: 2681.28, badges: [] },
  { rank: 112, team: "NathanLuccas22", username: "@NathanLuccas22", avatar: null, total: 300, divisional: 180, brady: 120, playoffs: 0, pf: 2648.44, badges: [] },
  { rank: 113, team: "Deflategreats FC", username: "@Jeison12", avatar: null, total: 300, divisional: 220, brady: 60, playoffs: 20, pf: 2606.28, badges: [] },
  { rank: 114, team: "Lima Schulka", username: "@Schulka", avatar: null, total: 300, divisional: 140, brady: 160, playoffs: 0, pf: 2593.26, badges: [] },
  { rank: 115, team: "Allyson Eagles", username: "@AllysonEagles", avatar: null, total: 300, divisional: 160, brady: 140, playoffs: 0, pf: 2551.44, badges: [] },
  { rank: 116, team: "beu128", username: "@beu128", avatar: null, total: 300, divisional: 180, brady: 100, playoffs: 20, pf: 2540.04, badges: [] },
  { rank: 117, team: "49ersForever", username: "@HadesX", avatar: null, total: 300, divisional: 200, brady: 100, playoffs: 0, pf: 2478.32, badges: [] },
  { rank: 118, team: "Capivaras Espaciais", username: "@czarmaick", avatar: null, total: 290, divisional: 120, brady: 120, playoffs: 50, pf: 2747.98, badges: [] },
  { rank: 119, team: "AaronFavre", username: "@AaronFavre", avatar: null, total: 290, divisional: 120, brady: 120, playoffs: 50, pf: 2657.18, badges: [] },
  { rank: 120, team: "LucasKP", username: "@LucasKP", avatar: null, total: 290, divisional: 80, brady: 120, playoffs: 90, pf: 2418.34, badges: [] },
  { rank: 121, team: "Exit light, enter night!", username: "@NeltonLopes", avatar: null, total: 280, divisional: 160, brady: 120, playoffs: 0, pf: 2768.78, badges: [] },
  { rank: 122, team: "RodGianini", username: "@RodGianini", avatar: null, total: 280, divisional: 120, brady: 160, playoffs: 0, pf: 2678.68, badges: [] },
  { rank: 123, team: "JoaoNascimento", username: "@JoaoNascimento", avatar: null, total: 280, divisional: 200, brady: 80, playoffs: 0, pf: 2671.02, badges: [] },
  { rank: 124, team: "MateusThomazini", username: "@MateusThomazini", avatar: null, total: 280, divisional: 120, brady: 140, playoffs: 20, pf: 2656.66, badges: [] },
  { rank: 125, team: "Urubroncos FC", username: "@pedrocysne10", avatar: null, total: 280, divisional: 180, brady: 80, playoffs: 20, pf: 2642.58, badges: [] },
  { rank: 126, team: "Eduhenri", username: "@Eduhenri", avatar: null, total: 280, divisional: 160, brady: 120, playoffs: 0, pf: 2622.48, badges: [] },
  { rank: 127, team: "chicopika", username: "@chicopika", avatar: null, total: 280, divisional: 180, brady: 100, playoffs: 0, pf: 2614.34, badges: [] },
  { rank: 128, team: "AnJuFire", username: "@AnJuFire", avatar: null, total: 280, divisional: 120, brady: 160, playoffs: 0, pf: 2580.54, badges: [] },
  { rank: 129, team: "PatsMan", username: "@PatsMan", avatar: null, total: 280, divisional: 140, brady: 140, playoffs: 0, pf: 2577.12, badges: [] },
  { rank: 130, team: "Isaque49er", username: "@Isaque49er", avatar: null, total: 280, divisional: 160, brady: 100, playoffs: 20, pf: 2563.68, badges: [] },
  { rank: 131, team: "FelipeFelix", username: "@FelipeFelix", avatar: null, total: 280, divisional: 140, brady: 140, playoffs: 0, pf: 2561.92, badges: [] },
  { rank: 132, team: "ManualNFLruim", username: "@ManualNFLruim", avatar: null, total: 280, divisional: 140, brady: 120, playoffs: 20, pf: 2529.68, badges: [] },
  { rank: 133, team: "AndreBruz", username: "@AndreBruz", avatar: null, total: 270, divisional: 80, brady: 140, playoffs: 50, pf: 2723.72, badges: [] },
  { rank: 134, team: "In AR we trust", username: "@ViniB", avatar: null, total: 270, divisional: 100, brady: 120, playoffs: 50, pf: 2716.28, badges: [] },
  { rank: 135, team: "Direful Teachers", username: "@vsommah", avatar: null, total: 270, divisional: 160, brady: 60, playoffs: 50, pf: 2568.00, badges: [] },
  { rank: 136, team: "diegohssg", username: "@diegohssg", avatar: null, total: 260, divisional: 180, brady: 80, playoffs: 0, pf: 2785.92, badges: [] },
  { rank: 137, team: "Corvos Caolhos", username: "@superochoque", avatar: null, total: 260, divisional: 100, brady: 140, playoffs: 20, pf: 2776.18, badges: [] },
  { rank: 138, team: "dariocsilva", username: "@dariocsilva", avatar: null, total: 260, divisional: 220, brady: 40, playoffs: 0, pf: 2757.08, badges: [] },
  { rank: 139, team: "Nega Jurema Renegades", username: "@hugosjr", avatar: null, total: 260, divisional: 160, brady: 100, playoffs: 0, pf: 2729.58, badges: [] },
  { rank: 140, team: "Pequi Smashers", username: "@oMoura", avatar: null, total: 260, divisional: 160, brady: 100, playoffs: 0, pf: 2704.72, badges: [] },
  { rank: 141, team: "Terê Bone's", username: "@Rodra26", avatar: null, total: 260, divisional: 120, brady: 140, playoffs: 0, pf: 2677.82, badges: [] },
  { rank: 142, team: "joaosandin", username: "@joaosandin", avatar: null, total: 260, divisional: 140, brady: 120, playoffs: 0, pf: 2658.52, badges: [] },
  { rank: 143, team: "Maringá Fans", username: "@igorfan", avatar: null, total: 260, divisional: 120, brady: 120, playoffs: 20, pf: 2657.88, badges: [] },
  { rank: 144, team: "Game of Mahomes", username: "@luckypio", avatar: null, total: 260, divisional: 160, brady: 100, playoffs: 0, pf: 2631.60, badges: [] },
  { rank: 145, team: "Marigoat", username: "@theblackbest", avatar: null, total: 260, divisional: 120, brady: 140, playoffs: 0, pf: 2626.08, badges: [] },
  { rank: 146, team: "Big D", username: "@luizgecco55", avatar: null, total: 260, divisional: 180, brady: 80, playoffs: 0, pf: 2606.60, badges: [] },
  { rank: 147, team: "Santástico da NFL", username: "@markinhosfc11", avatar: null, total: 260, divisional: 60, brady: 180, playoffs: 20, pf: 2591.96, badges: [] },
  { rank: 148, team: "salsichatony", username: "@salsichatony", avatar: null, total: 260, divisional: 120, brady: 140, playoffs: 0, pf: 2588.78, badges: [] },
  { rank: 149, team: "Tre White Goalie Academy", username: "@hellison999", avatar: null, total: 260, divisional: 140, brady: 120, playoffs: 0, pf: 2587.92, badges: [] },
  { rank: 150, team: "Green Bay Diamonds", username: "@Jeeh_GBP", avatar: null, total: 260, divisional: 100, brady: 140, playoffs: 20, pf: 2583.78, badges: [] },
  { rank: 151, team: "JordanLoveMyLove10", username: "@JordanLoveMyLove10", avatar: null, total: 260, divisional: 100, brady: 160, playoffs: 0, pf: 2553.42, badges: [] },
  { rank: 152, team: "Matligas", username: "@MatLigas", avatar: null, total: 260, divisional: 160, brady: 100, playoffs: 0, pf: 2545.08, badges: [] },
  { rank: 153, team: "Steeloso", username: "@AndreGenghini", avatar: null, total: 260, divisional: 140, brady: 120, playoffs: 0, pf: 2544.18, badges: [] },
  { rank: 154, team: "cardosoo", username: "@cardosoo", avatar: null, total: 260, divisional: 180, brady: 80, playoffs: 0, pf: 2536.74, badges: [] },
  { rank: 155, team: "Blitzburgh", username: "@yuriadams", avatar: null, total: 260, divisional: 100, brady: 160, playoffs: 0, pf: 2516.54, badges: [] },
  { rank: 156, team: "Moita Team", username: "@moesio", avatar: null, total: 260, divisional: 160, brady: 100, playoffs: 0, pf: 2474.42, badges: [] },
  { rank: 157, team: "pipito", username: "@pipito", avatar: null, total: 260, divisional: 80, brady: 160, playoffs: 20, pf: 2460.62, badges: [] },
  { rank: 158, team: "Savio87", username: "@Savio87", avatar: null, total: 260, divisional: 160, brady: 80, playoffs: 20, pf: 2447.86, badges: [] },
  { rank: 159, team: "Kobawsk", username: "@Kobawsk", avatar: null, total: 260, divisional: 120, brady: 120, playoffs: 20, pf: 2402.88, badges: [] },
  { rank: 160, team: "narutoeagles", username: "@narutoeagles", avatar: null, total: 260, divisional: 120, brady: 140, playoffs: 0, pf: 2373.64, badges: [] },
  { rank: 161, team: "Zorzella", username: "@Zorzella", avatar: null, total: 250, divisional: 120, brady: 80, playoffs: 50, pf: 2516.36, badges: [] },
  { rank: 162, team: "GaloMG", username: "@GaloMG", avatar: null, total: 250, divisional: 120, brady: 40, playoffs: 90, pf: 2448.46, badges: [] },
  { rank: 163, team: "Angeloni99", username: "@Angeloni99", avatar: null, total: 250, divisional: 120, brady: 80, playoffs: 50, pf: 2338.68, badges: [] },
  { rank: 164, team: "ThomasM3l00", username: "@ThomasM3l00", avatar: null, total: 250, divisional: 120, brady: 80, playoffs: 50, pf: 2245.30, badges: [] },
  { rank: 165, team: "VCF_49ers", username: "@VCF_49ers", avatar: null, total: 240, divisional: 120, brady: 100, playoffs: 20, pf: 2812.62, badges: [] },
  { rank: 166, team: "Explosion Raiders", username: "@Genys", avatar: null, total: 240, divisional: 80, brady: 140, playoffs: 20, pf: 2699.60, badges: [] },
  { rank: 167, team: "nY eRs", username: "@nyers", avatar: null, total: 240, divisional: 100, brady: 140, playoffs: 0, pf: 2691.42, badges: [] },
  { rank: 168, team: "Gumagol971", username: "@Gumagol971", avatar: null, total: 240, divisional: 120, brady: 120, playoffs: 0, pf: 2658.48, badges: [] },
  { rank: 169, team: "ThiagoW", username: "@ThiagoW", avatar: null, total: 240, divisional: 120, brady: 100, playoffs: 20, pf: 2569.26, badges: [] },
  { rank: 170, team: "helton", username: "@helton", avatar: null, total: 240, divisional: 120, brady: 120, playoffs: 0, pf: 2552.84, badges: [] },
  { rank: 171, team: "Lesio9ers", username: "@dennisamorim", avatar: null, total: 240, divisional: 120, brady: 100, playoffs: 20, pf: 2529.94, badges: [] },
  { rank: 172, team: "Camaragibe Republicans", username: "@PedroLuz07", avatar: null, total: 240, divisional: 100, brady: 120, playoffs: 20, pf: 2520.94, badges: [] },
  { rank: 173, team: "Fogonabombaaaa", username: "@Fogonabombaaaa", avatar: null, total: 240, divisional: 140, brady: 100, playoffs: 0, pf: 2517.34, badges: [] },
  { rank: 174, team: "JoaoElGringo", username: "@JoaoElGringo", avatar: null, total: 240, divisional: 160, brady: 60, playoffs: 20, pf: 2513.52, badges: [] },
  { rank: 175, team: "jperocco", username: "@jperocco", avatar: null, total: 240, divisional: 140, brady: 100, playoffs: 0, pf: 2501.82, badges: [] },
  { rank: 176, team: "Mestre do Fantasy", username: "@Gianluigi", avatar: null, total: 240, divisional: 160, brady: 80, playoffs: 0, pf: 2491.36, badges: [] },
  { rank: 177, team: "OCITELHTA VENTANIA", username: "@emilioneto86", avatar: null, total: 240, divisional: 120, brady: 120, playoffs: 0, pf: 2487.76, badges: [] },
  { rank: 178, team: "Prezzanfl", username: "@Prezzanfl", avatar: null, total: 240, divisional: 140, brady: 100, playoffs: 0, pf: 2485.56, badges: [] },
  { rank: 179, team: "MorandiHawks", username: "@MorandiHawks", avatar: null, total: 240, divisional: 120, brady: 120, playoffs: 0, pf: 2424.42, badges: [] },
  { rank: 180, team: "Diogoashura", username: "@Diogoashura", avatar: null, total: 240, divisional: 120, brady: 120, playoffs: 0, pf: 2421.00, badges: [] },
  { rank: 181, team: "Browns Porto", username: "@mporto96", avatar: null, total: 240, divisional: 100, brady: 140, playoffs: 0, pf: 2410.22, badges: [] },
  { rank: 182, team: "ZekMVP2022", username: "@ZekMVP2022", avatar: null, total: 240, divisional: 120, brady: 120, playoffs: 0, pf: 2326.64, badges: [] },
  { rank: 183, team: "Coltsquest", username: "@Coltsquest", avatar: null, total: 240, divisional: 60, brady: 160, playoffs: 20, pf: 2323.08, badges: [] },
  { rank: 184, team: "Vulgo Malvadão", username: "@ajunior", avatar: null, total: 230, divisional: 40, brady: 140, playoffs: 50, pf: 2498.64, badges: [] },
  { rank: 185, team: "Marau Bitu", username: "@andreseara", avatar: null, total: 230, divisional: 80, brady: 100, playoffs: 50, pf: 2417.62, badges: [] },
  { rank: 186, team: "Feehfiz", username: "@Feehfiz", avatar: null, total: 220, divisional: 160, brady: 60, playoffs: 0, pf: 2831.04, badges: [] },
  { rank: 187, team: "WI Redentor", username: "@Buzzuh", avatar: null, total: 220, divisional: 100, brady: 120, playoffs: 0, pf: 2796.86, badges: [] },
  { rank: 188, team: "RodrigoAlane", username: "@RodrigoAlane", avatar: null, total: 220, divisional: 100, brady: 120, playoffs: 0, pf: 2686.32, badges: [] },
  { rank: 189, team: "LiaraFP", username: "@LiaraFP", avatar: null, total: 220, divisional: 140, brady: 80, playoffs: 0, pf: 2673.08, badges: [] },
  { rank: 190, team: "vilsonm", username: "@vilsonm", avatar: null, total: 220, divisional: 100, brady: 100, playoffs: 20, pf: 2636.24, badges: [] },
  { rank: 191, team: "Gunpowder Crew", username: "@polvorje", avatar: null, total: 220, divisional: 100, brady: 120, playoffs: 0, pf: 2633.68, badges: [] },
  { rank: 192, team: "Los llamas", username: "@EddieBarreto", avatar: null, total: 220, divisional: 140, brady: 80, playoffs: 0, pf: 2628.74, badges: [] },
  { rank: 193, team: "VaiCurintia", username: "@GuilhermeSimoes", avatar: null, total: 220, divisional: 100, brady: 120, playoffs: 0, pf: 2600.98, badges: [] },
  { rank: 194, team: "darcklauser", username: "@darcklauser", avatar: null, total: 220, divisional: 100, brady: 120, playoffs: 0, pf: 2598.06, badges: [] },
  { rank: 195, team: "Clemson Broncos", username: "@BrunoFonseca7L", avatar: null, total: 220, divisional: 100, brady: 120, playoffs: 0, pf: 2549.60, badges: [] },
  { rank: 196, team: "Mesquita1983", username: "@Mesquita1983", avatar: null, total: 220, divisional: 140, brady: 80, playoffs: 0, pf: 2495.48, badges: [] },
  { rank: 197, team: "Giants Suzano", username: "@eumro", avatar: null, total: 220, divisional: 140, brady: 60, playoffs: 20, pf: 2320.18, badges: [] },
  { rank: 198, team: "Golden Tate Warriors", username: "@Canoleira", avatar: null, total: 200, divisional: 120, brady: 80, playoffs: 0, pf: 2651.04, badges: [] },
  { rank: 199, team: "Mundstock", username: "@Mundstock", avatar: null, total: 200, divisional: 80, brady: 100, playoffs: 20, pf: 2641.58, badges: [] },
  { rank: 200, team: "Samurais de olhos Azuis", username: "@B3TO", avatar: null, total: 200, divisional: 80, brady: 100, playoffs: 20, pf: 2637.66, badges: [] },
  { rank: 201, team: "Capivara Patriota", username: "@KaeZar", avatar: null, total: 200, divisional: 80, brady: 120, playoffs: 0, pf: 2631.24, badges: [] },
  { rank: 202, team: "KauEdelman11", username: "@KauEdelman11", avatar: null, total: 200, divisional: 80, brady: 100, playoffs: 20, pf: 2631.12, badges: [] },
  { rank: 203, team: "NO Saints", username: "@HenriqueAraujo", avatar: null, total: 200, divisional: 140, brady: 60, playoffs: 0, pf: 2630.34, badges: [] },
  { rank: 204, team: "Meia Boca Juniors", username: "@JrMendonca", avatar: null, total: 200, divisional: 100, brady: 100, playoffs: 0, pf: 2625.86, badges: [] },
  { rank: 205, team: "GuiOrtiz", username: "@GuiOrtiz", avatar: null, total: 200, divisional: 100, brady: 100, playoffs: 0, pf: 2560.14, badges: [] },
  { rank: 206, team: "How I Metcalf Your Mother", username: "@KamikazePiledrivers", avatar: null, total: 200, divisional: 120, brady: 80, playoffs: 0, pf: 2543.70, badges: [] },
  { rank: 207, team: "Last but not least", username: "@Ljcboy", avatar: null, total: 200, divisional: 100, brady: 80, playoffs: 20, pf: 2517.24, badges: [] },
  { rank: 208, team: "RegisCarrara", username: "@RegisCarrara", avatar: null, total: 200, divisional: 140, brady: 40, playoffs: 20, pf: 2489.40, badges: [] },
  { rank: 209, team: "GabrielSimioni", username: "@GabrielSimioni", avatar: null, total: 200, divisional: 120, brady: 80, playoffs: 0, pf: 2485.64, badges: [] },
  { rank: 210, team: "Denver Donkeys", username: "@bertini", avatar: null, total: 200, divisional: 60, brady: 120, playoffs: 20, pf: 2485.24, badges: [] },
  { rank: 211, team: "Montanha13", username: "@Montanha13", avatar: null, total: 200, divisional: 100, brady: 80, playoffs: 20, pf: 2465.12, badges: [] },
  { rank: 212, team: "Packão da Massa", username: "@Faula", avatar: null, total: 200, divisional: 40, brady: 160, playoffs: 0, pf: 2436.76, badges: [] },
  { rank: 213, team: "EaglesABS", username: "@EaglesABS", avatar: null, total: 200, divisional: 120, brady: 80, playoffs: 0, pf: 2434.02, badges: [] },
  { rank: 214, team: "tvvsgc", username: "@tvvsgc", avatar: null, total: 200, divisional: 140, brady: 60, playoffs: 0, pf: 2359.74, badges: [] },
  { rank: 215, team: "VoliBEARS", username: "@VoliBEARS", avatar: null, total: 200, divisional: 140, brady: 60, playoffs: 0, pf: 2310.78, badges: [] },
  { rank: 216, team: "vitor9", username: "@vitor9", avatar: null, total: 200, divisional: 60, brady: 120, playoffs: 20, pf: 2139.82, badges: [] },
  { rank: 217, team: "Broncos 2k25", username: "@ajuniords", avatar: null, total: 180, divisional: 120, brady: 60, playoffs: 0, pf: 2638.02, badges: [] },
  { rank: 218, team: "Brazuka Cheesers", username: "@TaallesMaartins", avatar: null, total: 180, divisional: 100, brady: 80, playoffs: 0, pf: 2610.42, badges: [] },
  { rank: 219, team: "Nascimentimao", username: "@Nascimentimao", avatar: null, total: 180, divisional: 60, brady: 120, playoffs: 0, pf: 2570.00, badges: [] },
  { rank: 220, team: "BroncosBr", username: "@BroncosBr", avatar: null, total: 180, divisional: 120, brady: 60, playoffs: 0, pf: 2553.92, badges: [] },
  { rank: 221, team: "migliorinisa", username: "@migliorinisa", avatar: null, total: 180, divisional: 60, brady: 100, playoffs: 20, pf: 2534.06, badges: [] },
  { rank: 222, team: "PinhaisUnderdogs", username: "@PinhaisUnderdogs", avatar: null, total: 180, divisional: 80, brady: 80, playoffs: 20, pf: 2519.22, badges: [] },
  { rank: 223, team: "Niteroi Giants", username: "@hragoncalves", avatar: null, total: 180, divisional: 60, brady: 120, playoffs: 0, pf: 2504.18, badges: [] },
  { rank: 224, team: "CWB Empacotadores", username: "@SrJabiroca26", avatar: null, total: 180, divisional: 120, brady: 60, playoffs: 0, pf: 2470.48, badges: [] },
  { rank: 225, team: "Brazilian Colts", username: "@rafamarques", avatar: null, total: 180, divisional: 100, brady: 60, playoffs: 20, pf: 2452.80, badges: [] },
  { rank: 226, team: "PauloFerreira", username: "@PauloFerreira", avatar: null, total: 180, divisional: 120, brady: 60, playoffs: 0, pf: 2425.08, badges: [] },
  { rank: 227, team: "Island Kubricks", username: "@allanray1979", avatar: null, total: 180, divisional: 120, brady: 60, playoffs: 0, pf: 2411.68, badges: [] },
  { rank: 228, team: "ACosta13", username: "@ACosta13", avatar: null, total: 160, divisional: 80, brady: 80, playoffs: 0, pf: 2604.14, badges: [] },
  { rank: 229, team: "Campinas Broncos", username: "@AlexMarchi", avatar: null, total: 160, divisional: 80, brady: 60, playoffs: 20, pf: 2557.14, badges: [] },
  { rank: 230, team: "BernardoMachado", username: "@BernardoMachado", avatar: null, total: 160, divisional: 80, brady: 80, playoffs: 0, pf: 2537.28, badges: [] },
  { rank: 231, team: "Black Bulls", username: "@Walmiro", avatar: null, total: 160, divisional: 80, brady: 80, playoffs: 0, pf: 2514.92, badges: [] },
  { rank: 232, team: "wladspfc", username: "@wladspfc", avatar: null, total: 160, divisional: 100, brady: 60, playoffs: 0, pf: 2500.98, badges: [] },
  { rank: 233, team: "Gustavao", username: "@Gustavao", avatar: null, total: 160, divisional: 80, brady: 80, playoffs: 0, pf: 2495.48, badges: [] },
  { rank: 234, team: "Gildarte", username: "@Gildarte", avatar: null, total: 160, divisional: 80, brady: 80, playoffs: 0, pf: 2324.04, badges: [] },
  { rank: 235, team: "FabricioCunha", username: "@FabricioCunha", avatar: null, total: 140, divisional: 80, brady: 60, playoffs: 0, pf: 2598.58, badges: [] },
  { rank: 236, team: "Carcarás do Cerrado", username: "@mac0387", avatar: null, total: 140, divisional: 80, brady: 60, playoffs: 0, pf: 2594.50, badges: [] },
  { rank: 237, team: "xanlost", username: "@xanlost", avatar: null, total: 140, divisional: 60, brady: 80, playoffs: 0, pf: 2540.58, badges: [] },
  { rank: 238, team: "joaomoherdaui", username: "@joaomoherdaui", avatar: null, total: 140, divisional: 40, brady: 100, playoffs: 0, pf: 2414.70, badges: [] },
  { rank: 239, team: "BrHorse", username: "@BrHorse", avatar: null, total: 140, divisional: 80, brady: 60, playoffs: 0, pf: 2407.58, badges: [] },
  { rank: 240, team: "SOAD", username: "@DiegoFilipi", avatar: null, total: 140, divisional: 60, brady: 80, playoffs: 0, pf: 2269.08, badges: [] },
  { rank: 241, team: "SipansBr", username: "@SipansBr", avatar: null, total: 140, divisional: 40, brady: 80, playoffs: 20, pf: 2258.86, badges: [] },
  { rank: 242, team: "MTosti", username: "@MTosti", avatar: null, total: 140, divisional: 80, brady: 60, playoffs: 0, pf: 2192.32, badges: [] },
  { rank: 243, team: "AndreLimas", username: "@AndreLimas", avatar: null, total: 140, divisional: 120, brady: 0, playoffs: 20, pf: 2149.78, badges: [] },
  { rank: 244, team: "North East Harpy", username: "@davilimmah", avatar: null, total: 140, divisional: 60, brady: 60, playoffs: 20, pf: 1913.50, badges: [] },
  { rank: 245, team: "Love Thy Nabers", username: "@giordanotoso", avatar: null, total: 120, divisional: 60, brady: 40, playoffs: 20, pf: 2355.72, badges: [] },
  { rank: 246, team: "Lambeaughini", username: "@adrianonfilho", avatar: null, total: 120, divisional: 60, brady: 40, playoffs: 20, pf: 2115.86, badges: [] },
  { rank: 247, team: "rapharegueira", username: "@rapharegueira", avatar: null, total: 120, divisional: 60, brady: 60, playoffs: 0, pf: 2082.58, badges: [] },
  { rank: 248, team: "Viuvo do Baker", username: "@GustavoInsua", avatar: null, total: 100, divisional: 40, brady: 60, playoffs: 0, pf: 2393.18, badges: [] },
  { rank: 249, team: "GMJohnWick", username: "@GMjohnWick", avatar: null, total: 100, divisional: 20, brady: 80, playoffs: 0, pf: 2185.28, badges: [] },
  { rank: 250, team: "EULLER_MATOS", username: "@EULLER_MATOS", avatar: null, total: 100, divisional: 20, brady: 80, playoffs: 0, pf: 1999.76, badges: [] },
  { rank: 251, team: "BLACK SAILS 66", username: "@JSANCHEZ62", avatar: null, total: 80, divisional: 40, brady: 40, playoffs: 0, pf: 2288.92, badges: [] },
  { rank: 252, team: "saylentbob", username: "@saylentbob", avatar: null, total: 50, divisional: 0, brady: 50, playoffs: 0, pf: 1485.48, badges: [] }
];

const GlobalRanking2025: React.FC<GlobalRanking2025Props> = ({ onBack }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [userAvatarMap, setUserAvatarMap] = useState<Record<string, string>>({});
  const [loadingAvatars, setLoadingAvatars] = useState(true);

  // Sync real avatars from Sleeper API using the official league IDs
  useEffect(() => {
    const syncAvatars = async () => {
      setLoadingAvatars(true);
      const map: Record<string, string> = {};
      try {
        // We fetch multiple leagues in parallel to build a comprehensive user map
        // Limitation: Rate limits might apply, but fetchLeagueData is relatively fast
        const results = await Promise.all(
          FWL_OFFICIAL_IDS.slice(0, 15).map(id => fetchLeagueData(id).catch(() => null))
        );

        results.forEach(data => {
          if (!data) return;
          data.users.forEach(user => {
            if (user.avatar) {
              map[user.display_name.toLowerCase()] = user.avatar;
            }
          });
        });
        setUserAvatarMap(map);
      } catch (err) {
        console.error("Failed to sync ranking avatars:", err);
      } finally {
        setLoadingAvatars(false);
      }
    };
    syncAvatars();
  }, []);

  const filteredRanking = useMemo(() => {
    const list = searchTerm 
      ? STATIC_RANKING.filter(entry => 
          entry.team.toLowerCase().includes(searchTerm.toLowerCase()) || 
          entry.username.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : STATIC_RANKING;

    // Enhance entry with live avatar if available in map
    return list.map(entry => {
      const cleanUsername = entry.username.replace('@', '').toLowerCase();
      const liveAvatar = userAvatarMap[cleanUsername];
      return {
        ...entry,
        avatar: liveAvatar || entry.avatar
      };
    });
  }, [searchTerm, userAvatarMap]);

  return (
    <div className="min-h-screen bg-[#02040a] text-slate-200 selection:bg-cyan-500/30">
      {/* Hyper-Visual Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-[600px] bg-gradient-to-b from-blue-600/20 to-transparent opacity-40"></div>
        <div className="absolute -top-[20%] -left-[10%] w-[60%] h-[60%] bg-blue-500/10 blur-[160px] rounded-full"></div>
      </div>

      {/* Futuristic Header */}
      <header className="sticky top-0 z-[100] bg-black/60 backdrop-blur-2xl border-b border-white/5 py-6">
        <div className="max-w-7xl mx-auto px-6 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-8 w-full lg:w-auto">
            <button 
              onClick={onBack} 
              className="p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-white transition-all group active:scale-95"
            >
              <ArrowLeft className="w-6 h-6 group-hover:-translate-x-1.5 transition-transform" />
            </button>
            <div className="flex flex-col">
              <div className="flex items-center gap-4">
                 <h1 className="text-4xl font-black text-white uppercase italic tracking-tighter leading-none">
                  Ranking <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">2025</span>
                 </h1>
              </div>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mt-1.5 flex items-center gap-2">
                <Hash className="w-3 h-3 text-blue-500" /> Consolidado das ligas FWL
              </p>
            </div>
          </div>
          
          <div className="relative w-full lg:w-[480px] group">
            <div className="absolute left-6 top-1/2 -translate-y-1/2 flex items-center gap-3">
               {loadingAvatars ? (
                 <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin" />
               ) : (
                 <Search className="w-4 h-4 text-slate-500 group-focus-within:text-cyan-400 transition-colors" />
               )}
               <div className="w-[1px] h-4 bg-white/10 group-focus-within:bg-cyan-400/50 transition-colors"></div>
            </div>
            <input 
              type="text" 
              placeholder="Pesquisar por Manager ou Equipe..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-[1.5rem] pl-16 pr-8 py-5 text-sm text-white outline-none focus:border-cyan-500/50 focus:ring-4 focus:ring-cyan-500/5 transition-all shadow-2xl placeholder:text-slate-600"
            />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12 lg:py-16 relative z-10 space-y-16">
        
        {/* Global List */}
        <section className="space-y-6">
          <div className="flex items-center justify-between px-8 text-[10px] font-black text-slate-600 uppercase tracking-[0.4em]">
             <div className="flex items-center gap-4">
                <Activity className="w-4 h-4 text-blue-500" />
                <span>Leaderboard Standing (252 Managers)</span>
             </div>
             <div className="hidden md:flex items-center gap-8">
                <span>Distribution Breakdown</span>
                <span>League PF</span>
             </div>
          </div>

          <div className="space-y-3">
             {filteredRanking.map((entry) => {
               const isFinalsQualified = entry.rank <= 12;
               // Sleeper IDs numeric vs hashes: numeric IDs from export don't load direct, hashes do. 
               // Our useEffect map fixes this by providing real hashes.
               const avatarUrl = getAvatarUrl(entry.avatar);
               
               return (
                 <div 
                   key={entry.rank} 
                   className={`group relative flex flex-col xl:flex-row items-center gap-8 p-6 lg:p-8 rounded-[2.5rem] transition-all border ${
                     isFinalsQualified 
                     ? 'bg-cyan-600/5 border-cyan-500/30 hover:bg-cyan-600/10 hover:border-cyan-400/50 shadow-[0_0_40px_rgba(6,182,212,0.1)]' 
                     : 'bg-[#0a0c14]/60 border-white/5 hover:bg-white/[0.04] hover:border-blue-500/20'
                   }`}
                 >
                    {/* Rank Indicator */}
                    <div className={`shrink-0 flex items-center justify-center w-16 h-16 rounded-3xl font-mono font-black text-2xl italic relative overflow-hidden transition-all ${
                      isFinalsQualified ? 'bg-cyan-500 text-cyan-950 shadow-lg' : 'bg-black/40 border border-white/10 text-slate-600 group-hover:text-blue-400 group-hover:border-blue-500/30'
                    }`}>
                       {entry.rank}
                    </div>

                    {/* Manager Info */}
                    <div className="flex-1 min-w-0 text-center xl:text-left">
                       <div className="flex flex-wrap items-center justify-center xl:justify-start gap-4 mb-1">
                          <div className="flex items-center gap-4 overflow-hidden">
                             <div className="relative group/pfp shrink-0">
                               <div className={`w-12 h-12 rounded-full border-2 p-0.5 flex items-center justify-center bg-slate-900 transition-all duration-300 ${isFinalsQualified ? 'border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)]' : 'border-slate-800'}`}>
                                 {entry.avatar ? (
                                   <img 
                                     src={avatarUrl} 
                                     className="w-full h-full rounded-full object-cover"
                                     alt={entry.team}
                                     onError={(e) => { 
                                       e.currentTarget.style.display = 'none'; 
                                       e.currentTarget.parentElement?.querySelector('.fallback')?.classList.remove('hidden'); 
                                     }}
                                   />
                                 ) : null}
                                 <UserIcon className={`fallback w-6 h-6 text-slate-700 ${entry.avatar ? 'hidden' : ''}`} />
                               </div>
                             </div>
                             <div className="flex flex-col min-w-0">
                               <h4 className={`text-2xl font-black uppercase italic tracking-tighter truncate max-w-[320px] transition-colors ${
                                 isFinalsQualified ? 'text-white' : 'text-slate-300 group-hover:text-white'
                               }`}>{entry.team}</h4>
                               <p className="text-xs font-bold text-slate-500 uppercase tracking-[0.2em] group-hover:text-slate-400 transition-colors">{entry.username}</p>
                             </div>
                          </div>
                          
                          {isFinalsQualified && (
                            <div className="flex items-center gap-1.5 px-3 py-1 bg-cyan-500/20 border border-cyan-500/40 rounded-full">
                               <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                               <span className="text-[8px] font-black text-cyan-400 uppercase tracking-widest">FINALS 2026 QUALIFIED</span>
                            </div>
                          )}
                          
                          <div className="flex gap-1.5">
                             {entry.badges.map((b, bi) => (
                               <span key={bi} className="text-lg filter drop-shadow-md">{b}</span>
                             ))}
                          </div>
                       </div>
                    </div>

                    {/* Metrics Panel - Challenge, Brady, Divisional */}
                    <div className="w-full xl:w-[540px] flex items-center justify-between bg-black/40 p-5 rounded-[2rem] border border-white/5 gap-6">
                        <div className="shrink-0 text-center px-4 border-r border-white/10">
                           <div className="flex items-center justify-center gap-2 mb-1">
                              <Zap className={`w-4 h-4 ${isFinalsQualified ? 'text-cyan-400' : 'text-blue-500'}`} />
                              <span className="text-3xl font-black italic text-white leading-none">{entry.total}</span>
                           </div>
                           <p className="text-[7px] font-black text-slate-600 uppercase tracking-widest">Total Rating</p>
                        </div>
                        
                        <div className="flex-1 grid grid-cols-3 gap-4 text-center">
                           <div className="space-y-1.5 group/item">
                              <p className="text-[7px] font-black text-slate-600 uppercase tracking-widest group-hover/item:text-yellow-500 transition-colors">Challenge</p>
                              <div className="flex items-center justify-center gap-1.5">
                                <Sword className="w-2.5 h-2.5 text-yellow-500/50" />
                                <span className="text-base font-black italic text-slate-300">{entry.playoffs}</span>
                              </div>
                           </div>
                           <div className="space-y-1.5 group/item">
                              <p className="text-[7px] font-black text-slate-600 uppercase tracking-widest group-hover/item:text-blue-400 transition-colors">Brady</p>
                              <div className="flex items-center justify-center gap-1.5">
                                <Shield className="w-2.5 h-2.5 text-blue-500/50" />
                                <span className="text-base font-black italic text-slate-300">{entry.brady}</span>
                              </div>
                           </div>
                           <div className="space-y-1.5 group/item">
                              <p className="text-[7px] font-black text-slate-600 uppercase tracking-widest group-hover/item:text-cyan-400 transition-colors">Divisional</p>
                              <div className="flex items-center justify-center gap-1.5">
                                <Layers className="w-2.5 h-2.5 text-cyan-500/50" />
                                <span className="text-base font-black italic text-slate-300">{entry.divisional}</span>
                              </div>
                           </div>
                        </div>

                        <div className="shrink-0 text-right px-4 border-l border-white/10">
                           <p className="text-xl font-mono font-black text-slate-400 leading-none">{entry.pf.toFixed(1)}</p>
                           <p className="text-[7px] font-black text-slate-600 uppercase tracking-widest mt-1">League PF</p>
                        </div>
                    </div>

                    <div className={`shrink-0 flex items-center justify-center p-3 rounded-2xl transition-all ${
                      isFinalsQualified ? 'bg-cyan-500/10 text-cyan-400' : 'bg-white/5 text-slate-700 group-hover:bg-blue-500 group-hover:text-black'
                    }`}>
                       <ArrowUpRight className="w-5 h-5" />
                    </div>
                 </div>
               );
             })}
          </div>
        </section>

        {/* Empty State */}
        {filteredRanking.length === 0 && (
          <div className="text-center py-56 bg-[#0a0c14] rounded-[5rem] border border-dashed border-white/10 space-y-8 animate-in zoom-in duration-500">
             <div className="w-24 h-24 rounded-full bg-slate-900 border-2 border-white/5 flex items-center justify-center mx-auto shadow-3xl">
                <Target className="w-16 h-16 text-slate-700 animate-pulse" />
             </div>
             <div className="space-y-3">
                <h3 className="text-3xl font-black text-white uppercase italic tracking-tighter">Search Null</h3>
                <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">Manager "{searchTerm}" not located.</p>
             </div>
             <button 
                onClick={() => setSearchTerm('')} 
                className="px-12 py-5 bg-blue-600 hover:bg-blue-500 text-white font-black uppercase tracking-[0.2em] text-xs rounded-3xl transition-all active:scale-95"
              >
                Reset Hub
              </button>
          </div>
        )}
      </main>

      <footer className="py-12 border-t border-white/5 text-center">
        <p className="text-[10px] font-black text-slate-700 uppercase tracking-[0.5em]">FWL Global Integrity Protocol • Hub v3.0 • Live Sync Enabled</p>
      </footer>
    </div>
  );
};

export default GlobalRanking2025;