
import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { fetchLeagueData, fetchMatchupsForWeek, getAvatarUrl } from '../services/sleeper';
import { FWL_LEAGUES } from '../App';
import { 
  ArrowLeft, 
  Search, 
  RefreshCw, 
  Clock, 
  Zap, 
  Users,
  TrendingUp
} from 'lucide-react';

interface RankingRegularPageProps {
  onBack: () => void;
}

interface UserStats {
  username: string;
  displayName: string;
  teamName: string;
  avatar: string | null;
  bradyWins: number;
  bradyPF: number;
  divWins: number;
  divPF: number;
  totalWins: number;
  totalPF: number;
}

const MANUAL_USER_EXCEPTIONS: Record<string, string> = {
  "old no. 7th round": "josuebrazil",
  "old no. 7th round picks": "josuebrazil",
  "respiração touchdown": "Tomchdown",
  "tre white goalie": "hellison99",
  "tre white goalie academy": "hellison99",
  "exit light!": "NeltonLopes",
  "exit light, enter night!": "NeltonLopes",
  "underdog": "PinhaisUnderdogs",
  "golden tate war.": "Canoleira",
  "golden tate warriors": "Canoleira",
  "camaragibe rep.": "PedroLuz07",
  "camaragibe republicans": "PedroLuz07",
  "colossal": "Lp_nfl",
  "vader's": "Vader",
  "eaglesabs": "EaglesABS",
  "samurais olhos": "B3TO",
  "samurais olhos azuis": "B3TO",
  "samurais de olhos azuis": "B3TO",
  "twerkzone": "Reagetime2",
  "vaifogo": "Fogonabombaaaa",
  "russell wilson": "HawkDestro",
  "brazil colts": "matigianini",
  "brazilian colts": "matigianini"
};

const wait = (ms: number) => new Promise(res => setTimeout(res, ms));

const RankingRegularPage: React.FC<RankingRegularPageProps> = ({ onBack }) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('Iniciando Crawler...');
  const [isRetrying, setIsRetrying] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [fetchedStats, setFetchedStats] = useState<Record<string, UserStats>>({});

  const fetchWithRetry = async <T extends unknown>(fn: () => Promise<T>, label: string): Promise<T> => {
    let attempts = 0;
    while (true) {
      try {
        const result = await fn();
        if (isRetrying) setIsRetrying(false);
        return result;
      } catch (e: any) {
        attempts++;
        setIsRetrying(true);
        const delayTime = e?.status === 429 ? 30000 : Math.min(2000 * Math.pow(2, attempts), 60000);
        setStatusText(`Rate Limit Sleeper: Aguardando ${delayTime / 1000}s...`);
        await wait(delayTime);
      }
    }
  };

  const crawlData = useCallback(async () => {
    setLoading(true);
    const stats: Record<string, UserStats> = {};
    
    try {
      for (let i = 0; i < FWL_LEAGUES.length; i++) {
        const leagueRef = FWL_LEAGUES[i];
        setProgress(Math.round(((i + 1) / FWL_LEAGUES.length) * 100));
        setStatusText(`Lendo: ${leagueRef.name}`);

        const { rosters, users } = await fetchWithRetry(() => fetchLeagueData(leagueRef.id), leagueRef.name);
        const isBrady = leagueRef.type === 'brady';

        const leagueWins: Record<number, number> = {};
        const leaguePF: Record<number, number> = {};

        if (isBrady) {
          for (let w = 1; w <= 11; w++) {
            const matchups = await fetchWithRetry(() => fetchMatchupsForWeek(leagueRef.id, w), `W${w} Brady`);
            const paired: Record<number, any[]> = {};
            matchups.forEach(m => {
              if (!paired[m.matchup_id]) paired[m.matchup_id] = [];
              paired[m.matchup_id].push(m);
              leaguePF[m.roster_id] = (leaguePF[m.roster_id] || 0) + m.points;
            });
            Object.values(paired).forEach(pair => {
              if (pair.length === 2) {
                const [t1, t2] = pair;
                if (t1.points > t2.points) leagueWins[t1.roster_id] = (leagueWins[t1.roster_id] || 0) + 1;
                else if (t2.points > t1.points) leagueWins[t2.roster_id] = (leagueWins[t2.roster_id] || 0) + 1;
              }
            });
          }
        } else {
          rosters.forEach(r => {
            leagueWins[r.roster_id] = r.settings.wins;
            leaguePF[r.roster_id] = r.settings.fpts + (r.settings.fpts_decimal / 100);
          });
        }

        rosters.forEach(r => {
          const user = users.find(u => u.user_id === r.owner_id);
          if (user) {
            let usernameKey = user.display_name.toLowerCase().trim();
            
            // Correção manual se o username do Sleeper for diferente do que temos no sistema
            if (MANUAL_USER_EXCEPTIONS[usernameKey]) {
                usernameKey = MANUAL_USER_EXCEPTIONS[usernameKey].toLowerCase().trim();
            }

            if (!stats[usernameKey]) {
              stats[usernameKey] = {
                username: user.display_name, displayName: user.display_name,
                teamName: user.metadata?.team_name || "Sem Nome",
                avatar: user.avatar, bradyWins: 0, bradyPF: 0,
                divWins: 0, divPF: 0, totalWins: 0, totalPF: 0
              };
            }
            if (isBrady) {
              stats[usernameKey].bradyWins += (leagueWins[r.roster_id] || 0);
              stats[usernameKey].bradyPF += (leaguePF[r.roster_id] || 0);
            } else {
              stats[usernameKey].divWins += (leagueWins[r.roster_id] || 0);
              stats[usernameKey].divPF += (leaguePF[r.roster_id] || 0);
            }
            stats[usernameKey].totalWins = stats[usernameKey].bradyWins + stats[usernameKey].divWins;
            stats[usernameKey].totalPF = stats[usernameKey].bradyPF + stats[usernameKey].divPF;
            if (user.metadata?.team_name) stats[usernameKey].teamName = user.metadata.team_name;
          }
        });
        await wait(50);
      }
      setFetchedStats(stats);
    } catch (err) { 
      console.error(err); 
    } finally { 
      setLoading(false); 
    }
  }, []);

  useEffect(() => { crawlData(); }, [crawlData]);

  const ranking = useMemo(() => {
    return Object.values(fetchedStats)
      .filter((u: UserStats) => 
        u.username.toLowerCase().includes(searchTerm.toLowerCase()) || 
        u.teamName.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .sort((a: UserStats, b: UserStats) => b.totalWins !== a.totalWins ? b.totalWins - a.totalWins : b.totalPF - a.totalPF);
  }, [fetchedStats, searchTerm]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8 p-6">
        <div className="relative">
          {isRetrying ? <Clock className="w-16 h-16 text-yellow-500 animate-pulse" /> : <RefreshCw className="w-16 h-16 text-blue-500 animate-spin" />}
          <div className="absolute inset-0 bg-blue-500/20 blur-2xl rounded-full"></div>
        </div>
        <div className="text-center space-y-4 max-w-sm">
          <h2 className="text-white font-black text-2xl uppercase italic tracking-widest">{isRetrying ? 'Rate Limit Hit' : 'Compilando 252 Managers'}</h2>
          <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/10">
            <div className="h-full bg-blue-500 transition-all duration-300 shadow-[0_0_10px_rgba(59,130,246,0.5)]" style={{ width: `${progress}%` }}></div>
          </div>
          <p className="text-[10px] font-bold uppercase text-slate-500 tracking-[0.2em]">{statusText}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex items-center justify-between sticky top-0 bg-[#0a0f1d]/90 backdrop-blur-xl p-4 -m-4 z-50 border-b border-white/5">
        <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
          <span className="text-[10px] font-black uppercase tracking-widest">Voltar</span>
        </button>
        <div className="text-right">
          <h2 className="text-xl font-black text-white italic uppercase tracking-tighter leading-none">Temporada Regular</h2>
          <p className="text-[9px] font-bold text-blue-500 uppercase tracking-widest">Global Standings (252 Managers)</p>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input 
          type="text" placeholder="Buscar por Manager ou Time..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white/5 border border-white/10 rounded-full pl-14 pr-6 py-4 text-sm focus:border-blue-500 outline-none transition-all"
        />
      </div>

      <div className="bg-[#1e293b]/20 border border-white/5 rounded-[2.5rem] overflow-hidden shadow-2xl">
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-white/5 border-b border-white/5">
                <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase w-16 text-center">#</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-500 uppercase">Manager & Time</th>
                <th className="px-4 py-5 text-[10px] font-black text-yellow-500 uppercase text-center bg-yellow-500/5">Brady Bowl</th>
                <th className="px-4 py-5 text-[10px] font-black text-blue-500 uppercase text-center bg-blue-500/5">Divisionais</th>
                <th className="px-6 py-5 text-[10px] font-black text-white uppercase text-right">Total Wins / PF</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {ranking.map((u, idx) => (
                <tr key={u.username} className="hover:bg-blue-500/5 transition-colors group">
                  <td className="px-6 py-5 font-black text-slate-600 text-center">{idx + 1}</td>
                  <td className="px-4 py-5">
                    <div className="flex items-center gap-3">
                      <img src={getAvatarUrl(u.avatar)} className="w-9 h-9 rounded-full border border-slate-800" alt="" />
                      <div className="flex flex-col min-w-0">
                        <span className="text-sm font-bold text-white leading-tight truncate">{u.displayName}</span>
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-tighter italic truncate">{u.teamName}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-5 text-center bg-yellow-500/5 text-xs font-black text-yellow-500">
                    {u.bradyWins}W
                  </td>
                  <td className="px-4 py-5 text-center bg-blue-500/5 text-xs font-black text-blue-400">
                    {u.divWins}W
                  </td>
                  <td className="px-6 py-5 text-right font-black">
                    <div className="text-lg text-white leading-none mb-1">{u.totalWins}W</div>
                    <div className="text-[10px] text-slate-500">{u.totalPF.toFixed(1)} PF</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RankingRegularPage;
