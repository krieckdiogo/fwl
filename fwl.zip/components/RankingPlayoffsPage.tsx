
import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { fetchLeagueData, getAvatarUrl } from '../services/sleeper';
import { FWL_LEAGUES } from '../App';
import { User } from '../types';
import { 
  ArrowLeft, 
  Search, 
  Trophy, 
  RefreshCw,
  Clock,
  Medal,
  Award
} from 'lucide-react';

interface RankingPlayoffsPageProps {
  onBack: () => void;
}

const POINTS_PER_ROUND_WIN: Record<number, number> = {
  1: 20, 2: 30, 3: 40, 4: 50, 5: 60, 6: 70, 7: 80
};

const PODIUM_BONUS = {
  CHAMPION: 500,
  VICE: 300,
  THIRD: 200
};

const TEAM_TO_USER_MAP: Record<string, string> = {
  "American Bulldogs": "Igwells",
  "Hijos de Rivers": "Passarelli80",
  "HeidlonG": "HeidlonG",
  "Rictus FC": "AmaraLynch",
  "Butt Fumble": "srpinguim",
  "volnandy": "volnandy",
  "Flessakianos": "flessak",
  "Coutinho15": "Coutinho15",
  "Texão da Massa": "RafaMartineli",
  "DGlad": "DGlad",
  "Inno9": "Inno9",
  "Green frogs": "Greenfrogs",
  "jetro50": "jetro50",
  "DeflateKing": "DeflateKing",
  "Claudianosilva": "Claudianosilva",
  "SaloMAYE": "thiagosalomao",
  "Real Garruchos F.C": "RealGarruchos",
  "Lunatkicks": "Krieck",
  "AugustoFuente": "AugustoFuente",
  "pedrotti": "pedrotti",
  "ライオンズ": "Akiradodo",
  "Borgo Hawks": "ivanborgo",
  "Explosion Raiders": "ExplosionRaiders",
  "“MaHomies”": "MaHomies",
  "Sporting Braunschweig": "SportingBraunschweig",
  "Brazuka Cheesers": "BrazukaCheesers",
  "EULLER_MATOS": "EULLER_MATOS",
  "Kobawsk": "Kobawsk",
  "crflicao": "crflicao",
  "MTosti": "MTosti",
  "saylentbob": "saylentbob",
  "Gumagol971": "Gumagol971",
  "OCITELHTA VENTANIA": "OCITELHTA",
  "Sirigaita": "Sirigaita",
  "Denver Donkeys": "DenverDonkeys",
  "FC Chucruts": "FCChucruts",
  "Black Bulls": "BlackBulls",
  "vagnercf": "vagnercf",
  "KFC Kings": "KFCKings",
  "beu128": "beu128",
  "VoliBEARS": "VoliBEARS",
  "Angeloni99": "Angeloni99",
  "Viúvo do Brady": "ViuvoDoBrady",
  "Old No. 7th Round Picks": "josuebrazil",
  "Viuvo do Baker": "ViuvoDoBaker",
  "Verdigris Calamities": "Verdigris",
  "NathanLuccas22": "NathanLuccas22",
  "Melca7": "Melca7",
  "Felipesimoes": "Felipesimoes",
  "FalcaoReal": "FalcaoReal",
  "GMJohnWick": "GMJohnWick",
  "vilsonm": "vilsonm",
  "BrHorse": "BrHorse",
  "WillPro": "WillPro",
  "Los llamas": "LosLlamas",
  "Seahawks LC": "SeahawksLC",
  "Green Bay Diamonds": "GBDiamonds",
  "Love Thy Nabers": "LoveThyNabers",
  "frostzx": "frostzx",
  "BernardoMachado": "BernardoMachado",
  "FlaFalcons": "FlaFalcons",
  "mathiascblc": "mathiascblc",
  "joaosandin": "joaosandin",
  "Eduardocfilho": "Eduardocfilho",
  "RESPIRAÇÃO TOUCHDOWN": "Tomchdown",
  "Exit light, enter night!": "NeltonLopes",
  "SaintsJP": "SaintsJP",
  "Eduhenri": "Eduhenri",
  "Blumenau 49ers": "Blumenau49ers",
  "GaloMG": "GaloMG",
  "NegoNey": "NegoNey",
  "MateusThomazini": "Thomazini",
  "BroncosBr": "BroncosBr",
  "Àlumani": "Alumani",
  "darcklauser": "darcklauser",
  "VV NIX": "VVNIX",
  "RegisCarrara": "RegisCarrara",
  "Last but not least": "LastButNotLeast",
  "FelipeFelix": "FelipeFelix",
  "Mamutes do Cerrado": "Mamutes",
  "wladspfc": "wladspfc",
  "migliorinisa": "migliorinisa",
  "Marigoat": "Marigoat",
  "Cyber Rats": "CyberRats",
  "joaomoherdaui": "joaomoherdaui",
  "chicopika": "chicopika",
  "KauEdelman11": "KauEdelman11",
  "Blitz do Chama": "BlitzChama",
  "Rio Docs": "RioDocs",
  "Chases da depressão": "ChasesDepre",
  "xanlost": "xanlost",
  "Montanha13": "Montanha13",
  "AnJuFire": "AnJuFire",
  "ManualNFLruim": "ManualNFL",
  "Pequi Smashers": "Pequi",
  "Redskins RS": "RedskinsRS",
  "Underdog": "PinhaisUnderdogs",
  "Kaepernick squad": "Kaepernick",
  "Campinas Broncos": "CampinasBroncos",
  "SiaraBigheads": "SiaraBigheads",
  "Golden Tate Warriors": "Canoleira",
  "JordanLoveMyLove10": "JordanLove",
  "21 Fighters": "21Fighters",
  "Gustavao": "Gustavao",
  "Zorzella": "Zorzella",
  "AaronFavre": "AaronFavre",
  "Leobala": "Leobala",
  "MorandiHawks": "Morandi",
  "Reds disfarçados": "RedsDisfarcados",
  "DanPini": "DanPini",
  "salsichatony": "salsichatony",
  "Mundstock": "Mundstock",
  "Direful Teachers": "Direful",
  "COLOSSAL": "Yuriidjsantos",
  "Camaragibe Republicans": "PedroLuz07",
  "rapharegueira": "rapharegueira",
  "Capivaras Espaciais": "Capivaras",
  "Nascimentimao": "Nascimentimao",
  "vitor9": "vitor9",
  "BLACK SAILS 66": "BlackSails",
  "Vader's": "Vader",
  "Broncos 2k25": "Broncos2k25",
  "Isaque49er": "Isaque49er",
  "JoaoNascimento": "JoaoNascimento",
  "FELIPERAMS": "FELIPERAMS",
  "nY eRs": "nYers",
  "Ué": "Ue",
  "Meia Boca Juniors": "MeiaBoca",
  "LeandroGaucho": "LeandroGaucho",
  "Carcarás do Cerrado": "Carcaras",
  "BengaoDaMassa": "Bengao",
  "Feehfiz": "Feehfiz",
  "PinhaisUnderdogs": "PinhaisUnderdogs",
  "San Jose dos Fields": "SanJose",
  "WI Redentor": "WIRedentor",
  "Vulgo Malvadão": "VulgoMalvadao",
  "VCF_49ers": "VCF_49ers",
  "tvvsgc": "tvvsgc",
  "Henry’s Kingdom": "HenrysKingdom",
  "Gunpowder Crew": "Gunpowder",
  "GuiMartins": "GuiMartins",
  "TwerkZonE": "Reagetime2",
  "Matligas": "Matligas",
  "Savio87": "Savio87",
  "Tiago_Caldeira": "Caldeira",
  "Lutfi Lycans": "Lutfi",
  "Bragil": "Bragil",
  "Emerik": "Emerik",
  "LucasPFerreira": "LucasPFerreira",
  "GuiOrtiz": "GuiOrtiz",
  "Niteroi Giants": "NiteroiGiants",
  "LucasKP": "LucasKP",
  "Brasília Wolfs": "BrasiliaWolfs",
  "ThiagoW": "ThiagoW",
  "AndreBruz": "AndreBruz",
  "Allyson Eagles": "AllysonEagles",
  "Cerrado Tiger": "CerradoTiger",
  "Urubroncos FC": "Urubroncos",
  "Pittsburgh Stealers": "Stealers",
  "yasminfariadias": "yasmin",
  "VaiCurintia": "VaiCurintia",
  "Salimporto": "Salimporto",
  "VaiFogo": "Fogonabombaaaa",
  "Fogonabombaaaa": "Fogonabombaaaa",
  "Lima Schulka": "Schulka",
  "Giants Suzano": "Suzano",
  "Gildarte": "Gildarte",
  "Blitzburgh": "Blitzburgh",
  "RafaelKoehler": "RafaelKoehler",
  "Terê Bone\'s": "TereBones",
  "JoaoElGringo": "JoaoElGringo",
  "jperocco": "jperocco",
  "helton": "helton",
  "AndreLimas": "AndreLimas",
  "NO Saints": "NOSaints",
  "Marau Bitu": "andreseara",
  "PatsMan": "PatsMan",
  "SipansBr": "SipansBr",
  "Russell Wilson": "HawkDestro",
  "AlisonBecker": "AlisonBecker",
  "narutoeagles": "narutoeagles",
  "Maringá Fans": "igorfan",
  "Quack Attack": "QuackAttack",
  "Packão da Massa": "Packao",
  "ACosta13": "ACosta13",
  "AleZucco": "AleZucco",
  "Love Hurts": "LoveHurts",
  "Corvos Caolhos": "CorvosCaolhos",
  "RodrigoAlane": "RodrigoAlane",
  "Island Kubricks": "IslandKubricks",
  "Carneiros Felpudos": "Carneiros",
  "POA Klingons": "POAKlingons",
  "MBC Bees": "MBCBees",
  "Lesio9ers": "dennisamorim",
  "Capivara Patriota": "CapivaraPatriota",
  "GlockPurdy": "GlockPurdy",
  "Coltsquest": "Coltsquest",
  "Joaoramalho Bandits": "Bandits",
  "North East Harpy": "davilimmah",
  "ZekMVP2022": "ZekMVP",
  "Prezzanfl": "Prezzanfl",
  "Planet Hampton": "MarcoMiranda05",
  "Game of Mahomes": "GameOfMahomes",
  "Favela Fangs": "FavelaFangs",
  "Samurais olhos": "B3TO",
  "Samurais olhos Azuis": "B3TO",
  "Samurais de olhos Azuis": "B3TO",
  "bielvicente": "bielvicente",
  "dariocsilva": "dariocsilva",
  "osmar": "osmar",
  "ThomasM3l00": "ThomasMelo",
  "EaglesABS": "EaglesABS",
  "FelipePatriots": "FelipePatriots",
  "How Metcalf Mother": "HowMetcalf",
  "Browns Porto": "BrownsPorto",
  "Mesquita1983": "Mesquita1983",
  "Green Bay Lakers": "GBLakers",
  "JoaoP97": "JoaoP97",
  "DS Valhalla": "DSValhalla",
  "CWB Empacotadores": "CWBEmpacotadores",
  "LeandroNS": "LeandroNS",
  "Nega Jurema Renegades": "NegaJurema",
  "BKW West Coast": "BKW",
  "In AR we trust": "ViniB",
  "Diogoashura": "Diogoashura",
  "Lambeaughini": "Lambeaughini",
  "Mestre do Fantasy": "MestreFantasy",
  "Deflategreats FC": "Deflategreats",
  "GabrielSimioni": "Simioni",
  "Santástico da NFL": "markinhosfc11",
  "marcobortolotto": "marcobortolotto",
  "MAGRELÃO BLUEDOGS": "Magrelao",
  "pipito": "pipito",
  "Porto Alegre Immortals": "Immortals",
  "Ghost of Soteropolis": "Rui",
  "rafaelroxxa": "rafaelroxxa",
  "Brazil Colts": "matigianini"
};

const wait = (ms: number) => new Promise(res => setTimeout(res, ms));

const RankingPlayoffsPage: React.FC<RankingPlayoffsPageProps> = ({ onBack }) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [isRetrying, setIsRetrying] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [allUsers, setAllUsers] = useState<Record<string, { displayName: string, avatar: string | null }>>({});

  const fetchWithRetry = async <T extends unknown>(fn: () => Promise<T>): Promise<T> => {
    let attempts = 0;
    while (true) {
      try {
        const result = await fn();
        if (isRetrying) setIsRetrying(false);
        return result;
      } catch (e: any) {
        attempts++;
        setIsRetrying(true);
        const delayTime = e?.status === 429 ? 30000 : 2000;
        await wait(delayTime);
      }
    }
  };

  const loadAllUsers = useCallback(async () => {
    setLoading(true);
    const usersMap: Record<string, { displayName: string, avatar: string | null }> = {};
    try {
      for (let i = 0; i < FWL_LEAGUES.length; i++) {
        const league = FWL_LEAGUES[i];
        setProgress(Math.round(((i + 1) / FWL_LEAGUES.length) * 100));
        const data = (await fetchWithRetry(() => fetchLeagueData(league.id))) as any;
        data.users.forEach((u: any) => {
          const key = u.display_name.toLowerCase().trim();
          if (!usersMap[key]) {
            usersMap[key] = { displayName: u.display_name, avatar: u.avatar };
          }
        });
      }
      setAllUsers(usersMap);
    } catch (err) { console.error(err); } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAllUsers(); }, [loadAllUsers]);

  const ranking = useMemo(() => {
    const scores: Record<string, any> = {};
    (Object.entries(allUsers) as [string, { displayName: string, avatar: string | null }][]).forEach(([key, u]) => {
      scores[key] = { 
        username: u.displayName, 
        team: "Não Classificado", 
        points: 0, 
        wins: 0, 
        pf: 0, 
        avatar: u.avatar,
        achievements: [] 
      };
    });

    [1, 2, 3, 4, 5, 6, 7].forEach(roundNum => {
      const roundMatches = STATIC_BRACKET_DATA[roundNum] || [];
      const ptsWin = POINTS_PER_ROUND_WIN[roundNum] || 0;
      roundMatches.forEach(m => {
        [m.t1, m.t2].forEach((team) => {
          const mappedUser = TEAM_TO_USER_MAP[team.name] || team.name;
          const key = mappedUser.toLowerCase().trim();
          if (scores[key]) {
            scores[key].team = team.name;
            scores[key].pf += team.score;
          }
        });
        const winnerUser = TEAM_TO_USER_MAP[m.winnerName] || m.winnerName;
        const wKey = winnerUser.toLowerCase().trim();
        if (scores[wKey]) {
          scores[wKey].points += ptsWin;
          scores[wKey].wins += 1;
        }
      });
    });

    const bronzeMatch = STATIC_BRACKET_DATA[8]?.[0];
    if (bronzeMatch) {
      const bronzeWinner = TEAM_TO_USER_MAP[bronzeMatch.winnerName] || bronzeMatch.winnerName;
      const bKey = bronzeWinner.toLowerCase().trim();
      if (scores[bKey]) {
        scores[bKey].points += PODIUM_BONUS.THIRD;
        scores[bKey].achievements.push("3º LUGAR CHALLENGE");
      }
    }

    const gfMatch = STATIC_BRACKET_DATA[9]?.[0];
    if (gfMatch) {
      const winnerName = gfMatch.winnerName;
      const loserName = gfMatch.t1.name === winnerName ? gfMatch.t2.name : gfMatch.t1.name;
      const winnerKey = (TEAM_TO_USER_MAP[winnerName] || winnerName).toLowerCase().trim();
      const loserKey = (TEAM_TO_USER_MAP[loserName] || loserName).toLowerCase().trim();
      if (scores[winnerKey]) {
        scores[winnerKey].points += PODIUM_BONUS.CHAMPION;
        scores[winnerKey].achievements.push("CAMPEÃO CHALLENGE");
      }
      if (scores[loserKey]) {
        scores[loserKey].points += PODIUM_BONUS.VICE;
        scores[loserKey].achievements.push("VICE-CAMPEÃO CHALLENGE");
      }
    }

    return Object.values(scores)
      .filter((u: any) => u.username.toLowerCase().includes(searchTerm.toLowerCase()))
      .sort((a: any, b: any) => {
        if (b.points !== a.points) return b.points - a.points;
        return b.pf - a.pf;
      });
  }, [allUsers, searchTerm]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8 p-6">
        <div className="relative">
          {isRetrying ? <Clock className="w-16 h-16 text-yellow-500 animate-pulse" /> : <RefreshCw className="w-16 h-16 text-blue-500 animate-spin" />}
          <div className="absolute inset-0 bg-blue-500/20 blur-2xl rounded-full"></div>
        </div>
        <div className="text-center space-y-4 max-w-sm">
          <h2 className="text-white font-black text-2xl uppercase italic tracking-widest">Calculando Playoffs</h2>
          <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/10">
            <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${progress}%` }}></div>
          </div>
          <p className="text-[10px] font-bold uppercase text-slate-500 tracking-[0.2em]">Aplicando Regulamento: Rounds 1 a 7 + Bônus</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex items-center justify-between sticky top-0 bg-[#0a0f1d]/90 backdrop-blur-xl p-4 -m-4 z-50 border-b border-white/5">
        <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
          <span className="text-[10px] font-black uppercase tracking-widest">Voltar</span>
        </button>
        <div className="text-right">
          <h2 className="text-xl font-black text-white italic uppercase tracking-tighter leading-none">Playoffs Challenge</h2>
          <p className="text-[9px] font-bold text-yellow-500 uppercase tracking-widest">Ranking Unificado por Rodada</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white/5 border border-white/10 p-4 rounded-2xl">
          <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Ponto por Vitória</p>
          <p className="text-xs font-bold text-white">R1: 20 • R2: 30 • R3: 40 • R4: 50 • R5: 60 • QF: 70 • SF: 80</p>
        </div>
        <div className="bg-yellow-500/5 border border-yellow-500/20 p-4 rounded-2xl">
          <p className="text-[8px] font-black text-yellow-500/60 uppercase tracking-widest mb-1">Bônus de Pódio</p>
          <p className="text-xs font-bold text-yellow-500">1º: 500 • 2º: 300 • 3º: 200</p>
        </div>
        <div className="bg-blue-500/5 border border-blue-500/20 p-4 rounded-2xl flex items-center justify-between">
           <div>
             <p className="text-[8px] font-black text-blue-400 uppercase tracking-widest mb-1">Desempate</p>
             <p className="text-xs font-bold text-white">Total PF nos Playoffs</p>
           </div>
           <Award className="w-6 h-6 text-blue-500" />
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input 
          type="text" placeholder="Buscar por Manager..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white/5 border border-white/10 rounded-full pl-14 pr-6 py-4 text-sm focus:border-blue-500 outline-none transition-all"
        />
      </div>

      <div className="bg-[#1e293b]/20 border border-white/5 rounded-[2.5rem] overflow-hidden shadow-2xl">
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-white/5 border-b border-white/5">
                <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase w-16 text-center">#</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-500 uppercase">Manager & Time</th>
                <th className="px-4 py-5 text-[10px] font-black text-blue-400 uppercase text-center bg-blue-500/5">Vitórias</th>
                <th className="px-4 py-5 text-[10px] font-black text-slate-500 uppercase text-center">Playoff PF</th>
                <th className="px-6 py-5 text-[10px] font-black text-white uppercase text-right">Pts Ranking</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {ranking.map((u: any, idx: number) => {
                const isTop3 = idx < 3;
                return (
                  <tr key={u.username} className={`hover:bg-yellow-500/5 transition-colors group ${isTop3 ? 'bg-yellow-500/[0.02]' : ''}`}>
                    <td className="px-6 py-5 font-black text-slate-600 text-center">
                      {idx === 0 ? <Trophy className="w-4 h-4 text-yellow-500 mx-auto" /> : idx + 1}
                    </td>
                    <td className="px-4 py-5">
                      <div className="flex items-center gap-3">
                        <img src={getAvatarUrl(u.avatar)} className={`w-10 h-10 rounded-full border-2 ${isTop3 ? 'border-yellow-500' : 'border-slate-800'}`} alt="" />
                        <div className="flex flex-col min-w-0">
                          <span className="text-sm font-bold text-white truncate leading-tight">{u.username}</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            <span className="text-[9px] font-black text-slate-500 uppercase tracking-tighter italic truncate max-w-[120px]">{u.team}</span>
                            {u.achievements.map((a: string, ai: number) => (
                              <span key={ai} className="px-1.5 py-0.5 bg-yellow-500/10 text-yellow-500 text-[7px] font-black rounded uppercase flex items-center gap-1">
                                <Award className="w-2 h-2" /> {a}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-5 text-center bg-blue-500/5 text-xs font-black text-blue-400">{u.wins}W</td>
                    <td className="px-4 py-5 text-center text-[10px] font-mono text-slate-500">{u.pf.toFixed(2)}</td>
                    <td className="px-6 py-5 text-right font-black">
                      <div className={`text-xl ${isTop3 ? 'text-yellow-500' : 'text-white'}`}>{u.points} pts</div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// DADOS ESTÁTICOS INTEGRADOS PARA CÁLCULO DE RANKING
const STATIC_BRACKET_DATA: Record<number, any[]> = {
  1: [
    { name: 'DGlad', score: 120.52, winnerName: 'DGlad', t1: { name: 'DGlad', score: 120.52 }, t2: { name: 'Brazuka Cheesers', score: 117.34 } },
    { name: 'Inno9', score: 125.30, winnerName: 'Inno9', t1: { name: 'Inno9', score: 125.30 }, t2: { name: 'EULLER_MATOS', score: 41.34 } },
    { name: 'Green frogs', score: 112.80, winnerName: 'Green frogs', t1: { name: 'Green frogs', score: 112.80 }, t2: { name: 'AugustoFuente', score: 102.18 } },
    { name: 'Kobawsk', score: 95.18, winnerName: 'Kobawsk', t1: { name: 'LiaraFP', score: 90.52 }, t2: { name: 'Kobawsk', score: 95.18 } },
    { name: 'Lunatkicks', score: 110.44, winnerName: 'Lunatkicks', t1: { name: 'Lunatkicks', score: 110.44 }, t2: { name: 'crflicao', score: 104.18 } },
    { name: 'Real Garruchos F.C', score: 102.70, winnerName: 'Real Garruchos F.C', t1: { name: 'Real Garruchos F.C', score: 102.70 }, t2: { name: 'MTosti', score: 79.60 } },
    { name: 'jetro50', score: 105.88, winnerName: 'jetro50', t1: { name: 'jetro50', score: 105.88 }, t2: { name: 'saylentbob', score: 84.24 } },
    { name: 'DeflateKing', score: 101.38, winnerName: 'DeflateKing', t1: { name: 'DeflateKing', score: 101.38 }, t2: { name: 'Gumagol971', score: 94.80 } },
    { name: 'Leitinho Dolphins', score: 138.80, winnerName: 'Leitinho Dolphins', t1: { name: 'Leitinho Dolphins', score: 138.80 }, t2: { name: 'OCITELHTA VENTANIA', score: 94.20 } },
    { name: 'Sirigaita', score: 115.86, winnerName: 'Sirigaita', t1: { name: 'Sirigaita', score: 115.86 }, t2: { name: 'SOAD', score: 87.74 } },
    { name: 'Denver Donkeys', score: 106.44, winnerName: 'Denver Donkeys', t1: { name: 'Denver Donkeys', score: 106.44 }, t2: { name: 'FabricioCunha', score: 103.00 } },
    { name: 'FC Chucruts', score: 126.54, winnerName: 'FC Chucruts', t1: { name: 'FC Chucruts', score: 126.54 }, t2: { name: 'diegohssg', score: 121.78 } },
    { name: 'ライオンズ', score: 145.76, winnerName: 'ライオンズ', t1: { name: 'ライオンズ', score: 145.76 }, t2: { name: 'Black Bulls', score: 97.94 } },
    { name: 'vagnercf', score: 107.30, winnerName: 'vagnercf', t1: { name: 'vagnercf', score: 107.30 }, t2: { name: 'Moita Team', score: 101.62 } },
    { name: 'KFC Kings', score: 130.84, winnerName: 'KFC Kings', t1: { name: 'KFC Kings', score: 130.84 }, t2: { name: 'GuiRezende', score: 116.40 } },
    { name: 'beu128', score: 101.64, winnerName: 'beu128', t1: { name: 'beu128', score: 101.64 }, t2: { name: 'VoliBEARS', score: 88.88 } },
    { name: 'Angeloni99', score: 115.00, winnerName: 'Angeloni99', t1: { name: 'Angeloni99', score: 115.00 }, t2: { name: 'Tre White Goalie Academy', score: 82.02 } },
    { name: 'Viúvo do Brady', score: 152.58, winnerName: 'Viúvo do Brady', t1: { name: 'Viúvo do Brady', score: 152.58 }, t2: { name: 'Clemson Broncos', score: 130.60 } },
    { name: 'Old No. 7th Round Picks', score: 107.32, winnerName: 'Old No. 7th Round Picks', t1: { name: 'Old No. 7th Round Picks', score: 107.32 }, t2: { name: 'Viuvo do Baker', score: 92.90 } },
    { name: 'Verdigris Calamities', score: 116.18, winnerName: 'Verdigris Calamities', t1: { name: 'Verdigris Calamities', score: 116.18 }, t2: { name: 'NathanLuccas22', score: 88.54 } },
    { name: 'Melca7', score: 141.04, winnerName: 'Melca7', t1: { name: 'Melca7', score: 141.04 }, t2: { name: 'Felipesimoes', score: 124.40 } },
    { name: 'FalcaoReal', score: 113.52, winnerName: 'FalcaoReal', t1: { name: 'FalcaoReal', score: 113.52 }, t2: { name: 'GMJohnWick', score: 84.76 } },
    { name: 'vilsonm', score: 117.30, winnerName: 'vilsonm', t1: { name: 'vilsonm', score: 117.30 }, t2: { name: 'RodGianini', score: 106.00 } },
    { name: 'WillPro', score: 121.50, winnerName: 'WillPro', t1: { name: 'WillPro', score: 121.50 }, t2: { name: 'BrHorse', score: 88.66 } },
    { name: 'volnandy', score: 134.40, winnerName: 'volnandy', t1: { name: 'volnandy', score: 134.40 }, t2: { name: 'Los llamas', score: 128.70 } },
    { name: 'Green Bay Diamonds', score: 119.14, winnerName: 'Green Bay Diamonds', t1: { name: 'Green Bay Diamonds', score: 119.14 }, t2: { name: 'Seahawks LC', score: 102.48 } },
    { name: 'Love Thy Nabers', score: 150.94, winnerName: 'Love Thy Nabers', t1: { name: 'Love Thy Nabers', score: 150.94 }, t2: { name: 'cardosoo', score: 97.40 } },
    { name: 'frostzx', score: 155.60, winnerName: 'frostzx', t1: { name: 'frostzx', score: 155.60 }, t2: { name: 'BernardoMachado', score: 140.46 } },
    { name: 'FlaFalcons', score: 126.88, winnerName: 'FlaFalcons', t1: { name: 'FlaFalcons', score: 126.88 }, t2: { name: 'mathiascblc', score: 124.74 } },
    { name: 'Eduardocfilho', score: 90.68, winnerName: 'Eduardocfilho', t1: { name: 'Eduardocfilho', score: 90.68 }, t2: { name: 'joaosandin', score: 85.94 } },
    { name: 'RESPIRAÇÃO TOUCHDOWN', score: 144.00, winnerName: 'RESPIRAÇÃO TOUCHDOWN', t1: { name: 'RESPIRAÇÃO TOUCHDOWN', score: 144.00 }, t2: { name: 'Exit light, enter night!', score: 66.84 } },
    { name: 'SaintsJP', score: 130.34, winnerName: 'SaintsJP', t1: { name: 'SaintsJP', score: 130.34 }, t2: { name: 'Eduhenri', score: 113.24 } },
    { name: '“MaHomies”', score: 123.18, winnerName: '“MaHomies”', t1: { name: '“MaHomies”', score: 123.18 }, t2: { name: 'Blumenau 49ers', score: 108.70 } },
    { name: 'GaloMG', score: 116.34, winnerName: 'GaloMG', t1: { name: 'GaloMG', score: 116.34 }, t2: { name: 'NegoNey', score: 106.38 } },
    { name: 'MateusThomazini', score: 119.28, winnerName: 'MateusThomazini', t1: { name: 'MateusThomazini', score: 119.28 }, t2: { name: 'BroncosBr', score: 61.74 } },
    { name: 'Àlumani', score: 76.64, winnerName: 'Àlumani', t1: { name: 'Àlumani', score: 76.64 }, t2: { name: 'darcklauser', score: 74.40 } },
    { name: 'RegisCarrara', score: 126.30, winnerName: 'RegisCarrara', t1: { name: 'RegisCarrara', score: 126.30 }, t2: { name: 'VV NIX', score: 116.00 } },
    { name: 'Last but not least', score: 117.34, winnerName: 'Last but not least', t1: { name: 'Last but not least', score: 117.34 }, t2: { name: 'FelipeFelix', score: 114.74 } },
    { name: 'Mamutes do Cerrado', score: 122.20, winnerName: 'Mamutes do Cerrado', t1: { name: 'Mamutes do Cerrado', score: 122.20 }, t2: { name: 'wladspfc', score: 77.04 } },
    { name: 'migliorinisa', score: 123.80, winnerName: 'migliorinisa', t1: { name: 'migliorinisa', score: 123.80 }, t2: { name: 'Marigoat', score: 98.08 } },
    { name: 'Cyber Rats', score: 84.54, winnerName: 'Cyber Rats', t1: { name: 'Cyber Rats', score: 84.54 }, t2: { name: 'joaomoherdaui', score: 64.44 } },
    { name: 'KauEdelman11', score: 117.76, winnerName: 'KauEdelman11', t1: { name: 'KauEdelman11', score: 117.76 }, t2: { name: 'chicopika', score: 91.32 } },
    { name: 'Blitz do Chama', score: 145.20, winnerName: 'Blitz do Chama', t1: { name: 'Blitz do Chama', score: 145.20 }, t2: { name: 'Big D', score: 107.98 } },
    { name: 'W’69', score: 101.62, winnerName: 'W’69', t1: { name: 'W’69', score: 101.62 }, t2: { name: 'Rio Docs', score: 91.18 } },
    { name: 'Chases da depressão', score: 127.38, winnerName: 'Chases da depressão', t1: { name: 'Chases da depressão', score: 127.38 }, t2: { name: 'xanlost', score: 83.74 } },
    { name: 'Montanha13', score: 81.78, winnerName: 'Montanha13', t1: { name: 'Montanha13', score: 81.78 }, t2: { name: 'AnJuFire', score: 81.50 } },
    { name: 'ManualNFLruim', score: 106.64, winnerName: 'ManualNFLruim', t1: { name: 'ManualNFLruim', score: 106.64 }, t2: { name: 'Pequi Smashers', score: 84.22 } },
    { name: 'Redskins RS', score: 111.62, winnerName: 'Redskins RS', t1: { name: 'Redskins RS', score: 111.62 }, t2: { name: 'Underdog', score: 107.10 } },
    { name: 'Kaepernick squad', score: 143.48, winnerName: 'Kaepernick squad', t1: { name: 'Kaepernick squad', score: 143.48 }, t2: { name: 'Steeloso', score: 95.70 } },
    { name: 'Campinas Broncos', score: 123.50, winnerName: 'Campinas Broncos', t1: { name: 'Campinas Broncos', score: 123.50 }, t2: { name: 'Coutinho15', score: 106.30 } },
    { name: 'SiaraBigheads', score: 103.62, winnerName: 'SiaraBigheads', t1: { name: 'SiaraBigheads', score: 103.62 }, t2: { name: 'Golden Tate Warriors', score: 99.88 } },
    { name: '21 Fighters', score: 116.58, winnerName: '21 Fighters', t1: { name: '21 Fighters', score: 116.58 }, t2: { name: 'JordanLoveMyLove10', score: 105.92 } },
    { name: 'Zorzella', score: 117.48, winnerName: 'Zorzella', t1: { name: 'Zorzella', score: 117.48 }, t2: { name: 'Gustavao', score: 83.80 } },
    { name: 'AaronFavre', score: 127.04, winnerName: 'AaronFavre', t1: { name: 'AaronFavre', score: 127.04 }, t2: { name: 'Leobala', score: 99.84 } },
    { name: 'Reds disfarçados', score: 146.72, winnerName: 'Reds disfarçados', t1: { name: 'Reds disfarçados', score: 146.72 }, t2: { name: 'MorandiHawks', score: 115.40 } },
    { name: 'DanPini', score: 116.80, winnerName: 'DanPini', t1: { name: 'DanPini', score: 116.80 }, t2: { name: 'salsichatony', score: 92.78 } },
    { name: 'Mundstock', score: 116.28, winnerName: 'Mundstock', t1: { name: 'Mundstock', score: 116.28 }, t2: { name: 'PauloFerreira', score: 114.08 } },
    { name: 'Direful Teachers', score: 104.76, winnerName: 'Direful Teachers', t1: { name: 'Direful Teachers', score: 104.76 }, t2: { name: 'Isaque49er', score: 81.38 } },
    { name: 'Vader\'s', score: 81.76, winnerName: 'Vader\'s', t1: { name: 'Vader\'s', score: 81.76 }, t2: { name: 'Camaragibe Republicans', score: 80.08 } },
    { name: 'Capivaras Espaciais', score: 152.90, winnerName: 'Capivaras Espaciais', t1: { name: 'Capivaras Espaciais', score: 152.90 }, t2: { name: 'vitor9', score: 86.02 } },
    { name: 'vitor9', winnerName: 'vitor9', t1: { name: 'vitor9', score: 119.10 }, t2: { name: 'BLACK SAILS 66', score: 102.40 } },
    { name: 'Vader\'s', winnerName: 'Vader\'s', t1: { name: 'Vader\'s', score: 106.30 }, t2: { name: 'Broncos 2k25', score: 105.58 } },
    { name: 'Isaque49er', winnerName: 'Isaque49er', t1: { name: 'Isaque49er', score: 117.28 }, t2: { name: 'JoaoNascimento', score: 90.82 } },
    { name: 'FELIPERAMS', winnerName: 'FELIPERAMS', t1: { name: 'FELIPERAMS', score: 115.70 }, t2: { name: 'nY eRs', score: 76.02 } },
    { name: 'Ué', winnerName: 'Ué', t1: { name: 'Ué', score: 135.50 }, t2: { name: 'Meia Boca Juniors', score: 118.28 } },
    { name: 'LeandroGaucho', winnerName: 'LeandroGaucho', t1: { name: 'LeandroGaucho', score: 94.82 }, t2: { name: 'Carcarás do Cerrado', score: 78.34 } },
    { name: 'BengaoDaMassa', winnerName: 'BengaoDaMassa', t1: { name: 'BengaoDaMassa', score: 126.56 }, t2: { name: 'Feehfiz', score: 99.62 } },
    { name: 'PinhaisUnderdogs', winnerName: 'PinhaisUnderdogs', t1: { name: 'PinhaisUnderdogs', score: 120.60 }, t2: { name: 'San Jose dos Fields', score: 92.08 } },
    { name: 'Vulgo Malvadão', winnerName: 'Vulgo Malvadão', t1: { name: 'Vulgo Malvadão', score: 127.10 }, t2: { name: 'WI Redentor', score: 98.98 } },
    { name: 'VCF_49ers', winnerName: 'VCF_49ers', t1: { name: 'VCF_49ers', score: 97.64 }, t2: { name: 'tvvsgc', score: 66.54 } },
    { name: 'Henry’s Kingdom', winnerName: 'Henry’s Kingdom', t1: { name: 'Henry’s Kingdom', score: 108.10 }, t2: { name: 'Gunpowder Crew', score: 91.64 } },
    { name: 'TwerkZonE', winnerName: 'TwerkZonE', t1: { name: 'TwerkZonE', score: 90.52 }, t2: { name: 'GuiMartins', score: 89.68 } },
    { name: 'Savio87', winnerName: 'Savio87', t1: { name: 'Savio87', score: 124.10 }, t2: { name: 'Matligas', score: 120.90 } },
    { name: 'Lutfi Lycans', winnerName: 'Lutfi Lycans', t1: { name: 'Lutfi Lycans', score: 96.20 }, t2: { name: 'Tiago_Caldeira', score: 87.38 } },
    { name: 'Bragil', winnerName: 'Bragil', t1: { name: 'Bragil', score: 124.76 }, t2: { name: 'Emerik', score: 109.90 } },
    { name: 'LucasPFerreira', winnerName: 'LucasPFerreira', t1: { name: 'LucasPFerreira', score: 136.48 }, t2: { name: 'GuiOrtiz', score: 108.28 } },
    { name: 'LucasKP', winnerName: 'LucasKP', t1: { name: 'LucasKP', score: 104.14 }, t2: { name: 'Niteroi Giants', score: 84.70 } },
    { name: 'ThiagoW', winnerName: 'ThiagoW', t1: { name: 'ThiagoW', score: 107.28 }, t2: { name: 'Brasília Wolfs', score: 89.90 } },
    { name: 'AndreBruz', winnerName: 'AndreBruz', t1: { name: 'AndreBruz', score: 80.44 }, t2: { name: 'Allyson Eagles', score: 70.34 } },
    { name: 'Urubroncos FC', winnerName: 'Urubroncos FC', t1: { name: 'Urubroncos FC', score: 111.14 }, t2: { name: 'Cerrado Tiger', score: 98.44 } },
    { name: 'yasminfariadias', winnerName: 'yasminfariadias', t1: { name: 'yasminfariadias', score: 133.28 }, t2: { name: 'Pittsburgh Stealers', score: 87.08 } },
    { name: 'Flessakianos', winnerName: 'Flessakianos', t1: { name: 'Flessakianos', score: 107.14 }, t2: { name: 'VaiCurintia', score: 87.28 } },
    { name: 'Salimporto', winnerName: 'Salimporto', t1: { name: 'Salimporto', score: 117.34 }, t2: { name: 'Fogonabombaaaa', score: 84.54 } },
    { name: 'Rictus FC', winnerName: 'Rictus FC', t1: { name: 'Rictus FC', score: 141.64 }, t2: { name: 'Lima Schulka', score: 118.22 } },
    { name: 'Giants Suzano', winnerName: 'Giants Suzano', t1: { name: 'Giants Suzano', score: 102.48 }, t2: { name: 'Gildarte', score: 90.60 } },
    { name: 'Claudianosilva', winnerName: 'Claudianosilva', t1: { name: 'Claudianosilva', score: 146.38 }, t2: { name: 'Blitzburgh', score: 61.88 } },
    { name: 'RafaelKoehler', winnerName: 'RafaelKoehler', t1: { name: 'RafaelKoehler', score: 135.18 }, t2: { name: 'Terê Bone\'s', score: 116.30 } },
    { name: 'JoaoElGringo', winnerName: 'JoaoElGringo', t1: { name: 'JoaoElGringo', score: 115.30 }, t2: { name: 'jperocco', score: 104.90 } },
    { name: 'AndreLimas', winnerName: 'AndreLimas', t1: { name: 'AndreLimas', score: 113.06 }, t2: { name: 'helton', score: 91.20 } },
    { name: 'Marau Bitu', winnerName: 'andreseara', t1: { name: 'andreseara', score: 127.58 }, t2: { name: 'NO Saints', score: 91.72 } },
    { name: 'SipansBr', winnerName: 'SipansBr', t1: { name: 'SipansBr', score: 108.36 }, t2: { name: 'PatsMan', score: 88.90 } },
    { name: 'AlisonBecker', winnerName: 'AlisonBecker', t1: { name: 'AlisonBecker', score: 142.40 }, t2: { name: 'Russell Wilson', score: 92.88 } },
    { name: 'Maringá Fans', winnerName: 'igorfan', t1: { name: 'igorfan', score: 132.90 }, t2: { name: 'narutoeagles', score: 83.72 } },
    { name: 'Quack Attack', winnerName: 'Quack Attack', t1: { name: 'Quack Attack', score: 101.60 }, t2: { name: 'Packão da Massa', score: 100.18 } },
    { name: 'AleZucco', winnerName: 'AleZucco', t1: { name: 'AleZucco', score: 140.04 }, t2: { name: 'ACosta13', score: 77.78 } },
    { name: 'Brazilian Colts', winnerName: 'Brazilian Colts', t1: { name: 'Brazilian Colts', score: 103.20 }, t2: { name: 'Love Hurts', score: 94.74 } },
    { name: 'Corvos Caolhos', winnerName: 'Corvos Caolhos', t1: { name: 'Corvos Caolhos', score: 96.90 }, t2: { name: 'RodrigoAlane', score: 79.34 } },
    { name: 'Carneiros Felpudos', winnerName: 'Carneiros Felpudos', t1: { name: 'Carneiros Felpudos', score: 124.90 }, t2: { name: 'Island Kubricks', score: 77.90 } },
    { name: 'Hijos de Rivers', winnerName: 'Hijos de Rivers', t1: { name: 'Hijos de Rivers', score: 118.62 }, t2: { name: '49ersForever', score: 95.10 } },
    { name: 'POA Klingons', winnerName: 'POA Klingons', t1: { name: 'POA Klingons', score: 151.50 }, t2: { name: 'MBC Bees', score: 104.14 } },
    { name: 'Lesio9ers', winnerName: 'dennisamorim', t1: { name: 'dennisamorim', score: 115.86 }, t2: { name: 'Capivara Patriota', score: 114.34 } },
    { name: 'Coltsquest', winnerName: 'Coltsquest', t1: { name: 'Coltsquest', score: 113.26 }, t2: { name: 'GlockPurdy', score: 105.84 } },
    { name: 'Borgo Hawks', winnerName: 'Borgo Hawks', t1: { name: 'Borgo Hawks', score: 96.20 }, t2: { name: 'Joaoramalho Bandits', score: 92.94 } },
    { name: 'North East Harpy', winnerName: 'davilimmah', t1: { name: 'davilimmah', score: 103.42 }, t2: { name: 'ZekMVP2022', score: 97.78 } },
    { name: 'Planet Hampton', winnerName: 'MarcoMiranda05', t1: { name: 'MarcoMiranda05', score: 114.34 }, t2: { name: 'Prezzanfl', score: 99.04 } },
    { name: 'Texão da Massa', winnerName: 'Texão da Massa', t1: { name: 'Texão da Massa', score: 136.40 }, t2: { name: 'Game of Mahomes', score: 114.58 } },
    { name: 'Samurais de olhos Azuis', winnerName: 'Samurais de olhos Azuis', t1: { name: 'Samurais de olhos Azuis', score: 104.20 }, t2: { name: 'Favela Fangs', score: 98.34 } },
    { name: 'Sporting Braunschweig', winnerName: 'Sporting Braunschweig', t1: { name: 'Sporting Braunschweig', score: 107.62 }, t2: { name: 'bielvicente', score: 99.98 } },
    { name: 'osmar', winnerName: 'osmar', t1: { name: 'osmar', score: 105.48 }, t2: { name: 'dariocsilva', score: 91.38 } },
    { name: 'ThomasM3l00', winnerName: 'ThomasM3l00', t1: { name: 'ThomasM3l00', score: 114.80 }, t2: { name: 'EaglesABS', score: 86.74 } },
    { name: 'FelipePatriots', winnerName: 'FelipePatriots', t1: { name: 'FelipePatriots', score: 144.78 }, t2: { name: 'How I Metcalf Your Mother', score: 103.64 } },
    { name: 'SaloMAYE', winnerName: 'SaloMAYE', t1: { name: 'SaloMAYE', score: 115.30 }, t2: { name: 'Browns Porto', score: 102.60 } },
    { name: 'Green Bay Lakers', winnerName: 'Green Bay Lakers', t1: { name: 'Green Bay Lakers', score: 124.20 }, t2: { name: 'Mesquita1983', score: 120.94 } },
    { name: 'HeidlonG', winnerName: 'HeidlonG', t1: { name: 'HeidlonG', score: 112.04 }, t2: { name: 'JoaoP97', score: 100.80 } },
    { name: 'DS Valhalla', winnerName: 'DS Valhalla', t1: { name: 'DS Valhalla', score: 179.64 }, t2: { name: 'CWB Empacotadores', score: 148.96 } },
    { name: 'LeandroNS', winnerName: 'LeandroNS', t1: { name: 'LeandroNS', score: 141.48 }, t2: { name: 'Nega Jurema Renegades', score: 99.44 } },
    { name: 'In AR we trust', winnerName: 'In AR we trust', t1: { name: 'In AR we trust', score: 95.14 }, t2: { name: 'BKW West Coast', score: 93.72 } },
    { name: 'Lambeaughini', winnerName: 'Lambeaughini', t1: { name: 'Lambeaughini', score: 123.74 }, t2: { name: 'Diogoashura', score: 87.60 } },
    { name: 'Deflategreats FC', winnerName: 'Deflategreats FC', t1: { name: 'Deflategreats FC', score: 124.60 }, t2: { name: 'Mestre do Fantasy', score: 85.80 } },
    { name: 'Santástico da NFL', winnerName: 'markinhosfc11', t1: { name: 'markinhosfc11', score: 104.10 }, t2: { name: 'GabrielSimioni', score: 77.88 } },
    { name: 'MAGRELÃO BLUEDOGS', winnerName: 'MAGRELÃO BLUEDOGS', t1: { name: 'MAGRELÃO BLUEDOGS', score: 122.60 }, t2: { name: 'marcobortolotto', score: 104.22 } },
    { name: 'pipito', winnerName: 'pipito', t1: { name: 'pipito', score: 131.46 }, t2: { name: 'Porto Alegre Immortals', score: 113.50 } },
    { name: 'Ghost of Soteropolis', winnerName: 'Rui', t1: { name: 'Rui', score: 106.74 }, t2: { name: 'rafaelroxxa', score: 90.94 } },
    { name: 'Explosion Raiders', winnerName: 'Explosion Raiders', t1: { name: 'Explosion Raiders', score: 103.34 }, t2: { name: 'South Chiefs', score: 95.30 } }
  ],
  2: [
    { winnerName: 'American Bulldogs', t1: { name: 'American Bulldogs', score: 129.82 }, t2: { name: 'Explosion Raiders', score: 116.16 } },
    { winnerName: 'Genipabus Dromedarios', t1: { name: 'Genipabus Dromedarios', score: 110.72 }, t2: { name: 'Ghost of Soteropolis', score: 82.08 } },
    { winnerName: 'pedrotti', t1: { name: 'pedrotti', score: 124.32 }, t2: { name: 'pipito', score: 111.68 } },
    { winnerName: 'Butt Fumble', t1: { name: 'Butt Fumble', score: 108.08 }, t2: { name: 'MAGRELÃO BLUEDOGS', score: 99.32 } },
    { winnerName: 'DGlad', t1: { name: 'DGlad', score: 129.82 }, t2: { name: 'Santástico da NFL', score: 65.26 } },
    { winnerName: 'Inno9', t1: { name: 'Inno9', score: 103.52 }, t2: { name: 'Deflategreats FC', score: 94.72 } },
    { winnerName: 'Green frogs', t1: { name: 'Green frogs', score: 120.82 }, t2: { name: 'Lambeaughini', score: 91.74 } },
    { winnerName: 'In AR we trust', t1: { name: 'Kobawsk', score: 112.26 }, t2: { name: 'In AR we trust', score: 149.02 } },
    { winnerName: 'Lunatkicks', t1: { name: 'Lunatkicks', score: 126.64 }, t2: { name: 'LeandroNS', score: 105.26 } },
    { winnerName: 'Real Garruchos F.C', t1: { name: 'Real Garruchos F.C', score: 102.02 }, t2: { name: 'DS Valhalla', score: 83.62 } },
    { winnerName: 'HeidlonG', t1: { name: 'jetro50', score: 84.60 }, t2: { name: 'HeidlonG', score: 118.44 } },
    { winnerName: 'Green Bay Lakers', t1: { name: 'DeflateKing', score: 108.68 }, t2: { name: 'Green Bay Lakers', score: 134.42 } },
    { winnerName: 'Leitinho Dolphins', t1: { name: 'Leitinho Dolphins', score: 122.22 }, t2: { name: 'SaloMAYE', score: 109.32 } },
    { winnerName: 'FelipePatriots', t1: { name: 'Sirigaita', score: 93.38 }, t2: { name: 'FelipePatriots', score: 111.26 } },
    { winnerName: 'ThomasM3l00', t1: { name: 'Denver Donkeys', score: 106.52 }, t2: { name: 'ThomasM3l00', score: 119.22 } },
    { winnerName: 'osmar', t1: { name: 'FC Chucruts', score: 103.34 }, t2: { name: 'osmar', score: 111.56 } },
    { winnerName: 'Sporting Braunschweig', t1: { name: 'ライオンズ', score: 106.98 }, t2: { name: 'Sporting Braunschweig', score: 116.32 } },
    { winnerName: 'vagnercf', t1: { name: 'vagnercf', score: 138.76 }, t2: { name: 'Samurais de olhos Azuis', score: 116.46 } },
    { winnerName: 'KFC Kings', t1: { name: 'KFC Kings', score: 142.24 }, t2: { name: 'Texão da Massa', score: 92.42 } },
    { winnerName: 'Planet Hampton', t1: { name: 'beu128', score: 95.42 }, t2: { name: 'Planet Hampton', score: 121.12 } },
    { winnerName: 'Angeloni99', t1: { name: 'Angeloni99', score: 68.36 }, t2: { name: 'North East Harpy', score: 62.92 } },
    { winnerName: 'Borgo Hawks', t1: { name: 'Viúvo do Brady', score: 103.62 }, t2: { name: 'Borgo Hawks', score: 109.56 } },
    { winnerName: 'Old No. 7th Round Picks', t1: { name: 'Old No. 7th Round Picks', score: 115.42 }, t2: { name: 'Coltsquest', score: 76.58 } },
    { winnerName: 'Verdigris Calamities', t1: { name: 'Verdigris Calamities', score: 102.66 }, t2: { name: 'Lesio9ers', score: 79.88 } },
    { winnerName: 'Melca7', t1: { name: 'Melca7', score: 99.44 }, t2: { name: 'POA Klingons', score: 91.46 } },
    { winnerName: 'Hijos de Rivers', t1: { name: 'FalcaoReal', score: 142.02 }, t2: { name: 'Hijos de Rivers', score: 147.22 } },
    { winnerName: 'Carneiros Felpudos', t1: { name: 'vilsonm', score: 73.28 }, t2: { name: 'Carneiros Felpudos', score: 112.82 } },
    { winnerName: 'WillPro', t1: { name: 'WillPro', score: 103.62 }, t2: { name: 'Corvos Caolhos', score: 101.66 } },
    { winnerName: 'volnandy', t1: { name: 'volnandy', score: 111.52 }, t2: { name: 'Brazilian Colts', score: 100.32 } },
    { winnerName: 'AleZucco', t1: { name: 'Green Bay Diamonds', score: 84.12 }, t2: { name: 'AleZucco', score: 131.12 } },
    { winnerName: 'Quack Attack', t1: { name: 'Love Thy Nabers', score: 93.62 }, t2: { name: 'Quack Attack', score: 123.72 } },
    { winnerName: 'frostzx', t1: { name: 'frostzx', score: 144.52 }, t2: { name: 'Maringá Fans', score: 95.72 } },
    { winnerName: 'AlisonBecker', t1: { name: 'FlaFalcons', score: 88.20 }, t2: { name: 'AlisonBecker', score: 117.52 } },
    { winnerName: 'Eduardocfilho', t1: { name: 'Eduardocfilho', score: 98.92 }, t2: { name: 'SipansBr', score: 91.58 } },
    { winnerName: 'Marau Bitu', t1: { name: 'RESPIRAÇÃO TOUCHDOWN', score: 94.82 }, t2: { name: 'Marau Bitu', score: 118.56 } },
    { winnerName: 'SaintsJP', t1: { name: 'SaintsJP', score: 80.84 }, t2: { name: 'AndreLimas', score: 77.48 } },
    { winnerName: '“MaHomies”', t1: { name: '“MaHomies”', score: 128.76 }, t2: { name: 'JoaoElGringo', score: 97.72 } },
    { winnerName: 'GaloMG', t1: { name: 'GaloMG', score: 112.14 }, t2: { name: 'RafaelKoehler', score: 96.76 } },
    { winnerName: 'Claudianosilva', t1: { name: 'MateusThomazini', score: 89.62 }, t2: { name: 'Claudianosilva', score: 125.22 } },
    { winnerName: 'Àlumani', t1: { name: 'Àlumani', score: 132.94 }, t2: { name: 'Giants Suzano', score: 96.46 } },
    { winnerName: 'Rictus FC', t1: { name: 'RegisCarrara', score: 109.62 }, t2: { name: 'Rictus FC', score: 110.44 } },
    { winnerName: 'Salimporto', t1: { name: 'Last but not least', score: 101.12 }, t2: { name: 'Salimporto', score: 145.14 } },
    { winnerName: 'Flessakianos', t1: { name: 'Mamutes do Cerrado', score: 125.62 }, t2: { name: 'Flessakianos', score: 146.22 } },
    { winnerName: 'yasminfariadias', t1: { name: 'migliorinisa', score: 93.12 }, t2: { name: 'yasminfariadias', score: 113.36 } },
    { winnerName: 'Cyber Rats', t1: { name: 'Cyber Rats', score: 120.44 }, t2: { name: 'Urubroncos FC', score: 103.64 } },
    { winnerName: 'AndreBruz', t1: { name: 'KauEdelman11', score: 94.28 }, t2: { name: 'AndreBruz', score: 119.64 } },
    { winnerName: 'Blitz do Chama', t1: { name: 'Blitz do Chama', score: 133.32 }, t2: { name: 'ThiagoW', score: 90.26 } },
    { winnerName: 'LucasKP', t1: { name: 'W’69', score: 95.92 }, t2: { name: 'LucasKP', score: 140.72 } },
    { winnerName: 'LucasPFerreira', t1: { name: 'Chases da depressão', score: 77.90 }, t2: { name: 'LucasPFerreira', score: 120.46 } },
    { winnerName: 'Bragil', t1: { name: 'Montanha13', score: 91.22 }, t2: { name: 'Bragil', score: 109.38 } },
    { winnerName: 'Lutfi Lycans', t1: { name: 'ManualNFLruim', score: 60.30 }, t2: { name: 'Lutfi Lycans', score: 87.32 } },
    { winnerName: 'Redskins RS', t1: { name: 'Redskins RS', score: 99.92 }, t2: { name: 'Savio87', score: 99.20 } },
    { winnerName: 'Kaepernick squad', t1: { name: 'Kaepernick squad', score: 141.50 }, t2: { name: 'TwerkZonE', score: 118.12 } },
    { winnerName: 'Henry’s Kingdom', t1: { name: 'Campinas Broncos', score: 77.66 }, t2: { name: 'Henry’s Kingdom', score: 120.82 } },
    { winnerName: 'SiaraBigheads', t1: { name: 'SiaraBigheads', score: 117.82 }, t2: { name: 'VCF_49ers', score: 102.82 } },
    { winnerName: 'Vulgo Malvadão', t1: { name: '21 Fighters', score: 80.40 }, t2: { name: 'Vulgo Malvadão', score: 86.22 } },
    { winnerName: 'Zorzella', t1: { name: 'Zorzella', score: 91.32 }, t2: { name: 'PinhaisUnderdogs', score: 82.32 } },
    { winnerName: 'AaronFavre', t1: { name: 'AaronFavre', score: 100.04 }, t2: { name: 'BengaoDaMassa', score: 92.78 } },
    { winnerName: 'Reds disfarçados', t1: { name: 'Reds disfarçados', score: 106.32 }, t2: { name: 'LeandroGaucho', score: 99.92 } },
    { winnerName: 'Ué', t1: { name: 'DanPini', score: 128.00 }, t2: { name: 'Ué', score: 141.22 } },
    { winnerName: 'FELIPERAMS', t1: { name: 'Mundstock', score: 93.52 }, t2: { name: 'FELIPERAMS', score: 122.22 } },
    { winnerName: 'Direful Teachers', t1: { name: 'Direful Teachers', score: 104.76 }, t2: { name: 'Isaque49er', score: 81.38 } },
    { winnerName: 'Vader\'s', t1: { name: 'Camaragibe Republicans', score: 80.08 }, t2: { name: 'Vader\'s', score: 81.76 } },
    { winnerName: 'Capivaras Espaciais', t1: { name: 'Capivaras Espaciais', score: 152.90 }, t2: { name: 'vitor9', score: 86.02 } }
  ],
  3: [
    { winnerName: 'AlisonBecker', t1: { name: 'American Bulldogs', score: 132.54 }, t2: { name: 'AlisonBecker', score: 151.34 } },
    { winnerName: 'Eduardocfilho', t1: { name: 'Genipabus Dromedarios', score: 129.06 }, t2: { name: 'Eduardocfilho', score: 145.98 } },
    { winnerName: 'pedrotti', t1: { name: 'pedrotti', score: 157.32 }, t2: { name: 'Marau Bitu', score: 111.90 } },
    { winnerName: 'Butt Fumble', t1: { name: 'Butt Fumble', score: 131.04 }, t2: { name: 'SaintsJP', score: 79.38 } },
    { winnerName: '“MaHomies”', t1: { name: 'DGlad', score: 109.16 }, t2: { name: '“MaHomies”', score: 124.90 } },
    { winnerName: 'GaloMG', t1: { name: 'Inno9', score: 100.88 }, t2: { name: 'GaloMG', score: 156.30 } },
    { winnerName: 'Claudianosilva', t1: { name: 'Green frogs', score: 114.22 }, t2: { name: 'Claudianosilva', score: 128.38 } },
    { winnerName: 'Àlumani', t1: { name: 'In AR we trust', score: 93.78 }, t2: { name: 'Àlumani', score: 101.60 } },
    { winnerName: 'Rictus FC', t1: { name: 'Lunatkicks', score: 100.70 }, t2: { name: 'Rictus FC', score: 107.90 } },
    { winnerName: 'Salimporto', t1: { name: 'Real Garruchos F.C', score: 97.86 }, t2: { name: 'Salimporto', score: 105.80 } },
    { winnerName: 'HeidlonG', t1: { name: 'HeidlonG', score: 151.20 }, t2: { name: 'Flessakianos', score: 129.14 } },
    { winnerName: 'Green Bay Lakers', t1: { name: 'Green Bay Lakers', score: 101.68 }, t2: { name: 'yasminfariadias', score: 91.50 } },
    { winnerName: 'Leitinho Dolphins', t1: { name: 'Leitinho Dolphins', score: 144.28 }, t2: { name: 'Cyber Rats', score: 81.16 } },
    { winnerName: 'FelipePatriots', t1: { name: 'FelipePatriots', score: 75.40 }, t2: { name: 'AndreBruz', score: 72.50 } },
    { winnerName: 'Blitz do Chama', t1: { name: 'ThomasM3l00', score: 124.88 }, t2: { name: 'Blitz do Chama', score: 131.14 } },
    { winnerName: 'LucasKP', t1: { name: 'osmar', score: 97.80 }, t2: { name: 'LucasKP', score: 110.98 } },
    { winnerName: 'Sporting Braunschweig', t1: { name: 'Sporting Braunschweig', score: 111.06 }, t2: { name: 'LucasPFerreira', score: 102.92 } },
    { winnerName: 'vagnercf', t1: { name: 'vagnercf', score: 121.20 }, t2: { name: 'Bragil', score: 112.82 } },
    { winnerName: 'Lutfi Lycans', t1: { name: 'KFC Kings', score: 94.70 }, t2: { name: 'Lutfi Lycans', score: 123.24 } },
    { winnerName: 'Planet Hampton', t1: { name: 'Planet Hampton', score: 133.44 }, t2: { name: 'Redskins RS', score: 100.26 } },
    { winnerName: 'Kaepernick squad', t1: { name: 'Angeloni99', score: 94.30 }, t2: { name: 'Kaepernick squad', score: 135.12 } },
    { winnerName: 'Borgo Hawks', t1: { name: 'Borgo Hawks', score: 121.80 }, t2: { name: 'Henry’s Kingdom', score: 86.18 } },
    { winnerName: 'SiaraBigheads', t1: { name: 'Old No. 7th Round Picks', score: 95.16 }, t2: { name: 'SiaraBigheads', score: 137.56 } },
    { winnerName: 'Verdigris Calamities', t1: { name: 'Verdigris Calamities', score: 132.26 }, t2: { name: 'Vulgo Malvadão', score: 108.28 } },
    { winnerName: 'Melca7', t1: { name: 'Melca7', score: 111.50 }, t2: { name: 'Zorzella', score: 108.48 } },
    { winnerName: 'Hijos de Rivers', t1: { name: 'Hijos de Rivers', score: 128.16 }, t2: { name: 'AaronFavre', score: 98.80 } },
    { winnerName: 'Carneiros Felpudos', t1: { name: 'Carneiros Felpudos', score: 125.66 }, t2: { name: 'Reds disfarçados', score: 115.56 } },
    { winnerName: 'WillPro', t1: { name: 'WillPro', score: 96.86 }, t2: { name: 'Ué', score: 78.32 } },
    { winnerName: 'FELIPERAMS', t1: { name: 'volnandy', score: 101.56 }, t2: { name: 'FELIPERAMS', score: 127.42 } },
    { winnerName: 'AleZucco', t1: { name: 'AleZucco', score: 122.16 }, t2: { name: 'Direful Teachers', score: 96.44 } },
    { winnerName: 'Quack Attack', t1: { name: 'Quack Attack', score: 105.48 }, t2: { name: 'Vader\'s', score: 95.70 } },
    { winnerName: 'frostzx', t1: { name: 'frostzx', score: 132.66 }, t2: { name: 'Capivaras Espaciais', score: 76.28 } }
  ],
  4: [
    { winnerName: 'Sporting Braunschweig', t1: { name: 'AlisonBecker', score: 105.32 }, t2: { name: 'Sporting Braunschweig', score: 131.14 } },
    { winnerName: 'Eduardocfilho', t1: { name: 'Eduardocfilho', score: 99.84 }, t2: { name: 'vagnercf', score: 86.50 } },
    { winnerName: 'Lutfi Lycans', t1: { name: 'pedrotti', score: 96.52 }, t2: { name: 'Lutfi Lycans', score: 97.38 } },
    { winnerName: 'Butt Fumble', t1: { name: 'Butt Fumble', score: 131.02 }, t2: { name: 'Planet Hampton', score: 78.48 } },
    { winnerName: '“MaHomies”', t1: { name: '“MaHomies”', score: 121.44 }, t2: { name: 'Kaepernick squad', score: 116.34 } },
    { winnerName: 'Borgo Hawks', t1: { name: 'GaloMG', score: 90.60 }, t2: { name: 'Borgo Hawks', score: 128.50 } },
    { winnerName: 'Claudianosilva', t1: { name: 'Claudianosilva', score: 167.52 }, t2: { name: 'SiaraBigheads', score: 106.22 } },
    { winnerName: 'Verdigris Calamities', t1: { name: 'Àlumani', score: 86.10 }, t2: { name: 'Verdigris Calamities', score: 113.56 } },
    { winnerName: 'Rictus FC', t1: { name: 'Rictus FC', score: 108.60 }, t2: { name: 'Melca7', score: 77.70 } },
    { winnerName: 'Hijos de Rivers', t1: { name: 'Salimporto', score: 84.32 }, t2: { name: 'Hijos de Rivers', score: 133.74 } },
    { winnerName: 'HeidlonG', t1: { name: 'HeidlonG', score: 103.20 }, t2: { name: 'Carneiros Felpudos', score: 100.76 } },
    { winnerName: 'WillPro', t1: { name: 'Green Bay Lakers', score: 98.62 }, t2: { name: 'WillPro', score: 151.76 } },
    { winnerName: 'FELIPERAMS', t1: { name: 'Leitinho Dolphins', score: 91.50 }, t2: { name: 'FELIPERAMS', score: 91.82 } },
    { winnerName: 'FelipePatriots', t1: { name: 'FelipePatriots', score: 128.14 }, t2: { name: 'AleZucco', score: 102.80 } },
    { winnerName: 'Blitz do Chama', t1: { name: 'Blitz do Chama', score: 140.22 }, t2: { name: 'Quack Attack', score: 130.18 } },
    { winnerName: 'frostzx', t1: { name: 'LucasKP', score: 65.50 }, t2: { name: 'frostzx', score: 145.22 } }
  ],
  5: [
    { winnerName: 'Rictus FC', t1: { name: 'Sporting Braunschweig', score: 112.40 }, t2: { name: 'Rictus FC', score: 114.22 } },
    { winnerName: 'Hijos de Rivers', t1: { name: 'Eduardocfilho', score: 85.36 }, t2: { name: 'Hijos de Rivers', score: 116.70 } },
    { winnerName: 'HeidlonG', t1: { name: 'Lutfi Lycans', score: 100.26 }, t2: { name: 'HeidlonG', score: 138.34 } },
    { winnerName: 'Butt Fumble', t1: { name: 'Butt Fumble', score: 106.44 }, t2: { name: 'WillPro', score: 95.64 } },
    { winnerName: '“MaHomies”', t1: { name: '“MaHomies”', score: 119.38 }, t2: { name: 'FELIPERAMS', score: 107.84 } },
    { winnerName: 'Borgo Hawks', t1: { name: 'Borgo Hawks', score: 117.10 }, t2: { name: 'FelipePatriots', score: 78.38 } },
    { winnerName: 'Claudianosilva', t1: { name: 'Claudianosilva', score: 112.56 }, t2: { name: 'Blitz do Chama', score: 97.16 } },
    { winnerName: 'Verdigris Calamities', t1: { name: 'Verdigris Calamities', score: 91.46 }, t2: { name: 'frostzx', score: 88.04 } }
  ],
  6: [
    { winnerName: 'Rictus FC', t1: { name: 'Rictus FC', score: 109.18 }, t2: { name: '“MaHomies”', score: 101.34 } },
    { winnerName: 'Hijos de Rivers', t1: { name: 'Hijos de Rivers', score: 150.06 }, t2: { name: 'Borgo Hawks', score: 86.12 } },
    { winnerName: 'HeidlonG', t1: { name: 'HeidlonG', score: 132.24 }, t2: { name: 'Claudianosilva', score: 129.84 } },
    { winnerName: 'Butt Fumble', t1: { name: 'Butt Fumble', score: 166.14 }, t2: { name: 'Verdigris Calamities', score: 93.36 } }
  ],
  7: [
    { winnerName: 'HeidlonG', t1: { name: 'Rictus FC', score: 93.20 }, t2: { name: 'HeidlonG', score: 99.46 } },
    { winnerName: 'Hijos de Rivers', t1: { name: 'Hijos de Rivers', score: 124.52 }, t2: { name: 'Butt Fumble', score: 80.12 } }
  ],
  8: [
    { winnerName: 'Rictus FC', t1: { name: 'Rictus FC', score: 115.40 }, t2: { name: 'Butt Fumble', score: 93.72 } }
  ],
  9: [
    { winnerName: 'Hijos de Rivers', t1: { name: 'HeidlonG', score: 99.00 }, t2: { name: 'Hijos de Rivers', score: 115.72 } }
  ]
};

export default RankingPlayoffsPage;
