import React, { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, Trophy, Crown, Medal, Award, Star, Shield, Sword, Layers, User as UserIcon, RefreshCw, AlertCircle } from 'lucide-react';
import { fetchLeagueData, getAvatarUrl } from '../services/sleeper';

interface HallOfFameProps {
  onBack: () => void;
}

interface Champion {
  type: 'major' | 'divisional';
  category: string;
  team: string;
  manager: string;
  leagueId: string;
  avatar: string | null;
  points?: string;
  leagueName?: string;
}

const DIVISIONAL_LEAGUE_IDS = [
  '1204159865153388544', '1227151609222414336', '1203718439328288768', '1228196172506615808',
  '1204160977872883712', '1208069127642558464', '1228858492396249088', '1205275237512380416',
  '1230678720927256576', '1204161934232911872', '1208069811418976256', '1228075640113086464',
  '1230631997513154560', '1229611593545826304', '1228008558625292288', '1205275488969306112',
  '1230004768844283904', '1205274747131150336', '1227150862938284032', '1205275066451906560',
  '1230515275959377920'
];

const HallOfFame: React.FC<HallOfFameProps> = ({ onBack }) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [majorChampions, setMajorChampions] = useState<Champion[]>([
    {
      type: 'major',
      category: 'Playoffs Challenge',
      team: 'Hijos de Rivers',
      manager: 'Passarelli80',
      leagueId: '1227151609222414336',
      avatar: '338903348123287552',
      points: '115.72',
    },
    {
      type: 'major',
      category: 'Brady Bowl',
      team: 'Coutinho15',
      manager: 'Coutinho15',
      leagueId: '1232712391108612096',
      avatar: '867746187652755456',
      points: '660 pts ranking',
    },
  ]);

  const [divisionalChampions, setDivisionalChampions] = useState<Champion[]>([]);

  const loadAllChampions = useCallback(async () => {
    setLoading(true);
    const champs: Champion[] = [];
    
    try {
      for (let i = 0; i < DIVISIONAL_LEAGUE_IDS.length; i++) {
        const leagueId = DIVISIONAL_LEAGUE_IDS[i];
        setProgress(Math.round(((i + 1) / DIVISIONAL_LEAGUE_IDS.length) * 100));
        
        try {
          const data = await fetchLeagueData(leagueId);
          if (!data.winnersBracket || data.winnersBracket.length === 0) continue;

          // O campeão é quem venceu a partida de 1º lugar (p: 1)
          const finalMatch = data.winnersBracket.find(m => m.p === 1);
          if (finalMatch && finalMatch.w) {
            const winnerRoster = data.rosters.find(r => r.roster_id === finalMatch.w);
            const winnerUser = data.users.find(u => u.user_id === winnerRoster?.owner_id);
            
            if (winnerUser) {
              const cityName = data.league.name.split(' - ').pop() || data.league.name;
              champs.push({
                type: 'divisional',
                category: 'Divisional Champion',
                leagueName: cityName.replace('Divisional ', ''),
                team: winnerUser.metadata?.team_name || winnerUser.display_name,
                manager: winnerUser.display_name,
                leagueId: leagueId,
                avatar: winnerUser.avatar || winnerUser.metadata?.avatar || null
              });
            }
          }
        } catch (e) {
          console.error(`Erro ao carregar campeão da liga ${leagueId}`, e);
        }
      }
      
      setDivisionalChampions(champs.sort((a, b) => (a.leagueName || '').localeCompare(b.leagueName || '')));
    } catch (err) {
      console.error("Erro fatal ao carregar Hall of Fame:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAllChampions();
  }, [loadAllChampions]);

  return (
    <div className="min-h-screen bg-[#0a0f1d] text-slate-200 py-12 px-6 overflow-x-hidden selection:bg-yellow-500/30">
      <div className="max-w-6xl mx-auto space-y-16">
        {/* Header */}
        <header className="flex items-center justify-between sticky top-0 bg-[#0a0f1d]/90 backdrop-blur-xl py-6 z-50 border-b border-white/5 -mx-6 px-6">
          <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Voltar</span>
          </button>
          <div className="text-right">
            <div className="flex items-center justify-end gap-3 mb-1">
              <h1 className="text-3xl font-black text-white uppercase italic leading-none tracking-tighter">Quadro de Honra</h1>
              {loading && <RefreshCw className="w-4 h-4 text-yellow-500 animate-spin" />}
            </div>
            <p className="text-[10px] font-bold text-yellow-500 uppercase tracking-[0.4em]">Soberanos da Temporada 2025</p>
          </div>
        </header>

        {loading && divisionalChampions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-8">
            <div className="relative">
              <RefreshCw className="w-16 h-16 text-yellow-500 animate-spin" />
              <div className="absolute inset-0 bg-yellow-500/20 blur-2xl rounded-full"></div>
            </div>
            <div className="text-center space-y-3">
              <h2 className="text-xl font-black text-white uppercase italic tracking-widest">Consultando Brackets Reais</h2>
              <div className="w-64 h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/10 mx-auto">
                <div className="h-full bg-yellow-500 transition-all duration-300" style={{ width: `${progress}%` }}></div>
              </div>
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.3em]">{progress}% - Analisando 21 Ligas Divisionais</p>
            </div>
          </div>
        ) : (
          <div className="space-y-20 animate-in fade-in duration-700">
            {/* Section: Grand Champions */}
            <section className="space-y-8">
              <div className="flex items-center gap-4 px-2">
                 <Trophy className="w-6 h-6 text-yellow-500" />
                 <h2 className="text-xl font-black uppercase italic tracking-widest text-white">Grandes Campeões</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 {majorChampions.map((champ, idx) => (
                   <div key={idx} className="group relative p-1 bg-gradient-to-br from-yellow-400 via-amber-600 to-yellow-900 rounded-[3rem] shadow-[0_0_50px_rgba(234,179,8,0.15)] transition-all hover:scale-[1.02]">
                      <div className="bg-[#0a0f1d] rounded-[2.8rem] p-10 h-full flex flex-col items-center text-center space-y-6 overflow-hidden relative">
                        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                           {champ.category.includes('Challenge') ? <Sword className="w-32 h-32 text-white" /> : <Shield className="w-32 h-32 text-white" />}
                        </div>
                        
                        <div className="relative">
                          <div className="w-28 h-28 rounded-full border-4 border-yellow-500/50 p-1 relative z-10 flex items-center justify-center bg-slate-900 overflow-hidden shadow-2xl">
                             <img 
                                src={getAvatarUrl(champ.avatar)} 
                                className="w-full h-full rounded-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" 
                                alt="" 
                             />
                          </div>
                          <div className="absolute -bottom-2 -right-2 bg-yellow-500 text-slate-950 p-2 rounded-full shadow-lg border-2 border-[#0a0f1d] z-20">
                             <Crown className="w-5 h-5 fill-current" />
                          </div>
                        </div>

                        <div className="space-y-2 relative z-10">
                           <p className="text-[10px] font-black text-yellow-500 uppercase tracking-[0.5em]">{champ.category}</p>
                           <h3 className="text-3xl font-black text-white uppercase italic tracking-tighter">{champ.team}</h3>
                           <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">@{champ.manager}</p>
                        </div>

                        <div className="px-6 py-2 bg-yellow-500/10 border border-yellow-500/20 rounded-full relative z-10">
                           <span className="text-[10px] font-black text-yellow-500 uppercase tracking-widest italic">{champ.points}</span>
                        </div>
                      </div>
                   </div>
                 ))}
              </div>
            </section>

            {/* Section: Divisional Champions */}
            <section className="space-y-8">
              <div className="flex items-center justify-between px-2">
                 <div className="flex items-center gap-4">
                   <Layers className="w-6 h-6 text-blue-500" />
                   <h2 className="text-xl font-black uppercase italic tracking-widest text-white">Campeões Divisionais ({divisionalChampions.length})</h2>
                 </div>
                 {!loading && progress < 100 && (
                   <span className="text-[8px] font-black text-blue-400 uppercase tracking-widest bg-blue-500/10 px-3 py-1 rounded-full">Sincronizando...</span>
                 )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                 {divisionalChampions.map((champ, idx) => (
                   <div key={idx} className="bg-[#1e293b]/20 border border-white/5 rounded-[2rem] p-6 hover:bg-white/5 hover:border-blue-500/30 transition-all group shadow-xl relative overflow-hidden">
                      <div className="flex items-center gap-4 mb-4 relative z-10">
                         <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-white/10 flex items-center justify-center overflow-hidden shadow-lg group-hover:scale-105 transition-transform shrink-0">
                            {champ.avatar ? (
                              <img 
                                src={getAvatarUrl(champ.avatar)} 
                                className="w-full h-full object-cover" 
                                alt="" 
                              />
                            ) : (
                               <Shield className="w-6 h-6 text-blue-500/40" />
                            )}
                         </div>
                         <div className="min-w-0">
                            <p className="text-[9px] font-black text-blue-400 uppercase tracking-widest">{champ.leagueName}</p>
                            <h4 className="text-sm font-black text-white uppercase italic truncate leading-tight mt-0.5">{champ.team}</h4>
                            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest truncate">@{champ.manager}</p>
                         </div>
                      </div>
                      <div className="pt-4 border-t border-white/5 flex items-center justify-between relative z-10">
                         <div className="flex items-center gap-1.5">
                            <Award className="w-3 h-3 text-yellow-500" />
                            <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Champion</span>
                         </div>
                         <Star className="w-3 h-3 text-blue-500 fill-blue-500/20" />
                      </div>
                      <Shield className="absolute -bottom-4 -right-4 w-16 h-16 text-white/5 rotate-12 pointer-events-none" />
                   </div>
                 ))}
              </div>

              {divisionalChampions.length === 0 && !loading && (
                <div className="py-20 text-center bg-white/5 rounded-[3rem] border border-dashed border-white/10 space-y-4">
                  <AlertCircle className="w-12 h-12 text-slate-700 mx-auto" />
                  <div>
                    <p className="text-white font-black uppercase tracking-widest text-sm">Dados não encontrados</p>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-[9px] mt-1">Não foi possível localizar os brackets de 2025.</p>
                  </div>
                </div>
              )}
            </section>
          </div>
        )}

        {/* Footer Info */}
        <footer className="pt-12 border-t border-white/5 text-center space-y-4">
           <div className="inline-flex items-center gap-3 px-6 py-2 bg-white/5 border border-white/10 rounded-full">
              <Star className="w-4 h-4 text-yellow-500" />
              <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em]">FWL 2025 • High-Fidelity Data Protocol • Hall of Fame Series</p>
           </div>
           <p className="text-[8px] text-slate-600 font-medium uppercase tracking-widest max-w-lg mx-auto leading-relaxed px-4">
             O Quadro de Honra celebra os competidores que atingiram a glória máxima. Os dados de campeões divisionais são extraídos em tempo real dos Brackets oficiais da Temporada 2025 via Sleeper API.
           </p>
        </footer>
      </div>
    </div>
  );
};

export default HallOfFame;