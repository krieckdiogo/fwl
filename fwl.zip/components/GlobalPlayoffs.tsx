
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { fetchLeagueData, fetchMatchupsForWeek, getAvatarUrl } from '../services/sleeper';
import { League, User, Matchup } from '../types';
import { 
  Trophy, 
  ChevronLeft, 
  Plus, 
  Minus, 
  Maximize,
  Target
} from 'lucide-react';

interface GlobalPlayoffsProps {
  leagues: League[];
  onBack: () => void;
}

interface QualifiedTeam {
  roster_id: number;
  user: User | undefined;
  league_id: string;
  league_name: string;
  wins: number;
  fpts: number;
  league_rank: number;
  seed?: number;
}

interface MatchNode {
  t1: QualifiedTeam | undefined;
  t2: QualifiedTeam | undefined;
  winner: QualifiedTeam | undefined;
  p1: number;
  p2: number;
}

const GlobalPlayoffs: React.FC<GlobalPlayoffsProps> = ({ leagues, onBack }) => {
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [qualifiedTeams, setQualifiedTeams] = useState<QualifiedTeam[]>([]);
  const [weeklyScores, setWeeklyScores] = useState<Record<string, Record<number, Record<number, number>>>>({}); 
  const [scale, setScale] = useState(0.4);
  const touchRef = useRef<{ dist: number | null }>({ dist: null });

  const loadAllData = useCallback(async () => {
    setLoading(true);
    try {
      const rankPools: Record<number, QualifiedTeam[]> = { 1: [], 2: [], 3: [], 4: [] };
      const scoresMap: Record<string, Record<number, Record<number, number>>> = {};

      for (let i = 0; i < leagues.length; i++) {
        const league = leagues[i];
        setProgress(Math.round(((i + 1) / leagues.length) * 100));
        const { rosters, users, league: leagueInfo } = await fetchLeagueData(league.league_id);
        
        const stats: Record<number, { wins: number, fpts: number }> = {};
        rosters.forEach(r => stats[r.roster_id] = { wins: 0, fpts: 0 });

        const weekPromises = [];
        for (let w = 1; w <= 11; w++) weekPromises.push(fetchMatchupsForWeek(league.league_id, w).catch(() => []));
        for (let w = 12; w <= 17; w++) weekPromises.push(fetchMatchupsForWeek(league.league_id, w).then(m => ({ week: w, matchups: m })).catch(() => ({ week: w, matchups: [] })));
        
        const results = await Promise.all(weekPromises);
        results.forEach((res: any) => {
          if (Array.isArray(res)) {
            const pairs: Record<number, any[]> = {};
            res.forEach(m => {
              if (!pairs[m.matchup_id]) pairs[m.matchup_id] = [];
              pairs[m.matchup_id].push(m);
              if (stats[m.roster_id]) stats[m.roster_id].fpts += m.points;
            });
            Object.values(pairs).forEach(p => {
              if (p.length === 2) {
                const [t1, t2] = p;
                if (t1.points > t2.points) stats[t1.roster_id].wins++;
                else if (t2.points > t1.points) stats[t2.roster_id].wins++;
              }
            });
          } else if (res.week >= 12) {
            if (!scoresMap[league.league_id]) scoresMap[league.league_id] = {};
            res.matchups.forEach((m: Matchup) => {
              if (!scoresMap[league.league_id][m.roster_id]) scoresMap[league.league_id][m.roster_id] = {};
              scoresMap[league.league_id][m.roster_id][res.week] = m.points;
            });
          }
        });

        const sorted = [...rosters].sort((a, b) => {
          const sA = stats[a.roster_id];
          const sB = stats[b.roster_id];
          if (sB.wins !== sA.wins) return sB.wins - sA.wins;
          return sB.fpts - sA.fpts;
        });

        sorted.forEach((r, idx) => {
          const rank = idx + 1;
          if (rank <= 4) {
            const user = users.find(u => u.user_id === r.owner_id);
            rankPools[rank].push({
              roster_id: r.roster_id,
              user,
              league_id: league.league_id,
              league_name: leagueInfo.name,
              wins: stats[r.roster_id].wins,
              fpts: stats[r.roster_id].fpts,
              league_rank: rank
            });
          }
        });
      }

      const finalRanking: QualifiedTeam[] = [];
      [1, 2, 3, 4].forEach(rank => {
        const pool = rankPools[rank].sort((a, b) => {
          if (b.wins !== a.wins) return b.wins - a.wins;
          return b.fpts - a.fpts;
        });
        finalRanking.push(...pool);
      });

      const top64 = finalRanking.slice(0, 64).map((t, idx) => ({ ...t, seed: idx + 1 }));
      setQualifiedTeams(top64);
      setWeeklyScores(scoresMap);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [leagues]);

  useEffect(() => { loadAllData(); }, [loadAllData]);

  const bracket = useMemo(() => {
    if (qualifiedTeams.length === 0) return null;
    const rounds: MatchNode[][] = [];
    
    // R64 (W12)
    let currentRoundMatches: MatchNode[] = [];
    for (let i = 0; i < 32; i++) {
      const s1 = i + 1;
      const s2 = 64 - i;
      const t1 = qualifiedTeams.find(t => t.seed === s1);
      const t2 = qualifiedTeams.find(t => t.seed === s2);
      const p1 = t1 ? (weeklyScores[t1.league_id]?.[t1.roster_id]?.[12] || 0) : 0;
      const p2 = t2 ? (weeklyScores[t2.league_id]?.[t2.roster_id]?.[12] || 0) : 0;
      const winner = (t1 || t2) ? (p1 >= p2 ? t1 : t2) : undefined;
      currentRoundMatches.push({ t1, t2, winner, p1, p2 });
    }
    rounds.push(currentRoundMatches);

    let week = 13;
    let prevRound = currentRoundMatches;
    while (prevRound.length > 1) {
      const nextRound: MatchNode[] = [];
      for (let i = 0; i < prevRound.length; i += 2) {
        const t1 = prevRound[i].winner;
        const t2 = prevRound[i + 1].winner;
        const p1 = t1 ? (weeklyScores[t1.league_id]?.[t1.roster_id]?.[week] || 0) : 0;
        const p2 = t2 ? (weeklyScores[t2.league_id]?.[t2.roster_id]?.[week] || 0) : 0;
        const winner = (t1 || t2) ? (p1 >= p2 ? t1 : t2) : undefined;
        nextRound.push({ t1, t2, winner, p1, p2 });
      }
      rounds.push(nextRound);
      prevRound = nextRound;
      week++;
    }
    return rounds;
  }, [qualifiedTeams, weeklyScores]);

  const TeamCard = ({ team, points, side = 'left', winner = false }: { team: QualifiedTeam | undefined, points?: number, side?: 'left' | 'right', winner?: boolean }) => {
    return (
      <div className={`flex items-center w-[240px] bg-white border border-slate-300 rounded shadow-sm h-[64px] relative group transition-all hover:border-slate-400 ${side === 'right' ? 'flex-row-reverse' : ''}`}>
        <div className={`w-[56px] h-full bg-slate-100 flex items-center justify-center p-2 border-slate-200 ${side === 'right' ? 'border-l' : 'border-r'}`}>
          <img src={getAvatarUrl(team?.user?.avatar || null)} className="w-full h-full object-contain" alt="" />
        </div>
        <div className={`flex-1 px-3 py-1 flex flex-col justify-center min-w-0 ${side === 'right' ? 'text-right' : ''}`}>
          <div className="flex items-center gap-1 overflow-hidden">
            <span className={`text-[12px] font-black text-slate-900 truncate uppercase tracking-tight ${!team ? 'opacity-20' : ''}`}>
              {team?.user?.display_name || 'TBD'}
            </span>
          </div>
          <div className={`flex items-center gap-1 mt-0.5 ${side === 'right' ? 'flex-row-reverse' : ''}`}>
            <span className="text-[10px] font-bold text-slate-500 whitespace-nowrap">Seed {team?.seed || '#'}</span>
            <span className="text-[10px] text-slate-400 truncate">@{team?.user?.display_name?.toLowerCase().replace(/\s/g, '') || 'username'}</span>
          </div>
        </div>
        <div className={`w-[56px] h-full bg-slate-50 flex items-center justify-center border-slate-200 font-black text-slate-700 text-[14px] ${side === 'right' ? 'border-r' : 'border-l'} ${winner ? 'bg-blue-50 text-blue-600' : ''}`}>
          {points !== undefined && points > 0 ? points.toFixed(0) : '---'}
        </div>
      </div>
    );
  };

  const Header = ({ text }: { text: string }) => (
    <div className="w-[240px] text-center text-[11px] font-black text-slate-400 uppercase tracking-[0.25em] py-6">{text}</div>
  );

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      touchRef.current.dist = Math.hypot(e.touches[0].pageX - e.touches[1].pageX, e.touches[0].pageY - e.touches[1].pageY);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && touchRef.current.dist !== null) {
      const d = Math.hypot(e.touches[0].pageX - e.touches[1].pageX, e.touches[0].pageY - e.touches[1].pageY);
      const delta = d / touchRef.current.dist;
      setScale(prev => Math.min(Math.max(prev * delta, 0.1), 1.5));
      touchRef.current.dist = d;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f1f5f9] flex flex-col items-center justify-center p-8 space-y-8">
        <Target className="w-16 h-16 text-slate-400 animate-pulse" />
        <h2 className="text-xl font-bold text-slate-600 uppercase tracking-widest italic">Ajustando Ligas no Saibro...</h2>
        <div className="w-full max-w-sm h-1.5 bg-slate-200 rounded-full overflow-hidden">
          <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${progress}%` }}></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f1f5f9] flex flex-col">
      <header className="p-4 bg-white border-b border-slate-300 flex items-center justify-between z-[100] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors"><ChevronLeft className="w-6 h-6" /></button>
          <div>
            <h1 className="text-lg font-black text-slate-900 uppercase tracking-tight italic">FWL BRADY BOWL</h1>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">64 Team Professional Tournament Bracket</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setScale(s => Math.min(s + 0.1, 1.5))} className="p-2.5 bg-white border border-slate-300 rounded hover:bg-slate-50 shadow-sm text-slate-600 transition-all"><Plus className="w-5 h-5" /></button>
          <button onClick={() => setScale(s => Math.max(s - 0.1, 0.1))} className="p-2.5 bg-white border border-slate-300 rounded hover:bg-slate-50 shadow-sm text-slate-600 transition-all"><Minus className="w-5 h-5" /></button>
          <button onClick={() => setScale(0.4)} className="p-2.5 bg-white border border-slate-300 rounded hover:bg-slate-50 shadow-sm text-slate-600 transition-all"><Maximize className="w-5 h-5" /></button>
        </div>
      </header>

      <main 
        className="flex-1 overflow-auto no-scrollbar cursor-grab active:cursor-grabbing"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
      >
        <div 
          className="relative transition-transform duration-75 origin-top-left p-[120px]"
          style={{ transform: `scale(${scale})`, minWidth: '8500px', height: '4500px' }}
        >
          {/* ROUND TITLES */}
          <div className="absolute top-[30px] left-[120px] flex gap-[220px] items-center">
            <Header text="Round of 64" />
            <Header text="Round of 32" />
            <Header text="Sweet 16" />
            <Header text="Elite 8" />
            <div className="w-[400px] text-center text-sm font-black text-slate-900 uppercase tracking-[0.4em]">CHAMPIONSHIP</div>
            <Header text="Final Four" />
            <Header text="Sweet 16" />
            <Header text="Round of 32" />
            <Header text="Round of 64" />
          </div>

          {/* LEFT SIDE BRACKET (NORTH/SOUTH) */}
          <div className="absolute left-[120px] top-[120px] flex gap-[220px] items-start">
            {/* Round 1 Left */}
            <div className="flex flex-col gap-12 pt-[44px]">
              <div className="text-[22px] font-black text-slate-300 italic mb-4">NORTH</div>
              {bracket?.[0].slice(0, 16).map((m, i) => (
                <div key={i} className="relative flex flex-col gap-4 h-[144px] justify-center">
                  {i === 8 && <div className="text-[22px] font-black text-slate-300 italic my-12">SOUTH</div>}
                  <TeamCard team={m.t1} points={m.p1} />
                  <TeamCard team={m.t2} points={m.p2} />
                  {/* Conector Pro - Alinhado ao centro */}
                  <div className="absolute left-[240px] top-[32px] w-[110px] h-[40px] border-r-2 border-t-2 border-slate-800 pointer-events-none"></div>
                  <div className="absolute left-[240px] bottom-[32px] w-[110px] h-[40px] border-r-2 border-b-2 border-slate-800 pointer-events-none"></div>
                  <div className="absolute left-[350px] top-1/2 -translate-y-1/2 w-[110px] h-[2px] bg-slate-800 pointer-events-none"></div>
                </div>
              ))}
            </div>

            {/* Round 2 Left - Estes são os vencedores do R1 */}
            <div className="flex flex-col pt-[116px] gap-[188px]">
              {bracket?.[1].slice(0, 8).map((m, i) => (
                <div key={i} className="relative flex flex-col gap-4 h-[144px] justify-center">
                   {i === 4 && <div className="h-[216px]"></div>}
                   {/* Card do Vencedor do Confronto Anterior */}
                   <TeamCard team={m.t1} points={m.p1} />
                   
                   {/* Conector para o próximo round */}
                   <div className="absolute left-[240px] top-[32px] w-[110px] h-[166px] border-r-2 border-t-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute left-[240px] bottom-[-134px] w-[110px] h-[166px] border-r-2 border-b-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute left-[350px] top-1/2 -translate-y-1/2 w-[110px] h-[2px] bg-slate-800 pointer-events-none"></div>
                </div>
              ))}
            </div>

            {/* Round 3 Left (Sweet 16) */}
            <div className="flex flex-col pt-[282px] gap-[476px]">
              {bracket?.[2].slice(0, 4).map((m, i) => (
                <div key={i} className="relative flex flex-col gap-4 h-[144px] justify-center">
                   {i === 2 && <div className="h-[432px]"></div>}
                   <TeamCard team={m.t1} points={m.p1} />
                   
                   <div className="absolute left-[240px] top-[32px] w-[110px] h-[310px] border-r-2 border-t-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute left-[240px] bottom-[-278px] w-[110px] h-[310px] border-r-2 border-b-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute left-[350px] top-1/2 -translate-y-1/2 w-[110px] h-[2px] bg-slate-800 pointer-events-none"></div>
                </div>
              ))}
            </div>

            {/* Round 4 Left (Elite 8) */}
            <div className="flex flex-col pt-[592px] gap-[1120px]">
              {bracket?.[3].slice(0, 2).map((m, i) => (
                <div key={i} className="relative flex flex-col gap-4 h-[144px] justify-center">
                   <TeamCard team={m.t1} points={m.p1} />
                   
                   <div className="absolute left-[240px] top-[32px] w-[110px] h-[632px] border-r-2 border-t-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute left-[240px] bottom-[-600px] w-[110px] h-[632px] border-r-2 border-b-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute left-[350px] top-1/2 -translate-y-1/2 w-[110px] h-[2px] bg-slate-800 pointer-events-none"></div>
                </div>
              ))}
            </div>

            {/* Final Four Left */}
            <div className="flex flex-col pt-[1224px]">
              <div className="relative h-[144px] flex flex-col justify-center">
                <TeamCard team={bracket?.[4][0].t1} points={bracket?.[4][0].p1} />
                <div className="absolute left-[240px] top-1/2 -translate-y-1/2 w-[260px] h-[2px] bg-slate-800"></div>
              </div>
            </div>
          </div>

          {/* CHAMPIONSHIP CENTER */}
          <div className="absolute left-[2400px] top-[1050px] flex flex-col items-center">
             <div className="text-[32px] font-black text-slate-900 tracking-[0.5em] mb-20 italic">CHAMPION</div>
             <div className="flex items-center gap-12">
                <div className="flex flex-col items-center gap-6">
                   <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Finalist 1</div>
                   <TeamCard team={bracket?.[5][0].t1} points={bracket?.[5][0].p1} />
                </div>
                
                <div className="relative">
                  <div className="w-[420px] h-[260px] bg-white border-8 border-slate-900 rounded-3xl flex flex-col items-center justify-center p-8 shadow-[0_45px_70px_-20px_rgba(0,0,0,0.2)] overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-2 bg-slate-900"></div>
                    {bracket?.[5][0].winner ? (
                      <div className="text-center animate-in zoom-in duration-700 scale-125">
                         <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-6" />
                         <div className="text-2xl font-black text-slate-900 uppercase leading-none mb-1 italic tracking-tighter">{bracket?.[5][0].winner.user?.display_name}</div>
                         <div className="text-[12px] font-bold text-slate-400 tracking-widest uppercase">Global Champion Series Winner</div>
                      </div>
                    ) : (
                      <div className="text-slate-200 font-black italic text-5xl select-none opacity-50">TBD</div>
                    )}
                  </div>
                  <div className="absolute -top-8 -right-8 w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center border-4 border-white rotate-12 shadow-2xl">
                    <Trophy className="w-12 h-12 text-white" />
                  </div>
                </div>

                <div className="flex flex-col items-center gap-6">
                   <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Finalist 2</div>
                   <TeamCard team={bracket?.[5][0].t2} points={bracket?.[5][0].p2} side="right" />
                </div>
             </div>
          </div>

          {/* RIGHT SIDE BRACKET (SOUTH/EAST) */}
          <div className="absolute left-[3380px] top-[120px] flex flex-row-reverse gap-[220px] items-start">
            {/* Round 1 Right */}
            <div className="flex flex-col gap-12 pt-[44px]">
              <div className="text-[22px] font-black text-slate-300 italic mb-4 text-right">SOUTH</div>
              {bracket?.[0].slice(16, 32).map((m, i) => (
                <div key={i} className="relative flex flex-col gap-4 h-[144px] justify-center">
                  {i === 8 && <div className="text-[22px] font-black text-slate-300 italic my-12 text-right">EAST</div>}
                  <TeamCard team={m.t1} points={m.p1} side="right" />
                  <TeamCard team={m.t2} points={m.p2} side="right" />
                  <div className="absolute right-[240px] top-[32px] w-[110px] h-[40px] border-l-2 border-t-2 border-slate-800 pointer-events-none"></div>
                  <div className="absolute right-[240px] bottom-[32px] w-[110px] h-[40px] border-l-2 border-b-2 border-slate-800 pointer-events-none"></div>
                  <div className="absolute right-[350px] top-1/2 -translate-y-1/2 w-[110px] h-[2px] bg-slate-800 pointer-events-none"></div>
                </div>
              ))}
            </div>

            {/* Round 2 Right */}
            <div className="flex flex-col pt-[116px] gap-[188px]">
              {bracket?.[1].slice(8, 16).map((m, i) => (
                <div key={i} className="relative flex flex-col gap-4 h-[144px] justify-center">
                   {i === 4 && <div className="h-[216px]"></div>}
                   <TeamCard team={m.t1} points={m.p1} side="right" />
                   <div className="absolute right-[240px] top-[32px] w-[110px] h-[166px] border-l-2 border-t-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute right-[240px] bottom-[-134px] w-[110px] h-[166px] border-l-2 border-b-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute right-[350px] top-1/2 -translate-y-1/2 w-[110px] h-[2px] bg-slate-800 pointer-events-none"></div>
                </div>
              ))}
            </div>

            {/* Round 3 Right */}
            <div className="flex flex-col pt-[282px] gap-[476px]">
              {bracket?.[2].slice(4, 8).map((m, i) => (
                <div key={i} className="relative flex flex-col gap-4 h-[144px] justify-center">
                   {i === 2 && <div className="h-[432px]"></div>}
                   <TeamCard team={m.t1} points={m.p1} side="right" />
                   <div className="absolute right-[240px] top-[32px] w-[110px] h-[310px] border-l-2 border-t-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute right-[240px] bottom-[-278px] w-[110px] h-[310px] border-l-2 border-b-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute right-[350px] top-1/2 -translate-y-1/2 w-[110px] h-[2px] bg-slate-800 pointer-events-none"></div>
                </div>
              ))}
            </div>

            {/* Round 4 Right */}
            <div className="flex flex-col pt-[592px] gap-[1120px]">
              {bracket?.[3].slice(2, 4).map((m, i) => (
                <div key={i} className="relative flex flex-col gap-4 h-[144px] justify-center">
                   <TeamCard team={m.t1} points={m.p1} side="right" />
                   <div className="absolute right-[240px] top-[32px] w-[110px] h-[632px] border-l-2 border-t-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute right-[240px] bottom-[-600px] w-[110px] h-[632px] border-l-2 border-b-2 border-slate-800 pointer-events-none"></div>
                   <div className="absolute right-[350px] top-1/2 -translate-y-1/2 w-[110px] h-[2px] bg-slate-800 pointer-events-none"></div>
                </div>
              ))}
            </div>

            {/* Final Four Right */}
            <div className="flex flex-col pt-[1224px]">
              <div className="relative h-[144px] flex flex-col justify-center">
                <TeamCard team={bracket?.[4][1].t1} points={bracket?.[4][1].p1} side="right" />
                <div className="absolute right-[240px] top-1/2 -translate-y-1/2 w-[260px] h-[2px] bg-slate-800"></div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="p-4 bg-white border-t border-slate-300 text-center shadow-inner">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">FWL Global Championship • Professional Tournament Design System • 2025 Series</p>
      </footer>
    </div>
  );
};

export default GlobalPlayoffs;
