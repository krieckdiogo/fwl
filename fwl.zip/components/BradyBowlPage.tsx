import React, { useState, useEffect } from 'react';
import { ArrowLeft, ChevronRight, Shield, RefreshCw, Trophy } from 'lucide-react';
import { fetchLeagueInfo, getAvatarUrl } from '../services/sleeper';
import { League } from '../types';
import { FWL_BRADY_IDS } from '../App';

interface BradyBowlPageProps {
  onBack: () => void;
  onSelectLeague: (id: string) => void;
  onOpenGeneralPlayoffs?: () => void;
}

const BradyBowlPage: React.FC<BradyBowlPageProps> = ({ onBack, onSelectLeague, onOpenGeneralPlayoffs }) => {
  const [leagues, setLeagues] = useState<League[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadLeagues = async () => {
      setLoading(true);
      try {
        const fetched = await Promise.all(
          FWL_BRADY_IDS.map(id => fetchLeagueInfo(id))
        );
        setLeagues(fetched);
      } catch (error) {
        console.error("Failed to load Brady Bowl divisions:", error);
      } finally {
        setLoading(false);
      }
    };
    loadLeagues();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0f1d] flex flex-col items-center justify-center space-y-4">
        <RefreshCw className="w-10 h-10 text-yellow-500 animate-spin" />
        <p className="text-slate-500 font-black uppercase tracking-widest text-[10px]">Acessando Divisões Brady Bowl...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0f1d] py-12 px-6">
      <div className="max-w-2xl mx-auto space-y-10">
        <header className="flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Voltar</span>
          </button>
          <div className="text-right">
            <h1 className="text-2xl font-black text-white uppercase italic leading-none">Brady Bowl</h1>
            <p className="text-[10px] font-bold text-yellow-500 uppercase tracking-widest">Temporada 2025</p>
          </div>
        </header>

        {/* Highlight: Playoffs Geral (Acesso mantido em dourado, sem o ícone da espada) */}
        <button
          onClick={onOpenGeneralPlayoffs}
          className="w-full group relative flex items-center justify-between p-8 bg-gradient-to-br from-yellow-600/20 via-yellow-900/10 to-transparent border border-yellow-500/40 rounded-[2.5rem] transition-all hover:bg-yellow-600/30 hover:-translate-y-1 shadow-2xl overflow-hidden text-left"
        >
          <div className="relative z-10">
            <h3 className="font-black text-white text-2xl uppercase tracking-tighter italic leading-none mb-1">Playoffs Geral</h3>
            <p className="text-[10px] font-black text-yellow-500 uppercase tracking-widest">Mata-Mata Consolidado (64 Times)</p>
          </div>
          <ChevronRight className="w-8 h-8 text-yellow-500/50 group-hover:text-yellow-500 group-hover:translate-x-1 transition-all" />
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <Trophy className="w-24 h-24 text-yellow-500" />
          </div>
        </button>

        <div className="space-y-4">
          <div className="ml-2 space-y-1.5">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Temporada Regular - Semanas 1-11</p>
            <div className="space-y-0.5">
              <p className="text-[9px] font-bold text-blue-400 uppercase tracking-widest">3 primeiros, + o melhor 4° colocado classificam</p>
              <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Playoffs entre os 64 classificados</p>
            </div>
          </div>
          
          <div className="grid gap-3">
            {leagues.map((league) => {
              return (
                <button
                  key={league.league_id}
                  onClick={() => onSelectLeague(league.league_id)}
                  className="group relative flex items-center justify-between p-6 bg-[#1e293b]/30 border border-white/5 rounded-3xl transition-all hover:bg-white/5 hover:border-blue-500/30 hover:-translate-y-0.5 shadow-xl text-left"
                >
                  <div className="flex items-center gap-6">
                    <div className="w-14 h-14 rounded-2xl bg-slate-950 border border-white/10 flex items-center justify-center overflow-hidden shadow-lg group-hover:scale-105 transition-transform">
                      {league.avatar ? (
                        <img src={getAvatarUrl(league.avatar)} className="w-full h-full object-cover" alt="" />
                      ) : (
                        <Shield className="w-6 h-6 text-blue-500" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-black text-white text-lg uppercase tracking-tighter italic leading-none mb-1">
                        {league.name.replace('FWL 2025 - ', '').replace('FWL 2026 - ', '')}
                      </h3>
                      <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                        <span>{league.total_rosters} Times</span>
                        <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
                        <span>Temporada 2025</span>
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-6 h-6 text-slate-700 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
                </button>
              );
            })}
          </div>
        </div>

        {leagues.length === 0 && (
          <div className="text-center py-20 bg-white/5 rounded-[2.5rem] border border-dashed border-white/10">
            <p className="text-slate-500 font-black uppercase tracking-widest text-xs">Nenhuma divisão encontrada.</p>
          </div>
        )}

        <footer className="text-center pt-8 opacity-30">
          <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.5em]">FWL Data Protocol • 2025 Series</p>
        </footer>
      </div>
    </div>
  );
};

export default BradyBowlPage;