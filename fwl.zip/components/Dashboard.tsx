
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { fetchLeagueData, fetchMatchupsForWeek, fetchPlayers, getAvatarUrl, fetchLeagueInfo } from '../services/sleeper';
import { getLeagueInsights } from '../services/gemini';
import { AppData, Matchup, BracketMatch, Roster, User, Player, Transaction, League } from '../types';
import Logo from './Logo';
import RosterModal from './RosterModal';
import WinnerBracket from './WinnerBracket';
import { FWL_BRADY_IDS, ALABAMA_ID } from '../App';
import { 
  Trophy, 
  Zap, 
  RefreshCw, 
  AlertCircle, 
  Layers, 
  Medal, 
  ChevronLeft, 
  LayoutGrid, 
  ShieldCheck, 
  Clock,
  GitMerge
} from 'lucide-react';

interface DashboardProps {
  leagueId: string;
  onBack: () => void;
}

interface CalculatedStats {
  wins: number;
  losses: number;
  fpts: number;
}

const Dashboard: React.FC<DashboardProps> = ({ leagueId, onBack }) => {
  const [data, setData] = useState<AppData>({
    league: {} as any,
    users: [],
    rosters: [],
    matchups: [],
    transactions: [],
    winnersBracket: [],
    players: {},
    loading: true,
    error: null,
  });
  const [activeTab, setActiveTab] = useState<'standings' | 'matchups' | 'bracket'>('standings');
  const [selectedWeek, setSelectedWeek] = useState<number>(1);
  const [loadingContent, setLoadingContent] = useState(false);
  const [selectedRosterId, setSelectedRosterId] = useState<number | null>(null);
  const [manualStats, setManualStats] = useState<Record<number, CalculatedStats>>({});
  const [playoffMatchups, setPlayoffMatchups] = useState<Record<number, Record<number, number>>>({});

  const isBradyBowl = FWL_BRADY_IDS.includes(leagueId);
  const isAlabama = leagueId === ALABAMA_ID;
  const isDivisional = !isBradyBowl;
  const maxWeeksAllowed = isBradyBowl ? 11 : 14;

  const loadData = useCallback(async () => {
    setData(prev => ({ ...prev, loading: true, error: null }));
    try {
      let currentLeagueInfo = await fetchLeagueInfo(leagueId);
      let targetId = leagueId;

      if (currentLeagueInfo.season === '2026' && currentLeagueInfo.previous_league_id) {
        targetId = currentLeagueInfo.previous_league_id;
      }

      const [result, players] = await Promise.all([
        fetchLeagueData(targetId),
        fetchPlayers()
      ]);

      // CÁLCULO MANUAL ATÉ A SEMANA LIMITE
      const statsMap: Record<number, CalculatedStats> = {};
      result.rosters.forEach(r => {
        statsMap[r.roster_id] = { wins: 0, losses: 0, fpts: 0 };
      });

      const weekPromises = [];
      for (let w = 1; w <= maxWeeksAllowed; w++) {
        weekPromises.push(fetchMatchupsForWeek(targetId, w));
      }

      // Adiciona semanas de playoff para todas as ligas Divisionais (15, 16, 17) para o Bracket
      if (isDivisional) {
        weekPromises.push(fetchMatchupsForWeek(targetId, 15));
        weekPromises.push(fetchMatchupsForWeek(targetId, 16));
        weekPromises.push(fetchMatchupsForWeek(targetId, 17));
      }

      const allWeeksResults = await Promise.all(weekPromises);
      
      // Mapeia pontuações de playoff (W15, 16, 17)
      const playoffMap: Record<number, Record<number, number>> = {};
      
      allWeeksResults.forEach((weekMatchups, index) => {
        const weekNum = index + 1;
        if (!weekMatchups) return;
        
        // Se for uma das semanas de playoff (15, 16 ou 17 em ligas Divisionais)
        const isPlayoffWeek = isDivisional && (weekNum >= 15);
        const actualWeek = weekNum;

        if (isPlayoffWeek) {
          playoffMap[actualWeek] = {};
          weekMatchups.forEach(m => {
            playoffMap[actualWeek][m.roster_id] = m.points;
          });
        }

        // Processa apenas até a semana limite para a tabela de classificação regular
        if (weekNum <= maxWeeksAllowed) {
          const paired: Record<number, Matchup[]> = {};
          weekMatchups.forEach(m => {
            if (!paired[m.matchup_id]) paired[m.matchup_id] = [];
            paired[m.matchup_id].push(m);
            
            if (statsMap[m.roster_id]) {
              statsMap[m.roster_id].fpts += m.points;
            }
          });

          Object.values(paired).forEach(pair => {
            if (pair.length === 2) {
              const [t1, t2] = pair;
              if (t1.points > t2.points) {
                if (statsMap[t1.roster_id]) statsMap[t1.roster_id].wins++;
                if (statsMap[t2.roster_id]) statsMap[t2.roster_id].losses++;
              } else if (t2.points > t1.points) {
                if (statsMap[t2.roster_id]) statsMap[t2.roster_id].wins++;
                if (statsMap[t1.roster_id]) statsMap[t1.roster_id].losses++;
              }
            }
          });
        }
      });

      setManualStats(statsMap);
      setPlayoffMatchups(playoffMap);

      const currentLeg = result.league.settings.leg || 1;
      // Aba de Matchups agora limitada a maxWeeksAllowed (11 para Brady, 14 para Divisional)
      let targetWeek = Math.max(1, Math.min(currentLeg, maxWeeksAllowed));
      
      const initialMatchups = allWeeksResults[targetWeek - 1] || [];

      setData({
        ...result,
        matchups: initialMatchups,
        players,
        loading: false,
        error: null,
      });

      setSelectedWeek(targetWeek);
    } catch (err) {
      console.error(err);
      setData(prev => ({ ...prev, loading: false, error: 'Erro ao carregar dados oficiais.' }));
    }
  }, [leagueId, maxWeeksAllowed, isDivisional]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleWeekChange = async (week: number) => {
    setSelectedWeek(week);
    setLoadingContent(true);
    try {
      const newMatchups = await fetchMatchupsForWeek(data.league.league_id, week);
      setData(prev => ({ ...prev, matchups: newMatchups }));
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingContent(false);
    }
  };

  const sortedRosters = useMemo(() => {
    return [...data.rosters].sort((a, b) => {
      const statsA = manualStats[a.roster_id] || { wins: 0, losses: 0, fpts: 0 };
      const statsB = manualStats[b.roster_id] || { wins: 0, losses: 0, fpts: 0 };
      
      if (statsB.wins !== statsA.wins) return statsB.wins - statsA.wins;
      return statsB.fpts - statsA.fpts;
    });
  }, [data.rosters, manualStats]);

  const getSleeperUser = (rosterId: number) => {
    const roster = data.rosters.find(r => r.roster_id === rosterId);
    return data.users.find(u => u.user_id === roster?.owner_id);
  };

  if (data.loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#111827] space-y-4">
        <div className="relative">
          <RefreshCw className="w-12 h-12 text-[#00ce7d] animate-spin" />
          <div className="absolute inset-0 bg-[#00ce7d]/20 blur-2xl rounded-full"></div>
        </div>
        <div className="text-center">
          <p className="text-white font-black uppercase tracking-[0.3em] text-xs italic">Sincronizando {isDivisional ? 'Divisional' : 'Liga'}</p>
          <p className="text-slate-500 font-bold uppercase tracking-widest text-[9px] mt-1 animate-pulse">Lendo Dados...</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'standings', label: 'Tabela', icon: LayoutGrid },
    { id: 'matchups', label: 'Jogos', icon: Zap },
    { id: 'bracket', label: 'Playoffs', icon: GitMerge },
  ].filter(tab => !(tab.id === 'bracket' && isBradyBowl));

  // A aba de jogos agora mostra apenas até a semana de corte da temporada regular
  const matchupWeeksCount = maxWeeksAllowed;

  return (
    <div className="min-h-screen bg-[#111827] text-slate-100 font-sans selection:bg-[#00ce7d]/30">
      {selectedRosterId && (
        <RosterModal 
          roster={data.rosters.find(r => r.roster_id === selectedRosterId)!} 
          user={getSleeperUser(selectedRosterId)} 
          playersMap={data.players}
          onClose={() => setSelectedRosterId(null)}
          customStats={manualStats[selectedRosterId]}
        />
      )}

      <header className="bg-[#1f2937]/80 backdrop-blur-md border-b border-white/5 sticky top-0 z-40 shadow-2xl">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full text-slate-400 hover:text-white transition-all">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <div className="w-14 h-14 rounded-2xl bg-slate-800 border border-white/10 overflow-hidden shadow-2xl group cursor-pointer relative">
               <Logo leagueAvatar={data.league.avatar} className="w-full h-full" />
            </div>
            <div>
              <h1 className="text-xl font-black text-white italic leading-none mb-1 uppercase tracking-tight truncate max-w-[200px] sm:max-w-none">
                {data.league.name.replace('FWL 2025 - ', '').replace('FWL 2026 - ', '')}
              </h1>
              <div className="flex items-center gap-2 text-[10px] font-black text-[#00ce7d] uppercase tracking-[0.2em]">
                <span className="bg-[#00ce7d]/10 px-1.5 py-0.5 rounded">{isBradyBowl ? 'BRADY BOWL' : 'DIVISIONAL'}</span>
                <span className="w-1 h-1 bg-slate-600 rounded-full"></span>
                <span className="text-slate-400">PLAYOFFS: {isBradyBowl ? 'W12-W17' : 'W15-W17'}</span>
              </div>
            </div>
          </div>
          <div className="hidden sm:block text-right">
             <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Sleeper Engine</p>
             <p className="text-xs font-mono text-blue-400">{data.league.league_id}</p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto flex px-2 overflow-x-auto no-scrollbar border-t border-white/5">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-8 py-5 border-b-2 transition-all text-[11px] font-black uppercase tracking-[0.2em] whitespace-nowrap ${
                activeTab === tab.id 
                ? 'border-[#00ce7d] text-[#00ce7d] bg-[#00ce7d]/5' 
                : 'border-transparent text-slate-500 hover:text-slate-300'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4 space-y-8 pb-32">
        {activeTab === 'matchups' && (
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2 px-1">
            {Array.from({ length: matchupWeeksCount }, (_, i) => i + 1).map(week => (
              <button
                key={week}
                onClick={() => handleWeekChange(week)}
                className={`flex-shrink-0 min-w-[80px] px-4 py-3 rounded-xl text-[11px] font-black border transition-all ${
                  selectedWeek === week 
                  ? 'bg-[#00ce7d] border-[#00ce7d] text-white shadow-[0_10px_20px_-5px_rgba(0,206,125,0.4)]' 
                  : 'bg-[#1f2937] border-white/5 text-slate-500 hover:border-slate-600'
                }`}
              >
                WEEK {week}
              </button>
            ))}
          </div>
        )}

        {loadingContent && (
          <div className="flex flex-col items-center justify-center py-24 space-y-4">
            <RefreshCw className="w-10 h-10 text-[#00ce7d] animate-spin" />
            <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Buscando Confrontos...</p>
          </div>
        )}

        {!loadingContent && activeTab === 'standings' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
             <div className="bg-blue-600/10 border border-blue-500/20 p-6 rounded-[2rem] flex items-center gap-6 shadow-2xl relative overflow-hidden group">
               <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                  <Clock className="w-24 h-24 text-blue-500" />
               </div>
               <div className="p-4 bg-blue-500/20 rounded-2xl border border-blue-500/30 relative z-10">
                  <Trophy className="w-8 h-8 text-blue-400" />
               </div>
               <div className="relative z-10">
                  <h3 className="text-xs font-black text-white uppercase tracking-[0.2em] italic mb-1">Classificação Regular</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-relaxed">
                    Mostrando dados consolidados das <strong className="text-blue-400">Semanas 1 a {maxWeeksAllowed}</strong>.<br/>
                    {isBradyBowl ? 'Top 3 avança para os Playoffs Gerais.' : 'Resultados oficiais da temporada regular divisional.'}
                  </p>
               </div>
             </div>

             <div className="bg-[#1f2937] rounded-[2rem] overflow-hidden border border-white/5 shadow-2xl">
               <div className="px-8 py-6 border-b border-white/5 bg-white/5 flex items-center justify-between">
                 <h2 className="text-xs font-black text-white uppercase tracking-[0.3em] flex items-center gap-2">
                   <LayoutGrid className="w-4 h-4 text-slate-500" /> Líderes da Temporada
                 </h2>
                 <span className="text-[9px] font-black text-blue-500 uppercase tracking-widest bg-blue-500/10 px-2 py-1 rounded">DATA LOCK: W{maxWeeksAllowed}</span>
               </div>
               <div className="overflow-x-auto">
                 <table className="w-full text-left">
                   <thead>
                     <tr className="bg-black/20 text-[10px] font-black text-slate-500 uppercase tracking-widest">
                       <th className="px-8 py-5 w-16 text-center">RANK</th>
                       <th className="px-4 py-5">MANAGER / TIME</th>
                       <th className="px-4 py-5 text-center">RECORD</th>
                       <th className="px-8 py-5 text-right">PONTOS (PF)</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-white/5">
                      {sortedRosters.map((roster, idx) => {
                        const user = data.users.find(u => u.user_id === roster.owner_id);
                        const stats = manualStats[roster.roster_id] || { wins: 0, losses: 0, fpts: 0 };
                        const isQualified = isBradyBowl ? (idx < 3) : (idx < 6);
                        
                        return (
                          <tr 
                            key={roster.roster_id} 
                            className={`hover:bg-white/5 cursor-pointer transition-all relative group ${isQualified ? 'bg-blue-500/[0.03]' : ''}`}
                            onClick={() => setSelectedRosterId(roster.roster_id)}
                          >
                            <td className={`px-8 py-6 text-center font-black text-sm ${isQualified ? 'text-blue-400' : 'text-slate-600'}`}>
                              {String(idx + 1).padStart(2, '0')}
                            </td>
                            <td className="px-4 py-6">
                              <div className="flex items-center gap-4">
                                <div className="relative">
                                  <img src={getAvatarUrl(user?.avatar || null)} className={`w-11 h-11 rounded-full border-2 p-0.5 transition-transform group-hover:scale-110 ${isQualified ? 'border-blue-500 shadow-[0_0_15px_rgba(37,99,235,0.3)]' : 'border-slate-700'}`} alt="" />
                                </div>
                                <div className="flex flex-col min-w-0">
                                  <span className="text-sm font-bold text-white truncate leading-none">{user?.display_name || 'Owner'}</span>
                                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-tighter truncate max-w-[150px] mt-1 italic">{user?.metadata?.team_name || 'Equipe Desconhecida'}</span>
                                </div>
                              </div>
                            </td>
                            <td className={`px-4 py-6 text-center text-sm font-black ${isQualified ? 'text-blue-400' : 'text-[#00ce7d]'}`}>
                              {stats.wins}-{stats.losses}
                            </td>
                            <td className="px-8 py-6 text-right">
                              <div className="text-sm font-black text-white leading-none">{stats.fpts.toFixed(2)}</div>
                              <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mt-1">Pontos Semana 1-{maxWeeksAllowed}</div>
                            </td>
                          </tr>
                        );
                      })}
                   </tbody>
                 </table>
               </div>
             </div>
          </div>
        )}

        {!loadingContent && activeTab === 'matchups' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in zoom-in duration-500">
            {data.matchups.length > 0 ? (() => {
              const pairs: Record<number, Matchup[]> = {};
              data.matchups.forEach(m => {
                if (!pairs[m.matchup_id]) pairs[m.matchup_id] = [];
                pairs[m.matchup_id].push(m);
              });
              return Object.entries(pairs).map(([id, teams]) => (
                <div key={id} className="bg-[#1f2937] border border-white/5 rounded-[2rem] p-8 flex flex-col gap-8 shadow-2xl hover:border-[#00ce7d]/30 transition-all group relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-1 h-full bg-slate-800 group-hover:bg-[#00ce7d] transition-colors"></div>
                  {teams.map((t, idx) => {
                    const u = getSleeperUser(t.roster_id);
                    const isWinning = teams.length === 2 && t.points > teams[idx === 0 ? 1 : 0].points;
                    return (
                      <div key={t.roster_id} className="flex items-center justify-between">
                         <div className="flex items-center gap-4">
                            <img src={getAvatarUrl(u?.avatar || null)} className={`w-12 h-12 rounded-full border-2 ${isWinning ? 'border-[#00ce7d]' : 'border-slate-700'}`} alt="" />
                            <div className="flex flex-col min-w-0">
                               <span className="text-sm font-bold truncate max-w-[140px] text-white">{u?.display_name}</span>
                               <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-0.5">SEED {sortedRosters.findIndex(r => r.roster_id === t.roster_id) + 1}</span>
                            </div>
                         </div>
                         <div className={`text-2xl font-black italic tracking-tighter ${isWinning ? 'text-[#00ce7d] drop-shadow-[0_0_10px_rgba(0,206,125,0.3)]' : 'text-slate-500'}`}>
                           {t.points.toFixed(2)}
                         </div>
                      </div>
                    );
                  })}
                </div>
              ));
            })() : (
              <div className="col-span-full py-24 text-center bg-[#1f2937]/50 rounded-[3rem] border border-dashed border-white/10 space-y-4">
                <AlertCircle className="w-12 h-12 text-slate-700 mx-auto" />
                <div>
                  <p className="text-white font-black uppercase tracking-widest text-sm">Calendário Não Encontrado</p>
                  <p className="text-slate-500 font-bold uppercase tracking-widest text-[9px] mt-1">Nenhum dado localizado para esta semana.</p>
                </div>
              </div>
            )}
          </div>
        )}

        {!loadingContent && activeTab === 'bracket' && isDivisional && (
          <WinnerBracket 
            bracket={data.winnersBracket} 
            users={data.users} 
            rosters={data.rosters}
            playoffScores={playoffMatchups}
          />
        )}
      </main>
      
      <footer className="fixed bottom-0 left-0 w-full bg-[#111827]/90 backdrop-blur-md border-t border-white/5 py-4 px-6 z-50">
        <div className="max-w-4xl mx-auto flex items-center justify-between text-[9px] font-black text-slate-500 uppercase tracking-[0.3em]">
           <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-[#00ce7d] animate-pulse"></div>
             <span>MODALIDADE: {isAlabama ? 'ALABAMA PLAYOFFS' : (isBradyBowl ? 'BRADY BOWL' : 'DIVISIONAL')}</span>
           </div>
           <span>FWL 2025 SERIES • {data.league.name.replace('FWL 2025 - ', '').replace('FWL 2026 - ', '')}</span>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;
