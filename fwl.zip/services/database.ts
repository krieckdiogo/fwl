
import { createClient } from '@supabase/supabase-js';

/**
 * CONFIGURAÇÃO SUPABASE
 */
const supabaseUrl = 'https://yzilgcyikbrhaizfmlsq.supabase.co';
const supabaseAnonKey = 'sb_publishable_zz8g3gWWbBt2AId3JNmWdg_6JvVIGix';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Registration {
  id?: number;
  created_at?: string;
  played_2025: string;
  full_name: string;
  cpf: string;
  sleeper_id: string;
  whatsapp: string;
  email: string;
  origin: string;
}

/**
 * Converte erros complexos do Supabase em mensagens legíveis.
 */
const parseSupabaseError = (error: any): string => {
  if (!error) return "Erro desconhecido.";

  // Caso o erro seja uma string direta
  if (typeof error === 'string') return error;

  // Erros do PostgREST/Supabase geralmente vêm com message, details e hint
  const msg = error.message || error.error_description || error.code || "";
  const details = error.details || "";
  
  if (msg.includes('relation "public.registrations" does not exist') || 
      msg.includes('42P01') ||
      msg.includes('not found')) {
    return "ERRO DE BANCO: A tabela 'registrations' não existe no seu projeto Supabase. Por favor, acesse a Área do Comissário e execute o comando SQL de criação.";
  }

  if (msg) {
    return `${msg}${details ? ' (' + details + ')' : ''}`;
  }

  return JSON.stringify(error);
};

export const saveRegistration = async (data: Registration) => {
  try {
    const { error } = await supabase
      .from('registrations')
      .insert([data]);
    
    if (error) {
      throw new Error(parseSupabaseError(error));
    }
    return true;
  } catch (err: any) {
    console.error("Save Error:", err);
    throw new Error(err.message || "Falha ao salvar na nuvem.");
  }
};

export const fetchAllRegistrations = async () => {
  try {
    const { data, error } = await supabase
      .from('registrations')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      throw new Error(parseSupabaseError(error));
    }
    return data || [];
  } catch (err: any) {
    console.error("Fetch Error:", err);
    throw new Error(err.message || "Erro ao carregar dados.");
  }
};

export const fetchRegistrationCount = async (): Promise<number> => {
  try {
    // Busca apenas a coluna sleeper_id para contagem de únicos
    const { data, error } = await supabase
      .from('registrations')
      .select('sleeper_id');
    
    if (error) {
      console.error("Count Error:", error);
      return 0;
    }

    if (!data || data.length === 0) return 0;

    // Normaliza e conta apenas IDs únicos
    const uniqueIds = new Set(
      data
        .map(r => r.sleeper_id)
        .filter(id => id) // Remove nulos/vazios
        .map(id => id.trim().toLowerCase()) // Normaliza para evitar duplicatas por case/espaço
    );

    return uniqueIds.size;
  } catch (err) {
    console.error("Count Fetch Error:", err);
    return 0;
  }
};

export const deleteRegistration = async (id: number) => {
  const { error } = await supabase
    .from('registrations')
    .delete()
    .eq('id', id);
  
  if (error) throw new Error(parseSupabaseError(error));
  return true;
};

export const clearAllRegistrations = async () => {
  const { error } = await supabase
    .from('registrations')
    .delete()
    .neq('id', 0);
  
  if (error) throw new Error(parseSupabaseError(error));
  return true;
};
