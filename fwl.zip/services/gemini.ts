
import { GoogleGenAI, Type } from "@google/genai";
import { AppData, Roster, User } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getLeagueInsights = async (data: Partial<AppData>) => {
  const model = "gemini-3-flash-preview";
  
  const standingsStr = data.rosters?.map((r, i) => {
    const user = data.users?.find(u => u.user_id === r.owner_id);
    return `${i + 1}. ${user?.display_name || 'Unknown'}: ${r.settings.wins}W-${r.settings.losses}L, Points: ${r.settings.fpts}`;
  }).join('\n');

  const prompt = `
    Como um analista especialista em Fantasy Football, analise os dados da liga "${data.league?.name}" da temporada ${data.league?.season}.
    
    Classificação atual:
    ${standingsStr}

    Forneça:
    1. Um resumo curto da situação da liga.
    2. Quem é o favorito ao título e por quê.
    3. Uma "zueira" (trash talk) leve sobre o último colocado.
    
    Responda em português brasileiro de forma descontraída e profissional.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [{ parts: [{ text: prompt }] }],
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Não foi possível gerar insights no momento. O comissário está dormindo.";
  }
};
