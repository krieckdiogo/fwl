import { League, User, Roster, Matchup, BracketMatch, Player, Transaction } from '../types';

const BASE_URL = 'https://api.sleeper.app/v1';

export const fetchLeagueInfo = async (leagueId: string): Promise<League> => {
  const res = await fetch(`${BASE_URL}/league/${leagueId}`);
  if (!res.ok) throw new Error(`Failed to fetch league info for ${leagueId}`);
  return res.json();
};

export const fetchTransactions = async (leagueId: string, week: number): Promise<Transaction[]> => {
  const res = await fetch(`${BASE_URL}/league/${leagueId}/transactions/${week}`);
  if (!res.ok) return [];
  return res.json();
};

export const fetchLeagueData = async (leagueId: string) => {
  try {
    const [leagueRes, usersRes, rostersRes] = await Promise.all([
      fetch(`${BASE_URL}/league/${leagueId}`),
      fetch(`${BASE_URL}/league/${leagueId}/users`),
      fetch(`${BASE_URL}/league/${leagueId}/rosters`),
    ]);

    if (!leagueRes.ok) throw new Error(`League info not found for ID: ${leagueId}`);
    
    const league: League = await leagueRes.json();
    const users: User[] = await usersRes.json();
    const rosters: Roster[] = await rostersRes.json();

    let winnersBracket: BracketMatch[] = [];
    try {
      const winnersRes = await fetch(`${BASE_URL}/league/${leagueId}/winners_bracket`);
      if (winnersRes.ok) {
        winnersBracket = await winnersRes.json();
      }
    } catch (e) {}

    const week = league.settings.leg || 1;
    const [matchups, transactions] = await Promise.all([
      fetchMatchupsForWeek(leagueId, week).catch(() => []),
      fetchTransactions(leagueId, week).catch(() => [])
    ]);

    return { league, users, rosters, matchups, transactions, winnersBracket };
  } catch (error) {
    throw error;
  }
};

export const fetchDrafts = async (leagueId: string) => {
  const res = await fetch(`${BASE_URL}/league/${leagueId}/drafts`);
  if (!res.ok) return [];
  return res.json();
};

export const fetchDraftPicks = async (draftId: string) => {
  const res = await fetch(`${BASE_URL}/draft/${draftId}/picks`);
  if (!res.ok) return [];
  return res.json();
};

// Cache local para jogadores para evitar fetch repetitivo de 30MB
let playersCache: Record<string, Player> | null = null;

export const fetchPlayers = async (): Promise<Record<string, Player>> => {
  if (playersCache) return playersCache;
  const res = await fetch(`${BASE_URL}/players/nfl`);
  if (!res.ok) throw new Error('Failed to fetch player database');
  playersCache = await res.json();
  return playersCache!;
};

export const fetchMatchupsForWeek = async (leagueId: string, week: number): Promise<Matchup[]> => {
  const res = await fetch(`${BASE_URL}/league/${leagueId}/matchups/${week}`);
  if (!res.ok) return [];
  return res.json();
};

export const getAvatarUrl = (avatarId: string | null) => {
  if (!avatarId) return 'https://sleepercdn.com/images/v2/icons/player_default.webp';
  if (avatarId.startsWith('http')) return avatarId;
  return `https://sleepercdn.com/avatars/thumbs/${avatarId}`;
};

export const getPlayerImageUrl = (playerId: string, position: string) => {
  if (position === 'DEF') {
    return `https://sleepercdn.com/images/team_logos/nfl/${playerId.toLowerCase()}.png`;
  }
  return `https://sleepercdn.content/nfl/players/thumb/${playerId}.jpg`;
};